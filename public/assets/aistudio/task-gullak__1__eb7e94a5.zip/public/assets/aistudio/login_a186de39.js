 /* =========================================================
    TASK GULLAK — LOGIN.JS
    Firebase Authentication
    Clean UI • Field Errors Only • Firebase Session
 ========================================================= */

 import {
     signInWithEmailAndPassword,
     signInWithPopup,
     signInWithRedirect,
     getRedirectResult,
     sendEmailVerification,
     onAuthStateChanged,
     signOut
 } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

 import {
     auth,
     googleProvider
 } from "../config.js";


 /* =========================================================
    DOM ELEMENTS
 ========================================================= */

 const loginForm =
     document.getElementById("loginForm");

 const emailInput =
     document.getElementById("emailInput");

 const passwordInput =
     document.getElementById("passwordInput");

 const emailInputBox =
     document.getElementById("emailInputBox");

 const passwordInputBox =
     document.getElementById("passwordInputBox");

 const emailMessage =
     document.getElementById("emailMessage");

 const passwordMessage =
     document.getElementById("passwordMessage");

 const loginButton =
     document.getElementById("loginButton");

 const loginButtonText =
     document.getElementById("loginButtonText");

 const loginLoader =
     document.getElementById("loginLoader");

 const googleLoginButton =
     document.getElementById("googleLoginButton");

 const passwordToggle =
     document.getElementById("passwordToggle");

 const eyeClosed =
     document.getElementById("eyeClosed");

 const eyeOpen =
     document.getElementById("eyeOpen");


 /* =========================================================
    CONFIG & STATE
 ========================================================= */

 const HOME_PAGE =
     "../../04-HOME/home.html";

 let loginInProgress = false;
 let googleLoginInProgress = false;


 /* =========================================================
    TEMPORARY CLIENT-SIDE LOGIN PROTECTION
    NOTE:
    Production rate limiting should be server-side.
 ========================================================= */

 const MAX_FAILED_ATTEMPTS = 5;

 const LOCKOUT_TIME_MS =
     15 * 60 * 1000;

 let failedLoginAttempts = 0;

 let lockoutUntil = 0;


 /* =========================================================
    INITIALIZE
 ========================================================= */

 function initializeLogin() {

     if (!loginForm) {

         console.error(
             "Task Gullak: loginForm not found in DOM."
         );

         return;
     }


     if (!auth) {

         console.error(
             "Task Gullak: Firebase Auth unavailable."
         );

         return;
     }


     setupPasswordToggle();

     setupInputValidation();

     setupLoginForm();

     setupGoogleLogin();

     setupFirebaseAuthState();

     handleGoogleRedirectResult();


     console.log(
         "Task Gullak Login initialized successfully."
     );
 }


 /* =========================================================
    PASSWORD SHOW / HIDE
 ========================================================= */

 function setupPasswordToggle() {

     if (!passwordInput || !passwordToggle) {
         return;
     }


     passwordInput.type = "password";


     if (eyeClosed) {
         eyeClosed.classList.add("active");
     }


     if (eyeOpen) {
         eyeOpen.classList.remove("active");
     }


     passwordToggle.setAttribute(
         "aria-label",
         "Show password"
     );

     passwordToggle.setAttribute(
         "title",
         "Show password"
     );


     passwordToggle.addEventListener(
         "click",
         function () {

             const isHidden =
                 passwordInput.type === "password";


             if (isHidden) {

                 passwordInput.type = "text";


                 eyeClosed?.classList.remove(
                     "active"
                 );

                 eyeOpen?.classList.add(
                     "active"
                 );


                 passwordToggle.setAttribute(
                     "aria-label",
                     "Hide password"
                 );

                 passwordToggle.setAttribute(
                     "title",
                     "Hide password"
                 );

             } else {

                 passwordInput.type =
                     "password";


                 eyeOpen?.classList.remove(
                     "active"
                 );

                 eyeClosed?.classList.add(
                     "active"
                 );


                 passwordToggle.setAttribute(
                     "aria-label",
                     "Show password"
                 );

                 passwordToggle.setAttribute(
                     "title",
                     "Show password"
                 );
             }


             passwordInput.focus();
         }
     );
 }


 /* =========================================================
    INPUT VALIDATION
 ========================================================= */

 function setupInputValidation() {

     if (emailInput) {

         emailInput.addEventListener(
             "input",
             function () {

                 clearFieldError(
                     emailInputBox,
                     emailMessage
                 );
             }
         );


         emailInput.addEventListener(
             "blur",
             function () {

                 if (
                     emailInput.value.trim()
                 ) {

                     validateEmail();
                 }
             }
         );
     }


     if (passwordInput) {

         passwordInput.addEventListener(
             "input",
             function () {

                 clearFieldError(
                     passwordInputBox,
                     passwordMessage
                 );
             }
         );
     }
 }


 /* =========================================================
    RATE LIMITING GUARD
 ========================================================= */

 function checkRateLimit() {

     const now = Date.now();


     if (
         lockoutUntil &&
         now < lockoutUntil
     ) {

         const remainingMinutes =
             Math.ceil(
                 (lockoutUntil - now) / 60000
             );


         showFieldError(
             emailInputBox,
             emailMessage,
             `Too many failed attempts. Try again after ${remainingMinutes} minute(s).`
         );


         return false;
     }


     if (
         lockoutUntil &&
         now >= lockoutUntil
     ) {

         resetFailedAttempts();
     }


     return true;
 }


 function registerFailedAttempt() {

     failedLoginAttempts += 1;


     if (
         failedLoginAttempts >=
         MAX_FAILED_ATTEMPTS
     ) {

         lockoutUntil =
             Date.now() +
             LOCKOUT_TIME_MS;


         showFieldError(
             emailInputBox,
             emailMessage,
             "5 failed attempts reached. Login locked for 15 minutes."
         );
     }
 }


 function resetFailedAttempts() {

     failedLoginAttempts = 0;

     lockoutUntil = 0;
 }


 /* =========================================================
    LOGIN FORM
 ========================================================= */

 function setupLoginForm() {

     loginForm.addEventListener(
         "submit",
         async function (event) {

             event.preventDefault();


             if (loginInProgress) {
                 return;
             }


             if (!checkRateLimit()) {
                 return;
             }


             const email =
                 emailInput?.value
                     ?.trim()
                     ?.toLowerCase() || "";


             const password =
                 passwordInput?.value || "";


             clearAllErrors();


             /* EMAIL REQUIRED */

             if (!email) {

                 showFieldError(
                     emailInputBox,
                     emailMessage,
                     "Please enter your email address."
                 );

                 emailInput?.focus();

                 return;
             }


             /* EMAIL FORMAT */

             if (!isValidEmail(email)) {

                 showFieldError(
                     emailInputBox,
                     emailMessage,
                     "Please enter a valid email address."
                 );

                 emailInput?.focus();

                 return;
             }


             /* PASSWORD REQUIRED */

             if (!password) {

                 showFieldError(
                     passwordInputBox,
                     passwordMessage,
                     "Please enter your password."
                 );

                 passwordInput?.focus();

                 return;
             }


             await loginWithEmail(
                 email,
                 password
             );
         }
     );
 }


 /* =========================================================
    EMAIL / PASSWORD LOGIN
 ========================================================= */

 async function loginWithEmail(
     email,
     password
 ) {

     loginInProgress = true;

     setLoginLoading(true);


     try {

         const userCredential =
             await signInWithEmailAndPassword(
                 auth,
                 email,
                 password
             );


         const user =
             userCredential.user;


         if (!user) {

             throw new Error(
                 "Authentication failed."
             );
         }


         /*
          * Refresh Firebase user information.
          */

         await user.reload();


         const currentUser =
             auth.currentUser;


         if (!currentUser) {

             throw new Error(
                 "Authentication session unavailable."
             );
         }


         /* =================================================
            EMAIL VERIFICATION
         ================================================= */

         if (!currentUser.emailVerified) {

             try {

                 await sendEmailVerification(
                     currentUser
                 );

             } catch (verificationError) {

                 console.warn(
                     "Could not resend verification email:",
                     verificationError
                 );
             }


             await signOut(auth);


             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "This email is not verified. Verification link sent to your inbox."
             );


             return;
         }


         /* =================================================
            SUCCESSFUL LOGIN
         ================================================= */

         resetFailedAttempts();


         await delay(300);


         /*
          * Firebase maintains the authenticated session.
          * No localStorage login flag is required.
          */

         window.location.replace(
             HOME_PAGE
         );

     } catch (error) {

         registerFailedAttempt();

         handleFirebaseLoginError(
             error
         );

     } finally {

         loginInProgress = false;

         setLoginLoading(false);
     }
 }


 /* =========================================================
    GOOGLE LOGIN
 ========================================================= */

 function setupGoogleLogin() {

     if (!googleLoginButton) {
         return;
     }


     googleLoginButton.addEventListener(
         "click",
         async function () {

             if (
                 googleLoginInProgress ||
                 loginInProgress
             ) {
                 return;
             }


             googleLoginInProgress = true;

             setGoogleLoading(true);

             clearAllErrors();


             try {

                 const result =
                     await signInWithPopup(
                         auth,
                         googleProvider
                     );


                 const user =
                     result.user;


                 if (!user) {

                     throw new Error(
                         "Google authentication failed."
                     );
                 }


                 resetFailedAttempts();


                 await delay(300);


                 window.location.replace(
                     HOME_PAGE
                 );

             } catch (error) {

                 /*
                  * Popup blocked → use redirect.
                  */

                 if (
                     error?.code ===
                     "auth/popup-blocked"
                 ) {

                     try {

                         await signInWithRedirect(
                             auth,
                             googleProvider
                         );

                         return;

                     } catch (
                         redirectError
                     ) {

                         handleFirebaseLoginError(
                             redirectError
                         );
                     }


                 } else if (
                     error?.code ===
                     "auth/popup-closed-by-user"
                 ) {

                     /*
                      * User intentionally closed
                      * the Google popup.
                      */

                     return;


                 } else {

                     handleFirebaseLoginError(
                         error
                     );
                 }

             } finally {

                 googleLoginInProgress =
                     false;

                 setGoogleLoading(false);
             }
         }
     );
 }


 /* =========================================================
    GOOGLE REDIRECT RESULT
 ========================================================= */

 async function handleGoogleRedirectResult() {

     try {

         const result =
             await getRedirectResult(
                 auth
             );


         if (
             !result ||
             !result.user
         ) {
             return;
         }


         const user =
             result.user;


         if (!user) {
             return;
         }


         resetFailedAttempts();


         await delay(300);


         window.location.replace(
             HOME_PAGE
         );

     } catch (error) {

         handleFirebaseLoginError(
             error
         );
     }
 }


 /* =========================================================
    FIREBASE AUTH STATE
 ========================================================= */

 function setupFirebaseAuthState() {

     onAuthStateChanged(
         auth,
         async function (user) {

             /*
              * No Firebase session.
              * User can remain on Login.
              */

             if (!user) {
                 return;
             }


             try {

                 /*
                  * Refresh user information.
                  */

                 await user.reload();


                 const currentUser =
                     auth.currentUser;


                 if (!currentUser) {
                     return;
                 }


                 /*
                  * Determine authentication provider.
                  */

                 const isPasswordUser =
                     currentUser.providerData.some(
                         provider =>
                             provider.providerId ===
                             "password"
                     );


                 /*
                  * Email/password accounts must
                  * have verified email.
                  */

                 if (
                     isPasswordUser &&
                     !currentUser.emailVerified
                 ) {

                     /*
                      * Do not keep an unverified
                      * account signed in on Login.
                      */

                     await signOut(auth);

                     console.log(
                         "Unverified user signed out."
                     );

                     return;
                 }


                 /*
                  * Existing authenticated user.
                  *
                  * Firebase remembers the session,
                  * so Login page is skipped.
                  */

                 console.log(
                     "Existing Firebase session found:",
                     currentUser.uid
                 );


                 window.location.replace(
                     HOME_PAGE
                 );

             } catch (error) {

                 console.error(
                     "Task Gullak Auth State Error:",
                     error
                 );
             }
         }
     );
 }


 /* =========================================================
    FIREBASE ERROR HANDLING
 ========================================================= */

 function handleFirebaseLoginError(error) {

     console.error(
         "Task Gullak Login Error:",
         error
     );


     const code =
         error?.code || "";


     clearAllErrors();


     switch (code) {

         case "auth/user-not-found":

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "This email address is not registered. Please sign up first."
             );

             break;


         case "auth/wrong-password":

         case "auth/invalid-credential":

             showFieldError(
                 passwordInputBox,
                 passwordMessage,
                 "Incorrect email or password. Please try again."
             );

             break;


         case "auth/invalid-email":

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "Please enter a valid email address."
             );

             break;


         case "auth/user-disabled":

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "This account has been disabled. Please contact Task Gullak support."
             );

             break;


         case "auth/too-many-requests":

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "Too many login attempts. Please try again later."
             );

             break;


         case "auth/network-request-failed":

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "Network error. Please check your internet connection."
             );

             break;


         case "auth/popup-closed-by-user":

             /*
              * No visible error.
              */

             break;


         case "auth/popup-blocked":

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "Google sign-in was blocked. Please allow the popup and try again."
             );

             break;


         case "auth/account-exists-with-different-credential":

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "An account already exists with this email. Please use the original sign-in method."
             );

             break;


         default:

             showFieldError(
                 emailInputBox,
                 emailMessage,
                 "Unable to sign in. Please check your details and try again."
             );

             break;
     }
 }


/* =========================================================
    EMAIL VALIDATION
 ========================================================= */

 function validateEmail() {

     const email =
         emailInput?.value
             ?.trim()
             ?.toLowerCase() || "";


     if (!email) {

         showFieldError(
             emailInputBox,
             emailMessage,
             "Please enter your email address."
         );

         return false;
     }


     if (!isValidEmail(email)) {

         showFieldError(
             emailInputBox,
             emailMessage,
             "Please enter a valid email address."
         );

         return false;
     }


     clearFieldError(
         emailInputBox,
         emailMessage
     );


     return true;
 }


 function isValidEmail(email) {

     return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
         email
     );
 }


 /* =========================================================
    FIELD ERROR
 ========================================================= */

 function showFieldError(
     inputBox,
     messageElement,
     message
 ) {

     if (inputBox) {

         inputBox.classList.remove(
             "field-error",
             "error",
             "input-error"
         );


         /*
          * Restart CSS error animation.
          */

         void inputBox.offsetWidth;


         inputBox.classList.add(
             "field-error"
         );
     }


     if (messageElement) {

         messageElement.textContent =
             message;

         messageElement.style.color =
             "#dc3545";
     }
 }


 function clearFieldError(
     inputBox,
     messageElement
 ) {

     if (inputBox) {

         inputBox.classList.remove(
             "field-error",
             "error",
             "input-error"
         );
     }


     if (messageElement) {

         messageElement.textContent = "";

         messageElement.style.color = "";
     }
 }


 function clearAllErrors() {

     clearFieldError(
         emailInputBox,
         emailMessage
     );


     clearFieldError(
         passwordInputBox,
         passwordMessage
     );
 }


 /* =========================================================
    LOGIN LOADING
 ========================================================= */

 function setLoginLoading(
     isLoading
 ) {

     if (
         !loginButton ||
         !loginButtonText ||
         !loginLoader
     ) {
         return;
     }


     loginButton.disabled =
         isLoading;


     if (isLoading) {

         loginButton.classList.add(
             "is-loading"
         );


         loginButtonText.textContent =
             "Logging in...";


         loginLoader.hidden = false;

     } else {

         loginButton.classList.remove(
             "is-loading"
         );


         loginButtonText.textContent =
             "Login to Task Gullak";


         loginLoader.hidden = true;
     }
 }


 /* =========================================================
    GOOGLE LOADING
 ========================================================= */

 function setGoogleLoading(
     isLoading
 ) {

     if (!googleLoginButton) {
         return;
     }


     googleLoginButton.disabled =
         isLoading;


     if (isLoading) {

         if (
             !googleLoginButton.dataset
                 .originalText
         ) {

             googleLoginButton.dataset
                 .originalText =
                 googleLoginButton.innerHTML;
         }


         googleLoginButton.innerHTML =
             `<span class="google-loading-text">Signing in...</span>`;

     } else {

         if (
             googleLoginButton.dataset
                 .originalText
         ) {

             googleLoginButton.innerHTML =
                 googleLoginButton.dataset
                     .originalText;
         }
     }
 }


 /* =========================================================
    DELAY
 ========================================================= */

 function delay(milliseconds) {

     return new Promise(
         resolve =>
             setTimeout(
                 resolve,
                 milliseconds
             )
     );
 }


 /* =========================================================
    START APPLICATION
 ========================================================= */

 initializeLogin();