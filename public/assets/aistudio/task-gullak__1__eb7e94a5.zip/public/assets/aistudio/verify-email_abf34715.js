/* =========================================================
   TASK GULLAK — VERIFY-EMAIL.JS
   Firebase Email Verification
========================================================= */

import {
    onAuthStateChanged,
    sendEmailVerification,
    reload,
    signOut
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    auth
} from "../config.js";


/* =========================================================
   CONFIG
========================================================= */

const HOME_PAGE = "../../04-HOME/home.html";
const LOGIN_PAGE = "../LOGIN/login.html";

const RESEND_COOLDOWN = 60;


/* =========================================================
   DOM ELEMENTS
========================================================= */

const userEmail =
    document.getElementById("userEmail");

const emailDisplay =
    document.getElementById("emailDisplay");

const openGmailButton =
    document.getElementById("openGmailButton");

const resendButton =
    document.getElementById("resendButton");

const resendButtonText =
    document.getElementById("resendButtonText");

const resendButtonIcon =
    document.getElementById("resendButtonIcon");

const resendLoader =
    document.getElementById("resendLoader");

const checkVerificationButton =
    document.getElementById("checkVerificationButton");

const logoutButton =
    document.getElementById("logoutButton");

const statusBox =
    document.getElementById("verifyStatus");

const statusTitle =
    document.getElementById("verifyStatusTitle");

const statusMessage =
    document.getElementById("verifyStatusMessage");


/* =========================================================
   STATE
========================================================= */

let currentUser = null;

let resendInProgress = false;

let resendTimer = null;

let remainingSeconds = 0;

let pageInitialized = false;


/* =========================================================
   INITIALIZE
========================================================= */

function initializeVerifyEmail() {

    if (!auth) {

        console.error(
            "Task Gullak: Firebase Auth unavailable."
        );

        showStatus(
            "Authentication unavailable",
            "Task Gullak could not connect to Firebase Authentication.",
            "error"
        );

        disableActions();

        return;
    }


    setupButtons();

    listenForAuthState();


    console.log(
        "Task Gullak Verify Email initialized successfully."
    );
}


/* =========================================================
   AUTH STATE
========================================================= */

function listenForAuthState() {

    onAuthStateChanged(
        auth,
        async function (user) {

            /*
             * No logged-in user
             */

            if (!user) {

                currentUser = null;

                redirectToLogin();

                return;
            }


            currentUser = user;


            /*
             * Firebase user data can be refreshed
             * before checking verification status.
             */

            try {

                await reload(user);

            } catch (error) {

                console.warn(
                    "Task Gullak: Unable to refresh user.",
                    error
                );
            }


            /*
             * Reload may update the current user's
             * emailVerified state.
             */

            currentUser = auth.currentUser;


            if (!currentUser) {

                redirectToLogin();

                return;
            }


            /*
             * Already verified
             */

            if (currentUser.emailVerified) {

                showStatus(
                    "Email already verified",
                    "Your Task Gullak account is verified. Taking you to your dashboard.",
                    "success"
                );


                setTimeout(
                    function () {

                        redirectToHome();

                    },
                    900
                );


                return;
            }


            /*
             * Unverified user
             */

            showUserEmail();

            enableActions();

            pageInitialized = true;

        }
    );
}


/* =========================================================
   SHOW USER EMAIL
========================================================= */

function showUserEmail() {

    if (!userEmail) {
        return;
    }


    const email =
        currentUser?.email || "";


    if (!email) {

        userEmail.textContent =
            "Your registered email";

        return;
    }


    userEmail.textContent =
        email;
}


/* =========================================================
   BUTTON SETUP
========================================================= */

function setupButtons() {


    /* =====================================================
       OPEN GMAIL
    ====================================================== */

    if (openGmailButton) {

        openGmailButton.addEventListener(
            "click",
            function () {

                openGmail();

            }
        );
    }


    /* =====================================================
       RESEND
    ====================================================== */

    if (resendButton) {

        resendButton.addEventListener(
            "click",
            function () {

                resendVerificationEmail();

            }
        );
    }


    /* =====================================================
       CHECK VERIFICATION
    ====================================================== */

    if (checkVerificationButton) {

        checkVerificationButton.addEventListener(
            "click",
            function () {

                checkVerificationStatus();

            }
        );
    }


    /* =====================================================
       LOGOUT
    ====================================================== */

    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            function () {

                logoutUser();

            }
        );
    }
}


/* =========================================================
   OPEN GMAIL
========================================================= */

function openGmail() {

    /*
     * Gmail web is used instead of forcing
     * an app-specific deep link.
     *
     * This works reliably on mobile browsers.
     */

    window.open(
        "https://mail.google.com/",
        "_blank",
        "noopener,noreferrer"
    );
}


/* =========================================================
   RESEND VERIFICATION EMAIL
========================================================= */

async function resendVerificationEmail() {

    if (!currentUser) {

        showStatus(
            "Session expired",
            "Please sign in again to continue.",
            "error"
        );

        return;
    }


    if (resendInProgress) {
        return;
    }


    if (remainingSeconds > 0) {

        showStatus(
            "Please wait",
            `You can request another verification email in ${remainingSeconds} seconds.`,
            "info"
        );

        return;
    }


    /*
     * Refresh user before sending.
     */

    try {

        await reload(currentUser);

        currentUser = auth.currentUser;

    } catch (error) {

        console.warn(
            "Task Gullak: User refresh failed.",
            error
        );
    }


    /*
     * User may have verified email
     * in another browser/device.
     */

    if (currentUser?.emailVerified) {

        showStatus(
            "Email already verified",
            "Your email has already been verified.",
            "success"
        );


        setTimeout(
            redirectToHome,
            700
        );

        return;
    }


    resendInProgress = true;

    setResendLoading(true);


    try {

        await sendEmailVerification(
            currentUser
        );


        showStatus(
            "Verification email sent",
            "A new verification link has been sent. Please check your inbox and spam folder.",
            "success"
        );


        startResendCooldown();


    } catch (error) {

        console.error(
            "Task Gullak Verification Email Error:",
            error
        );


        handleVerificationError(error);

    } finally {

        resendInProgress = false;

        setResendLoading(false);

    }
}


/* =========================================================
   CHECK VERIFICATION
========================================================= */

async function checkVerificationStatus() {

    if (!currentUser) {

        showStatus(
            "Session expired",
            "Please sign in again to continue.",
            "error"
        );

        return;
    }


    if (checkVerificationButton) {

        checkVerificationButton.disabled = true;

    }


    showStatus(
        "Checking verification",
        "We're checking your email verification status...",
        "info"
    );


    try {

        /*
         * IMPORTANT:
         * reload() fetches the latest Firebase user
         * state from the server.
         */

        await reload(
            currentUser
        );


        currentUser =
            auth.currentUser;


        if (
            currentUser &&
            currentUser.emailVerified
        ) {

            showStatus(
                "Email verified successfully",
                "Your Task Gullak account is now verified. Welcome aboard!",
                "success"
            );


            setTimeout(
                function () {

                    redirectToHome();

                },
                900
            );


            return;
        }


        /*
         * Still unverified
         */

        showStatus(
            "Email not verified yet",
            "Please open the verification email and click the verification link, then try again.",
            "info"
        );


    } catch (error) {

        console.error(
            "Task Gullak Verification Check Error:",
            error
        );


        handleVerificationError(
            error
        );

    } finally {

        if (checkVerificationButton) {

            checkVerificationButton.disabled = false;

        }
    }
}


/* =========================================================
   RESEND COOLDOWN
========================================================= */

function startResendCooldown() {

    clearResendCooldown();


    remainingSeconds =
        RESEND_COOLDOWN;


    updateResendButton();


    resendTimer =
        setInterval(
            function () {

                remainingSeconds--;


                if (
                    remainingSeconds <= 0
                ) {

                    clearResendCooldown();

                    return;
                }


                updateResendButton();

            },
            1000
        );
}


/* =========================================================
   UPDATE COOLDOWN UI
========================================================= */

function updateResendButton() {

    if (!resendButton) {
        return;
    }


    if (remainingSeconds > 0) {

        resendButton.disabled = true;


        if (resendButtonText) {

            resendButtonText.textContent =
                `Resend available in ${remainingSeconds}s`;

        }


        if (resendButtonIcon) {

            resendButtonIcon.style.display =
                "none";

        }

    } else {

        resendButton.disabled = false;


        if (resendButtonText) {

            resendButtonText.textContent =
                "Resend Verification Email";

        }


        if (resendButtonIcon) {

            resendButtonIcon.style.display =
                "inline-flex";

        }
    }
}


/* =========================================================
   CLEAR COOLDOWN
========================================================= */

function clearResendCooldown() {

    if (resendTimer) {

        clearInterval(
            resendTimer
        );

        resendTimer = null;
    }


    remainingSeconds = 0;

    updateResendButton();
}


/* =========================================================
   RESEND LOADING
========================================================= */

function setResendLoading(
    isLoading
) {

    if (!resendButton) {
        return;
    }


    resendButton.disabled =
        isLoading ||
        remainingSeconds > 0;


    if (isLoading) {

        resendButton.classList.add(
            "is-loading"
        );


        if (resendButtonText) {

            resendButtonText.textContent =
                "Sending verification email...";

        }


        if (resendButtonIcon) {

            resendButtonIcon.style.display =
                "none";

        }


        if (resendLoader) {

            resendLoader.hidden = false;

        }

    } else {

        resendButton.classList.remove(
            "is-loading"
        );


        if (resendLoader) {

            resendLoader.hidden = true;

        }


        if (remainingSeconds <= 0) {

            if (resendButtonText) {

                resendButtonText.textContent =
                    "Resend Verification Email";

            }


            if (resendButtonIcon) {

                resendButtonIcon.style.display =
                    "inline-flex";

            }

            resendButton.disabled = false;
        }
    }
}


/* =========================================================
   ERROR HANDLING
========================================================= */

function handleVerificationError(
    error
) {

    const code =
        error?.code || "";


    switch (code) {


        /* ================================================
           TOO MANY REQUESTS
        ================================================= */

        case "auth/too-many-requests":

            showStatus(
                "Too many requests",
                "Too many verification emails were requested. Please wait a while before trying again.",
                "error"
            );

            break;


        /* ================================================
           NETWORK
        ================================================= */

        case "auth/network-request-failed":

            showStatus(
                "Connection problem",
                "Please check your Internet connection and try again.",
                "error"
            );

            break;


        /* ================================================
           USER DISABLED
        ================================================= */

        case "auth/user-disabled":

            showStatus(
                "Account unavailable",
                "This account is currently unavailable. Please contact Task Gullak support.",
                "error"
            );

            disableActions();

            break;


        /* ================================================
           USER NOT FOUND
        ================================================= */

        case "auth/user-not-found":

            showStatus(
                "Session expired",
                "Your account session could not be found. Please sign in again.",
                "error"
            );

            setTimeout(
                redirectToLogin,
                1200
            );

            break;


        /* ================================================
           UNAUTHORIZED DOMAIN
        ================================================= */

        case "auth/unauthorized-domain":

            showStatus(
                "Domain not authorized",
                "This website address is not authorized in Firebase Authentication.",
                "error"
            );

            break;


        /* ================================================
           INVALID API KEY
        ================================================= */

        case "auth/invalid-api-key":

        case "auth/api-key-not-valid.-please-pass-a-valid-api-key.":

            showStatus(
                "Firebase configuration error",
                "Task Gullak could not connect to Firebase Authentication. Please check the Firebase Web API key.",
                "error"
            );

            break;


        /* ================================================
           OPERATION NOT ALLOWED
        ================================================= */

        case "auth/operation-not-allowed":

            showStatus(
                "Verification unavailable",
                "Email verification is currently unavailable in Firebase Authentication.",
                "error"
            );

            break;


        /* ================================================
           DEFAULT
        ================================================= */

        default:

            showStatus(
                "Something went wrong",
                "We couldn't complete the verification request. Please try again.",
                "error"
            );

            break;
    }
}


/* =========================================================
   STATUS MESSAGE
========================================================= */

function showStatus(
    title,
    message,
    type = "info"
) {

    if (!statusBox) {
        return;
    }


    if (statusTitle) {

        statusTitle.textContent =
            title;
    }


    if (statusMessage) {

        statusMessage.textContent =
            message;
    }


    statusBox.classList.remove(
        "success",
        "error",
        "info"
    );


    statusBox.classList.add(
        type
    );


    statusBox.hidden = false;
}


/* =========================================================
   HIDE STATUS
========================================================= */

function hideStatus() {

    if (!statusBox) {
        return;
    }


    statusBox.hidden = true;


    statusBox.classList.remove(
        "success",
        "error",
        "info"
    );
}


/* =========================================================
   DISABLE ACTIONS
========================================================= */

function disableActions() {

    if (openGmailButton) {

        openGmailButton.disabled = true;

    }


    if (resendButton) {

        resendButton.disabled = true;

    }


    if (checkVerificationButton) {

        checkVerificationButton.disabled = true;

    }
}


/* =========================================================
   ENABLE ACTIONS
========================================================= */

function enableActions() {

    if (openGmailButton) {

        openGmailButton.disabled = false;

    }


    if (resendButton) {

        resendButton.disabled =
            remainingSeconds > 0;

    }


    if (checkVerificationButton) {

        checkVerificationButton.disabled = false;

    }
}


/* =========================================================
   REDIRECT TO LOGIN
========================================================= */

function redirectToLogin() {

    window.location.replace(
        LOGIN_PAGE
    );
}


/* =========================================================
   REDIRECT TO HOME
========================================================= */

function redirectToHome() {

    window.location.replace(
        HOME_PAGE
    );
}


/* =========================================================
   LOGOUT
========================================================= */

async function logoutUser() {

    if (!auth) {
        return;
    }


    if (logoutButton) {

        logoutButton.disabled = true;

    }


    try {

        await signOut(
            auth
        );


        window.location.replace(
            LOGIN_PAGE
        );


    } catch (error) {

        console.error(
            "Task Gullak Logout Error:",
            error
        );


        showStatus(
            "Unable to sign out",
            "Something went wrong while signing out. Please try again.",
            "error"
        );


        if (logoutButton) {

            logoutButton.disabled = false;

        }
    }
}


/* =========================================================
   PAGE CLEANUP
========================================================= */

window.addEventListener(
    "beforeunload",
    function () {

        clearResendCooldown();

    }
);


/* =========================================================
   START
========================================================= */

initializeVerifyEmail();