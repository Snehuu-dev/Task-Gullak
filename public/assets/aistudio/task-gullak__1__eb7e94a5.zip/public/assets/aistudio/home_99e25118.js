/* =========================================================
   TASK GULLAK — HOME.JS  (04-HOME)
   Wallet, task summary, welcome card.
   Profile (photo / naam edit) ab alag page par hoga (11-PROFILE).
   Bottom nav: ../15-SHARED/navigation.js (HTML mein classic script)
========================================================= */

import {
  db,
  doc,
  getDoc,
  setDoc,
  onSnapshot,
  serverTimestamp,
  collection,
  query,
  where,
  limit,
  watchVerifiedUser
} from "../15-SHARED/firebase-service.js";

import { COLLECTIONS, PATHS, TASK_RULES } from "../15-SHARED/constants.js";
import { formatCount, formatDecimal } from "../15-SHARED/formatters.js";


/* =========================================================
   1. CONFIG + DOM HELPERS
========================================================= */

const CONFIG = {
  LOGIN_PAGE: PATHS.LOGIN,
  VERIFY_EMAIL_PAGE: PATHS.VERIFY_EMAIL,
  WALLET_PAGE: PATHS.WALLET,
  PROFILE_PAGE: PATHS.PROFILE,
  NOTIFICATIONS_PAGE: PATHS.NOTIFICATIONS,

  PROFILE_COLLECTION: COLLECTIONS.USERS,
  SUBMISSION_COLLECTION: COLLECTIONS.SUBMISSIONS,
  MAX_SUBMISSIONS: TASK_RULES.MAX_SUBMISSIONS,

  HOME_ENTRY_KEY: "tg_home_entry_animation"
};

const reduceMotion = window.matchMedia(
  "(prefers-reduced-motion: reduce)"
).matches;

const $ = id => document.getElementById(id);

function setText(id, value) {
  const node = $(id);
  if (node) node.textContent = value;
}

function on(id, event, callback) {
  const node = $(id);
  if (node) node.addEventListener(event, callback);
}

function setVh() {
  document.documentElement.style.setProperty(
    "--vh",
    `${window.innerHeight * 0.01}px`
  );
}

setVh();

window.addEventListener("resize", setVh);
window.addEventListener("orientationchange", setVh);


/* =========================================================
   2. NUMBER ANIMATION
========================================================= */

const easeOutExpo = p =>
  p >= 1 ? 1 : 1 - Math.pow(2, -10 * p);

function countTo(element, target, duration = 800, formatter = formatCount) {
  if (!element) return;

  cancelAnimationFrame(element._countRAF);

  const endValue = Number(target);

  if (!Number.isFinite(endValue)) {
    element.textContent = "0";
    return;
  }

  if (reduceMotion) {
    element.textContent = formatter(endValue);
    return;
  }

  const start = performance.now();

  function tick(now) {
    const progress = Math.min((now - start) / duration, 1);

    element.textContent = formatter(endValue * easeOutExpo(progress));

    if (progress < 1) {
      element._countRAF = requestAnimationFrame(tick);
    }
  }

  element._countRAF = requestAnimationFrame(tick);
}


/* =========================================================
   3. USER STATE + WELCOME CARD
========================================================= */

let currentUser = null;

let profile = {
  name: "",
  photoURL: null
};

let unsubscribeProfile = null;
let unsubscribeSubmissions = null;

let lastWalletBalance = null;
let submissionsLoaded = false;

function getFirstName() {
  const name = (profile.name || "").trim();

  return name
    ? name.split(/\s+/)[0]
    : "there";
}

/* Naam ka pehla letter — "Savvy" -> "S" */
function getInitial() {
  const name = (profile.name || "").trim();

  return name
    ? Array.from(name)[0].toUpperCase()
    : "";
}

/* Welcome card ka profile circle: photo ya naam ka pehla letter */
function renderHeaderPhoto() {
  const btn = $("headerProfilePhoto");
  const img = $("headerProfileImage");

  if (!btn || !img) return;

  const fallback = btn.querySelector(".header-profile-fallback");
  if (fallback) fallback.textContent = getInitial() || "👤";

  if (profile.photoURL) {
    if (img.getAttribute("src") !== profile.photoURL) {
      img.onerror = () => {
        img.hidden = true;
        btn.classList.remove("has-photo");
      };

      img.src = profile.photoURL;
    }

    img.hidden = false;
    btn.classList.add("has-photo");
  } else {
    img.hidden = true;
    img.removeAttribute("src");
    btn.classList.remove("has-photo");
  }
}

function renderWelcome() {
  renderHeaderPhoto();

  const firstName = profile.name ? getFirstName() : "";

  // "Let's grow your Gullak" gradient mein (HTML .grad),
  // user ka naam normal black mein (.user-name)
  setText("welcomeName", firstName ? `, ${firstName}!` : "");

  setText(
    "greetSub",
    firstName
      ? `${firstName}, every task adds to your savings.`
      : "Every completed task brings you one step closer to your goals."
  );
}


/* =========================================================
   4. LOCAL CACHE (page khulte hi turant data dikhane ke liye)
========================================================= */

const CACHE_KEY = "tg_home_cache_v1";

function readCache() {
  try {
    return JSON.parse(localStorage.getItem(CACHE_KEY)) || null;
  } catch {
    return null;
  }
}

function writeCache(part) {
  try {
    localStorage.setItem(
      CACHE_KEY,
      JSON.stringify({ ...(readCache() || {}), ...part })
    );
  } catch {
    /* storage blocked — ignore */
  }
}

function clearCache() {
  try {
    localStorage.removeItem(CACHE_KEY);
  } catch {
    /* ignore */
  }
}


/* =========================================================
   5. WALLET ID
   Firestore mein `walletId` field ho to wahi dikhega,
   warna display ke liye uid se TG-XXXXXXXX banta hai.
========================================================= */

function makeWalletId(uid) {
  return `TG-${String(uid || "").slice(0, 8).toUpperCase()}`;
}

function setWalletId(value) {
  setText("walletId", value || "TG-········");
}


/* =========================================================
   6. PROFILE DOCUMENT
========================================================= */

async function createMissingProfile(user) {
  const profileRef = doc(db, CONFIG.PROFILE_COLLECTION, user.uid);

  const snapshot = await getDoc(profileRef);

  if (snapshot.exists()) return snapshot.data();

  const newProfile = {
    uid: user.uid,
    name:
      user.displayName ||
      user.email?.split("@")[0] ||
      "User",

    email: user.email || "",
    photoURL: user.photoURL || null,

    walletBalance: 0,

    totalTasks: 0,
    pendingTasks: 0,
    approvedTasks: 0,
    rejectedTasks: 0,

    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };

  await setDoc(profileRef, newProfile);

  return newProfile;
}


/* =========================================================
   7. REAL-TIME USER PROFILE
========================================================= */

function listenToProfile(user) {
  if (unsubscribeProfile) {
    unsubscribeProfile();
    unsubscribeProfile = null;
  }

  const profileRef = doc(db, CONFIG.PROFILE_COLLECTION, user.uid);

  unsubscribeProfile = onSnapshot(
    profileRef,

    snapshot => {
      if (!snapshot.exists()) return;

      const data = snapshot.data();

      profile.name =
        data.name ||
        user.displayName ||
        user.email?.split("@")[0] ||
        "User";

      profile.photoURL =
        data.photoURL ||
        user.photoURL ||
        null;

      const walletId = data.walletId || makeWalletId(user.uid);

      renderWelcome();
      updateWallet(data.walletBalance);
      setWalletId(walletId);

      writeCache({
        uid: user.uid,
        name: profile.name,
        photoURL: profile.photoURL,
        wallet: Number(data.walletBalance),
        walletId
      });

      // Submissions abhi tak nahi aaye to user doc ke counts turant dikha do
      if (
        !submissionsLoaded &&
        Number.isFinite(Number(data.totalTasks))
      ) {
        updateSummary({
          pending: Number(data.pendingTasks) || 0,
          approved: Number(data.approvedTasks) || 0,
          rejected: Number(data.rejectedTasks) || 0
        });
      }
    },

    error => {
      console.error("Profile listener error:", error);
      showNotice("Profile data could not be loaded.");
    }
  );
}


/* =========================================================
   8. WALLET BALANCE
========================================================= */

const intEl = $("int");
const decEl = $("dec");

function updateWallet(value) {
  const balance = Number(value);

  if (!Number.isFinite(balance) || balance < 0) {
    setText("int", "—");
    setText("dec", ".––");
    return;
  }

  const [integerPart, decimalPart] = formatDecimal(balance).split(".");

  if (intEl) intEl.textContent = integerPart;
  if (decEl) decEl.textContent = `.${decimalPart}`;

  if (lastWalletBalance !== null) {
    const difference = balance - lastWalletBalance;

    if (difference > 0) {
      setText(
        "walletTrendText",
        `₹${formatDecimal(difference)} added to your wallet`
      );
    } else if (difference < 0) {
      setText("walletTrendText", "Wallet updated");
    }
  }

  lastWalletBalance = balance;
}


/* =========================================================
   9. TASK SUMMARY DONUT
========================================================= */

const NS = "http://www.w3.org/2000/svg";

const R_DONUT = 62;
const CIRC = 2 * Math.PI * R_DONUT;
const GAP = 12;

const segsEl = $("segs");
const legendEl = $("legend");
const sumCard = $("sumCard");
const cNum = $("cNum");

let selectedStat = null;
let stats = [];
let summaryKey = "";

function makeSpan(className) {
  const node = document.createElement("span");
  node.className = className;
  return node;
}

/* Loading skeleton + spinner ring on/off */
function setSummaryLoading(isLoading) {
  sumCard?.classList.toggle("is-loading", isLoading);
  legendEl?.setAttribute("aria-busy", String(isLoading));
}

/* Chalti hui count animation roko, warna wo naya total purane se overwrite kar deti hai */
function stopCountAnimation() {
  if (cNum) cancelAnimationFrame(cNum._countRAF);
}

/* Skeleton wapas dikhao (user badalne par) */
function showSummarySkeleton() {
  if (!segsEl || !legendEl) return;

  segsEl.replaceChildren();
  legendEl.replaceChildren();

  for (let i = 0; i < 3; i++) {
    const li = document.createElement("li");
    li.className = "sk-row";

    const text = makeSpan("sk-txt");
    text.append(makeSpan("sk sk-line"), makeSpan("sk sk-line sk-short"));

    li.append(makeSpan("sk sk-dot"), text, makeSpan("sk sk-num"));
    legendEl.appendChild(li);
  }

  stats = [];
  selectedStat = null;

  stopCountAnimation();

  if (cNum) {
    cNum.textContent = "—";
    cNum.style.color = "";
  }

  setText("cLabel", "Total Tasks");
  setSummaryLoading(true);
}

/* Summary load na ho paye to skeleton hamesha na atke */
function showSummaryError() {
  if (!segsEl || !legendEl) return;

  segsEl.replaceChildren();

  const li = document.createElement("li");
  li.className = "sum-error";
  li.textContent = "Task summary is unavailable right now.";

  legendEl.replaceChildren(li);

  stopCountAnimation();

  if (cNum) cNum.textContent = "—";

  setSummaryLoading(false);
}

function buildSummary(statsData, instant = false) {
  if (!segsEl || !legendEl) return;

  setSummaryLoading(false);
  stopCountAnimation();

  segsEl.replaceChildren();
  legendEl.replaceChildren();

  selectedStat = null;

  const colors = {
    pending: "#f5a524",
    approved: "#10b981",
    rejected: "#f43f5e"
  };

  stats = [
    { key: "pending", label: "Pending Review", value: Math.max(0, Number(statsData.pending) || 0), color: colors.pending },
    { key: "approved", label: "Approved", value: Math.max(0, Number(statsData.approved) || 0), color: colors.approved },
    { key: "rejected", label: "Rejected", value: Math.max(0, Number(statsData.rejected) || 0), color: colors.rejected }
  ];

  const total = stats.reduce((sum, item) => sum + item.value, 0);

  let start = 0;

  stats.forEach(item => {
    const fraction = total ? item.value / total : 0;

    item.len = Math.max(fraction * CIRC - GAP, 0);

    const circle = document.createElementNS(NS, "circle");

    circle.setAttribute("class", "seg");
    circle.setAttribute("cx", "80");
    circle.setAttribute("cy", "80");
    circle.setAttribute("r", String(R_DONUT));

    circle.style.stroke = item.color;
    circle.style.opacity = "1";
    circle.style.strokeDashoffset = String(-(start + GAP / 2));

    if (instant || reduceMotion) {
      circle.style.transition = "none";
      circle.style.strokeDasharray = `${item.len} ${CIRC}`;
    } else {
      circle.style.strokeDasharray = `0 ${CIRC}`;
    }

    segsEl.appendChild(circle);
    item.el = circle;

    start += fraction * CIRC;

    const li = document.createElement("li");

    const button = document.createElement("button");
    button.type = "button";
    button.className = "row";
    button.setAttribute("aria-pressed", "false");
    button.style.setProperty("--c", item.color);

    const dot = makeSpan("dot");
    const textWrap = makeSpan("txt");

    const name = makeSpan("name");
    name.textContent = item.label;

    const percent = makeSpan("pct");
    percent.textContent = `${Math.round(fraction * 100)}% of total`;

    const number = makeSpan("num");
    number.textContent = formatCount(item.value);

    textWrap.append(name, percent);
    button.append(dot, textWrap, number);
    li.appendChild(button);
    legendEl.appendChild(li);

    item.row = button;

    button.addEventListener("click", () => {
      selectStat(item.key);
    });
  });

  setText("cLabel", "Total Tasks");

  if (cNum) cNum.style.color = "";

  if (instant || reduceMotion) {
    if (cNum) cNum.textContent = formatCount(total);
    return;
  }

  countTo(cNum, total, 500);

  requestAnimationFrame(() => {
    stats.forEach((item, index) => {
      setTimeout(() => {
        if (item.el) {
          item.el.style.strokeDasharray = `${item.len} ${CIRC}`;
        }
      }, index * 70);
    });
  });
}

function updateSummary(data, instant = false) {
  const key = `${data.pending}|${data.approved}|${data.rejected}`;

  // Same data par dobara rebuild nahi — flicker band
  if (key === summaryKey) return;

  const alreadyShown = summaryKey !== "";
  summaryKey = key;

  buildSummary(data, instant || alreadyShown);
  writeCache({ summary: data });
}

function selectStat(key) {
  selectedStat = selectedStat === key ? null : key;

  const selected = stats.find(item => item.key === selectedStat);

  stats.forEach(item => {
    item.el?.classList.toggle(
      "dim",
      selectedStat !== null && item.key !== selectedStat
    );

    item.row?.setAttribute(
      "aria-pressed",
      String(item.key === selectedStat)
    );
  });

  setText("cLabel", selected ? selected.label : "Total Tasks");

  if (cNum) {
    cNum.style.color = selected ? selected.color : "";
  }

  countTo(
    cNum,
    selected
      ? selected.value
      : stats.reduce((sum, item) => sum + item.value, 0),
    600
  );
}

/* Page khulte hi cache se sab kuch turant dikhao */
function paintFromCache() {
  const cached = readCache();
  if (!cached) return;

  profile.name = cached.name || "";
  profile.photoURL = cached.photoURL || null;
  renderWelcome();

  if (Number.isFinite(cached.wallet)) {
    updateWallet(cached.wallet);
  }

  lastWalletBalance = null; // cache se "added" message na dikhe

  if (cached.walletId) {
    setWalletId(cached.walletId);
  } else if (cached.uid) {
    setWalletId(makeWalletId(cached.uid));
  }

  if (cached.summary) {
    updateSummary(cached.summary, true);
  }
}

paintFromCache();


/* =========================================================
   10. REAL-TIME SUBMISSION COUNTS
========================================================= */

function listenToSubmissions(user) {
  if (unsubscribeSubmissions) {
    unsubscribeSubmissions();
    unsubscribeSubmissions = null;
  }

  const submissionsQuery = query(
    collection(db, CONFIG.SUBMISSION_COLLECTION),
    where("userId", "==", user.uid),
    limit(CONFIG.MAX_SUBMISSIONS)
  );

  unsubscribeSubmissions = onSnapshot(
    submissionsQuery,

    snapshot => {
      let pending = 0;
      let approved = 0;
      let rejected = 0;

      snapshot.forEach(item => {
        const status = String(item.data().status || "").toLowerCase();

        if (status === "pending" || status === "submitted" || status === "under_review") {
          pending++;
        } else if (status === "approved") {
          approved++;
        } else if (status === "rejected" || status === "declined") {
          rejected++;
        }
      });

      submissionsLoaded = true;

      updateSummary({ pending, approved, rejected });
    },

    error => {
      console.error("Submission listener error:", error);

      // Kuch bhi dikhaya nahi gaya hai to error state dikhao (fake 0 nahi)
      if (summaryKey === "") {
        showSummaryError();
      }

      showNotice("Task summary could not be loaded.");
    }
  );
}


/* =========================================================
   11. START / STOP REAL-TIME LISTENERS
   Wallet balance user document se aata hai (trusted backend
   approval ke baad update karta hai). Browser se wallet credit
   nahi hota.
========================================================= */

/* Dusre user ka cached data screen par na rahe */
function resetHomeUI() {
  profile = { name: "", photoURL: null };
  renderWelcome();

  setText("int", "—");
  setText("dec", ".––");
  setText("walletTrendText", "Your approved rewards");
  setWalletId("");

  lastWalletBalance = null;
  summaryKey = "";
  submissionsLoaded = false;

  showSummarySkeleton();
}

function startRealtime(user) {
  currentUser = user;

  const cached = readCache();
  const sameUser = Boolean(cached && cached.uid === user.uid);

  if (cached && !sameUser) {
    clearCache();
    resetHomeUI();
  }

  writeCache({ uid: user.uid });

  // Real walletId cache mein ho to wahi rahe, warna uid se turant dikhao
  if (!(sameUser && cached.walletId)) {
    setWalletId(makeWalletId(user.uid));
  }

  // Signup ke naam ka pehla letter turant dikhao (Firestore ka wait nahi)
  if (!profile.name) {
    profile.name =
      user.displayName ||
      user.email?.split("@")[0] ||
      "";

    renderWelcome();
  }

  listenToProfile(user);
  listenToSubmissions(user);

  // Profile doc nahi hai to background mein bana do
  createMissingProfile(user).catch(error => {
    console.error("Profile create error:", error);
  });
}

function stopListeners() {
  unsubscribeProfile?.();
  unsubscribeSubmissions?.();

  unsubscribeProfile = null;
  unsubscribeSubmissions = null;
}

/* Back/forward cache se page wapas aaye to listeners dobara chalao */
function ensureListeners() {
  if (currentUser && !unsubscribeProfile) {
    startRealtime(currentUser);
  }
}


/* =========================================================
   12. BUTTONS (page navigation)
========================================================= */

on("notificationBtn", "click", () => {
  window.location.href = CONFIG.NOTIFICATIONS_PAGE;
});

on("goWallet", "click", () => {
  window.location.href = CONFIG.WALLET_PAGE;
});

/* Welcome card ka profile circle -> alag Profile page */
on("headerProfilePhoto", "click", () => {
  window.location.href = CONFIG.PROFILE_PAGE;
});


