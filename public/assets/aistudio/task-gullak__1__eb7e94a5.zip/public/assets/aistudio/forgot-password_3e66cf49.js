/* =========================================================
   TASK GULLAK — FORGOT-PASSWORD.JS
   Firebase Password Reset
   Login NOT Required
   Mobile Friendly • Secure
========================================================= */

import {
    sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    auth
} from "../config.js";


/* =========================================================
   DOM ELEMENTS
========================================================= */

const forgotForm =
    document.getElementById("forgotPasswordForm");

const emailInput =
    document.getElementById("emailInput");

const emailInputBox =
    document.getElementById("emailInputBox");

const emailMessage =
    document.getElementById("emailMessage");

const resetButton =
    document.getElementById("resetPasswordButton");

const resetButtonText =
    document.getElementById("resetButtonText");

const resetLoader =
    document.getElementById("resetLoader");

const statusBox =
    document.getElementById("forgotStatus");

const statusTitle =
    document.getElementById("forgotStatusTitle");

const statusMessage =
    document.getElementById("forgotStatusMessage");


/* =========================================================
   STATE
========================================================= */

let resetInProgress = false;


/* =========================================================
   INITIALIZE
========================================================= */

function initializeForgotPassword() {

    if (!forgotForm) {

        console.error(
            "Task Gullak: forgotPasswordForm not found."
        );

        return;
    }


    if (!auth) {

        console.error(
            "Task Gullak: Firebase Auth unavailable."
        );

        showStatus(
            "Authentication unavailable",
            "Task Gullak could not connect to Firebase Authentication.",
            "error"
        );

        return;
    }


    setupEmailInput();

    setupForm();


    console.log(
        "Task Gullak Forgot Password initialized successfully."
    );
}


/* =========================================================
   EMAIL INPUT
========================================================= */

function setupEmailInput() {

    if (!emailInput) {
        return;
    }


    /* INPUT */

    emailInput.addEventListener(
        "input",
        function () {

            clearEmailError();

            clearEmailSuccess();

            hideStatus();

        }
    );


    /* FOCUS */

    emailInput.addEventListener(
        "focus",
        function () {

            clearEmailError();

            clearEmailSuccess();

        }
    );


    /* BLUR */

    emailInput.addEventListener(
        "blur",
        function () {

            const email =
                emailInput.value
                    .trim()
                    .toLowerCase();


            if (!email) {
                return;
            }


            validateEmail();

        }
    );
}


/* =========================================================
   FORM
========================================================= */

function setupForm() {

    forgotForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            if (resetInProgress) {
                return;
            }


            const email =
                emailInput?.value
                    ?.trim()
                    ?.toLowerCase() || "";


            clearEmailError();

            clearEmailSuccess();

            hideStatus();


            /* EMPTY */

            if (!email) {

                showEmailError(
                    "Please enter your email address."
                );

                emailInput?.focus();

                return;
            }


            /* INVALID */

            if (!isValidEmail(email)) {

                showEmailError(
                    "Please enter a valid email address."
                );


                showStatus(
                    "Invalid email address",
                    "Please check the email address and enter a valid email.",
                    "error"
                );


                emailInput?.focus();

                return;
            }


            /* VALID */

            await sendResetEmail(email);

        }
    );
}


/* =========================================================
   SEND RESET EMAIL
========================================================= */

async function sendResetEmail(email) {

    resetInProgress = true;

    setLoading(true);


    try {

        /*
         * IMPORTANT:
         *
         * User does NOT need to be logged in.
         *
         * Firebase handles password reset
         * and sends the email automatically.
         */

        await sendPasswordResetEmail(
            auth,
            email
        );


        /* SUCCESS */

        showEmailSuccess();


        showStatus(
            "Reset link sent successfully",
            "Please check your inbox and spam folder for the password reset email.",
            "success"
        );


        /*
         * Clear email after successful request.
         */

        if (emailInput) {
            emailInput.value = "";
        }


    } catch (error) {

        console.error(
            "Task Gullak Password Reset Error:",
            error
        );


        handleResetError(error);

    } finally {

        resetInProgress = false;

        setLoading(false);

    }
}


/* =========================================================
   FIREBASE ERROR HANDLING
========================================================= */

function handleResetError(error) {

    const code =
        error?.code || "";


    clearEmailError();

    clearEmailSuccess();


    switch (code) {


        /* =================================================
           EMAIL NOT REGISTERED
        ================================================= */

        case "auth/user-not-found":

            /*
             * Do not reveal whether an account exists.
             *
             * This prevents account enumeration.
             */

            showStatus(
                "Check your email",
                "If an account exists with this email, a password reset link will be sent.",
                "info"
            );

            break;


        /* =================================================
           INVALID EMAIL
        ================================================= */

        case "auth/invalid-email":

            showEmailError(
                "Please enter a valid email address."
            );


            showStatus(
                "Invalid email address",
                "Please check the email address and try again.",
                "error"
            );

            break;


        /* =================================================
           TOO MANY REQUESTS
        ================================================= */

        case "auth/too-many-requests":

            showStatus(
                "Too many requests",
                "Too many password reset requests were made. Please wait a while and try again.",
                "error"
            );

            break;


        /* =================================================
           NETWORK ERROR
        ================================================= */

        case "auth/network-request-failed":

            showStatus(
                "Connection problem",
                "Please check your Internet connection and try again.",
                "error"
            );

            break;


        /* =================================================
           API KEY ERROR
        ================================================= */

        case "auth/invalid-api-key":

        case "auth/api-key-not-valid.-please-pass-a-valid-api-key.":

            showStatus(
                "Firebase configuration error",
                "Task Gullak could not connect to Firebase Authentication. Please check the Firebase Web API key.",
                "error"
            );

            break;


        /* =================================================
           OPERATION NOT ALLOWED
        ================================================= */

        case "auth/operation-not-allowed":

            showStatus(
                "Password reset unavailable",
                "Password reset is currently unavailable in Firebase Authentication.",
                "error"
            );

            break;


        /* =================================================
           UNAUTHORIZED DOMAIN
        ================================================= */

        case "auth/unauthorized-domain":

            showStatus(
                "Domain not authorized",
                "This website address is not authorized in Firebase Authentication.",
                "error"
            );

            break;


        /* =================================================
           USER DISABLED
        ================================================= */

        case "auth/user-disabled":

            showStatus(
                "Account unavailable",
                "This account is currently unavailable. Please contact Task Gullak support.",
                "error"
            );

            break;


        /* =================================================
           DEFAULT
        ================================================= */

        default:

            showStatus(
                "Unable to send reset link",
                "Something went wrong. Please check your email and try again.",
                "error"
            );

            break;
    }
}


/* =========================================================
   VALIDATE EMAIL
========================================================= */

function validateEmail() {

    const email =
        emailInput?.value
            ?.trim()
            ?.toLowerCase() || "";


    clearEmailError();

    clearEmailSuccess();


    if (!email) {

        showEmailError(
            "Please enter your email address."
        );

        return false;
    }


    if (!isValidEmail(email)) {

        showEmailError(
            "Please enter a valid email address."
        );

        return false;
    }


    showEmailSuccess();

    return true;
}


/* =========================================================
   EMAIL REGEX
========================================================= */

function isValidEmail(email) {

    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        email
    );
}


/* =========================================================
   SHOW EMAIL ERROR
========================================================= */

function showEmailError(message) {

    if (emailInputBox) {

        emailInputBox.classList.remove(
            "field-success"
        );


        emailInputBox.classList.remove(
            "field-error"
        );


        /*
         * Restart CSS state cleanly.
         */

        void emailInputBox.offsetWidth;


        emailInputBox.classList.add(
            "field-error"
        );
    }


    if (emailMessage) {

        emailMessage.textContent =
            message;

        emailMessage.style.color =
            "#dc465b";
    }
}


/* =========================================================
   SHOW EMAIL SUCCESS
========================================================= */

function showEmailSuccess() {

    if (emailInputBox) {

        emailInputBox.classList.remove(
            "field-error"
        );


        emailInputBox.classList.add(
            "field-success"
        );
    }


    if (emailMessage) {

        emailMessage.textContent =
            "Email address looks good.";

        emailMessage.style.color =
            "#16a34a";
    }
}


/* =========================================================
   CLEAR EMAIL ERROR
========================================================= */

function clearEmailError() {

    if (emailInputBox) {

        emailInputBox.classList.remove(
            "field-error"
        );
    }


    if (emailMessage) {

        /*
         * Only clear if it currently
         * belongs to an error state.
         */

        if (
            emailInputBox &&
            !emailInputBox.classList.contains(
                "field-success"
            )
        ) {

            emailMessage.textContent = "";

            emailMessage.style.color = "";
        }
    }
}


/* =========================================================
   CLEAR EMAIL SUCCESS
========================================================= */

function clearEmailSuccess() {

    if (emailInputBox) {

        emailInputBox.classList.remove(
            "field-success"
        );
    }


    if (emailMessage) {

        emailMessage.textContent = "";

        emailMessage.style.color = "";
    }
}


/* =========================================================
   STATUS MESSAGE
========================================================= */

function showStatus(
    title,
    message,
    type = "info"
) {

    if (!statusBox) {
        return;
    }


    if (statusTitle) {

        statusTitle.textContent =
            title;
    }


    if (statusMessage) {

        statusMessage.textContent =
            message;
    }


    statusBox.classList.remove(
        "success",
        "error",
        "info"
    );


    statusBox.classList.add(
        type
    );


    statusBox.hidden = false;
}


/* =========================================================
   HIDE STATUS
========================================================= */

function hideStatus() {

    if (!statusBox) {
        return;
    }


    statusBox.hidden = true;


    statusBox.classList.remove(
        "success",
        "error",
        "info"
    );
}


/* =========================================================
   BUTTON LOADING
========================================================= */

function setLoading(isLoading) {

    if (!resetButton) {
        return;
    }


    resetButton.disabled =
        isLoading;


    if (isLoading) {

        resetButton.classList.add(
            "is-loading"
        );


        if (resetButtonText) {

            resetButtonText.textContent =
                "Sending reset link...";
        }


        if (resetLoader) {

            resetLoader.hidden = false;
        }

    } else {

        resetButton.classList.remove(
            "is-loading"
        );


        if (resetButtonText) {

            resetButtonText.textContent =
                "Send Reset Link →";
        }


        if (resetLoader) {

            resetLoader.hidden = true;
        }
    }
}


/* =========================================================
   START APPLICATION
========================================================= */

initializeForgotPassword();