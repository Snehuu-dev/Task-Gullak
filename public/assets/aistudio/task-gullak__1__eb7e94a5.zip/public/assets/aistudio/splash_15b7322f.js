/* =========================================================
   TASK GULLAK 0.2 — SPLASH CONTROLLER
   Splash → Firebase Auth Check → Correct Destination
========================================================= */

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    auth
} from "../03-AUTH/config.js";


/* =========================================================
   CONFIGURATION
========================================================= */

const CONFIG = {
    ONBOARDING_COMPLETED_KEY: "tg_onboarding_completed",

    ONBOARDING_PAGE: "../02-ONBOARDING/onboarding.html",
    LOGIN_PAGE: "../03-AUTH/LOGIN/login.html",
    VERIFY_EMAIL_PAGE: "../03-AUTH/VERIFY-EMAIL/verify-email.html",
    HOME_PAGE: "../04-HOME/home.html",

    SPLASH_DURATION: 5200,
    COIN_SOUND_DELAY: 3150,
    EXIT_DURATION: 700,

    // Used by Home to identify entry from the splash screen.
    HOME_ENTRY_KEY: "tg_home_entry_animation"
};


/* =========================================================
   ELEMENTS
========================================================= */

const splashScreen = document.getElementById("splashScreen");
const coinSound = document.getElementById("coinSound");


/* =========================================================
   STATE
========================================================= */

let splashStarted = false;
let splashExited = false;

let authResolved = false;
let authUser = null;

let soundTimer = null;
let splashTimer = null;
let exitTimer = null;

let authPromise = null;


/* =========================================================
   ONBOARDING STATUS
========================================================= */

function hasCompletedOnboarding() {
    try {
        return (
            localStorage.getItem(
                CONFIG.ONBOARDING_COMPLETED_KEY
            ) === "true"
        );
    } catch (error) {
        console.warn(
            "Unable to read onboarding status:",
            error
        );

        return false;
    }
}


/* =========================================================
   AUTHENTICATION
========================================================= */

function initializeAuthListener() {
    if (authPromise) {
        return authPromise;
    }

    authPromise = new Promise((resolve) => {
        let settled = false;
        let unsubscribe = null;

        const finish = (user) => {
            if (settled) return;

            settled = true;

            authUser = user || null;
            authResolved = true;

            if (unsubscribe) {
                unsubscribe();
                unsubscribe = null;
            }

            resolve(authUser);
        };

        try {
            unsubscribe = onAuthStateChanged(
                auth,

                (user) => {
                    finish(user);
                },

                (error) => {
                    console.error(
                        "Firebase authentication error:",
                        error
                    );

                    finish(null);
                }
            );

        } catch (error) {
            console.error(
                "Unable to initialize Firebase authentication:",
                error
            );

            finish(null);
        }
    });

    return authPromise;
}


/* =========================================================
   DESTINATION ROUTING
========================================================= */

async function getNextPage() {
    if (!authResolved) {
        await initializeAuthListener();
    }

    /*
       No signed-in user:
       Onboarding → Login
    */

    if (!authUser) {
        if (!hasCompletedOnboarding()) {
            return CONFIG.ONBOARDING_PAGE;
        }

        return CONFIG.LOGIN_PAGE;
    }

    /*
       Refresh account details before routing.
    */

    try {
        await authUser.reload();

    } catch (error) {
        console.warn(
            "Unable to refresh user details:",
            error
        );
    }

    const currentUser = auth.currentUser;

    if (!currentUser) {
        if (!hasCompletedOnboarding()) {
            return CONFIG.ONBOARDING_PAGE;
        }

        return CONFIG.LOGIN_PAGE;
    }

    /*
       Password-based accounts require verified email.
       Google sign-in does not use this password check.
    */

    const isPasswordUser =
        currentUser.providerData?.some(
            (provider) =>
                provider.providerId === "password"
        ) || false;

    if (
        isPasswordUser &&
        !currentUser.emailVerified
    ) {
        return CONFIG.VERIFY_EMAIL_PAGE;
    }

    /*
       Authenticated and eligible user → Home
    */

    try {
        sessionStorage.setItem(
            CONFIG.HOME_ENTRY_KEY,
            "true"
        );
    } catch (error) {
        console.warn(
            "Unable to save Home entry animation flag:",
            error
        );
    }

    return CONFIG.HOME_PAGE;
}


/* =========================================================
   LUCIDE ICONS
========================================================= */

function initializeIcons() {
    if (
        typeof lucide === "undefined" ||
        typeof lucide.createIcons !== "function"
    ) {
        return false;
    }

    try {
        lucide.createIcons();
        return true;

    } catch (error) {
        console.warn(
            "Unable to initialize Lucide icons:",
            error
        );

        return false;
    }
}


function waitForIcons() {
    let attempts = 0;
    const maxAttempts = 30;

    const iconTimer = setInterval(() => {
        attempts++;

        if (
            initializeIcons() ||
            attempts >= maxAttempts
        ) {
            clearInterval(iconTimer);
        }
    }, 100);
}


/* =========================================================
   COIN SOUND
========================================================= */

function playCoinSound() {
    if (!coinSound || splashExited) return;

    try {
        coinSound.pause();
        coinSound.currentTime = 0;
        coinSound.volume = 0.45;

        const playPromise = coinSound.play();

        if (
            playPromise &&
            typeof playPromise.catch === "function"
        ) {
            playPromise.catch(() => {
                // Browsers may block autoplay.
            });
        }

    } catch (error) {
        console.warn(
            "Coin sound could not play:",
            error
        );
    }
}


function scheduleCoinSound() {
    clearTimeout(soundTimer);

    soundTimer = setTimeout(() => {
        soundTimer = null;

        if (!splashExited) {
            playCoinSound();
        }

    }, CONFIG.COIN_SOUND_DELAY);
}


function stopCoinSound() {
    if (!coinSound) return;

    try {
        coinSound.pause();
        coinSound.currentTime = 0;

    } catch (error) {
        console.warn(
            "Unable to stop coin sound:",
            error
        );
    }
}


/* =========================================================
   TIMER CLEANUP
========================================================= */

function clearTimers() {
    if (soundTimer !== null) {
        clearTimeout(soundTimer);
        soundTimer = null;
    }

    if (splashTimer !== null) {
        clearTimeout(splashTimer);
        splashTimer = null;
    }

    if (exitTimer !== null) {
        clearTimeout(exitTimer);
        exitTimer = null;
    }
}


/* =========================================================
   EXIT SPLASH
========================================================= */

async function exitSplash() {
    if (splashExited) return;

    splashExited = true;

    clearTimers();
    stopCoinSound();

    if (splashScreen) {
        splashScreen.classList.add("is-exiting");
    }

    /*
       Wait for the existing CSS exit transition.
    */

    exitTimer = setTimeout(async () => {
        exitTimer = null;

        try {
            const nextPage = await getNextPage();

            window.location.replace(nextPage);

        } catch (error) {
            console.error(
                "Unable to determine the next page:",
                error
            );

            window.location.replace(
                CONFIG.LOGIN_PAGE
            );
        }

    }, CONFIG.EXIT_DURATION);
}


/* =========================================================
   START SPLASH
========================================================= */

function startSplash() {
    if (splashStarted || !splashScreen) return;

    splashStarted = true;

    initializeIcons();
    waitForIcons();

    /*
       Start authentication checking immediately.
       Do not wait until the animation finishes.
    */

    initializeAuthListener();

    /*
       Preserve the existing animation and sound timing.
    */

    scheduleCoinSound();

    splashTimer = setTimeout(() => {
        splashTimer = null;
        exitSplash();

    }, CONFIG.SPLASH_DURATION);
}


/* =========================================================
   INITIALIZATION
========================================================= */

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        startSplash,
        { once: true }
    );

} else {
    startSplash();
}


/* =========================================================
   SAFETY FALLBACK
========================================================= */

const safetyTimer = setTimeout(() => {
    if (!splashExited && splashScreen) {
        exitSplash();
    }

}, CONFIG.SPLASH_DURATION + 2500);


/* =========================================================
   PAGE VISIBILITY & CLEANUP
========================================================= */

document.addEventListener(
    "visibilitychange",
    () => {
        if (document.hidden) {
            stopCoinSound();
        }
    }
);


window.addEventListener(
    "pagehide",
    () => {
        clearTimers();
        clearTimeout(safetyTimer);
        stopCoinSound();
    },
    { once: true }
);