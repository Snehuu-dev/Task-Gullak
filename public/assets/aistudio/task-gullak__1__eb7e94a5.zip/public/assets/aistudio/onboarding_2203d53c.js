/* =========================================================
   TASK GULLAK — ONBOARDING CONTROLLER
   ========================================================= */

"use strict";

/* CONFIGURATION */
const CONFIG = {
    LOGIN_PAGE: "../03-AUTH/LOGIN/login.html",
    SWIPE_THRESHOLD: 50,
    ANIMATION_DURATION: 500,

    // UI preference only — NOT authentication/session data
    ONBOARDING_COMPLETED_KEY: "tg_onboarding_completed"
};


/* DOM ELEMENTS */

const onboarding =
    document.getElementById("onboarding");

const slides =
    Array.from(
        document.querySelectorAll(".onboarding-slide")
    );

const dots =
    Array.from(
        document.querySelectorAll(".progress-dot")
    );

const nextButton =
    document.getElementById("nextButton");

const backButton =
    document.getElementById("backButton");

const skipButton =
    document.getElementById("skipButton");

const brandLink =
    document.getElementById("brandLink");


/* STATE MANAGEMENT */

let currentSlide = 0;

let isAnimating = false;

let touchStartX = 0;
let touchStartY = 0;

let touchEndX = 0;
let touchEndY = 0;


/* =========================================================
   ONBOARDING COMPLETION
   ========================================================= */

/*
   This stores ONLY whether the onboarding UI
   has already been completed.

   It does NOT store:
   - Firebase token
   - password
   - user UID
   - login session
   - authentication credentials
*/

function isOnboardingCompleted() {
    return (
        localStorage.getItem(
            CONFIG.ONBOARDING_COMPLETED_KEY
        ) === "true"
    );
}


function markOnboardingCompleted() {

    try {

        localStorage.setItem(
            CONFIG.ONBOARDING_COMPLETED_KEY,
            "true"
        );

    } catch (error) {

        console.warn(
            "Task Gullak: Could not save onboarding state.",
            error
        );
    }
}


/* =========================================================
   LUCIDE ICONS
   ========================================================= */

function refreshIcons() {

    if (
        typeof window.lucide === "undefined" ||
        typeof window.lucide.createIcons !== "function"
    ) {
        return;
    }

    try {

        window.lucide.createIcons();

    } catch (error) {

        console.warn(
            "Task Gullak: Lucide initialization failed.",
            error
        );
    }
}


function waitForIcons() {

    let attempts = 0;

    const maxAttempts = 30;

    const iconTimer =
        window.setInterval(() => {

            attempts++;

            refreshIcons();

            if (
                typeof window.lucide !== "undefined" ||
                attempts >= maxAttempts
            ) {

                window.clearInterval(
                    iconTimer
                );
            }

        }, 100);
}


/* =========================================================
   UI STATE UPDATER
   ========================================================= */

function updateSlides() {

    if (!slides.length) {
        return;
    }


    /* UPDATE SLIDES */

    slides.forEach(
        (slide, index) => {

            const isActive =
                index === currentSlide;

            slide.classList.toggle(
                "active",
                isActive
            );

            slide.classList.toggle(
                "previous",
                index < currentSlide
            );

            slide.setAttribute(
                "aria-hidden",
                String(!isActive)
            );
        }
    );


    /* UPDATE DOTS */

    dots.forEach(
        (dot, index) => {

            const isActive =
                index === currentSlide;

            dot.classList.toggle(
                "active",
                isActive
            );

            dot.classList.toggle(
                "completed",
                index < currentSlide
            );

            dot.setAttribute(
                "aria-selected",
                String(isActive)
            );
        }
    );


    /* BACK BUTTON */

    if (backButton) {

        const isFirstSlide =
            currentSlide === 0;

        backButton.disabled =
            isFirstSlide;

        backButton.setAttribute(
            "aria-disabled",
            String(isFirstSlide)
        );
    }


    /* NEXT BUTTON */

    if (nextButton) {

        const isLastSlide =
            currentSlide === slides.length - 1;

        const buttonText =
            nextButton.querySelector(
                ".button-text"
            );


        if (buttonText) {

            buttonText.textContent =
                isLastSlide
                    ? "Get Started"
                    : "Next";
        }


        nextButton.setAttribute(
            "aria-label",
            isLastSlide
                ? "Get started"
                : "Next slide"
        );
    }


    refreshIcons();
}


/* =========================================================
   SLIDE NAVIGATION
   ========================================================= */

function goToSlide(targetIndex) {

    if (
        isAnimating ||
        !slides.length
    ) {
        return;
    }


    if (
        targetIndex < 0 ||
        targetIndex >= slides.length ||
        targetIndex === currentSlide
    ) {
        return;
    }


    const previousIndex =
        currentSlide;

    const movingForward =
        targetIndex > previousIndex;


    isAnimating = true;


    const previousSlide =
        slides[previousIndex];

    const targetSlide =
        slides[targetIndex];


    if (previousSlide) {

        previousSlide.classList.remove(
            "slide-out-left",
            "slide-out-right"
        );

        previousSlide.classList.add(
            movingForward
                ? "slide-out-left"
                : "slide-out-right"
        );
    }


    currentSlide =
        targetIndex;


    if (targetSlide) {

        targetSlide.classList.remove(
            "slide-in-left",
            "slide-in-right"
        );

        targetSlide.classList.add(
            movingForward
                ? "slide-in-right"
                : "slide-in-left"
        );
    }


    updateSlides();


    window.setTimeout(
        () => {

            slides.forEach(
                (slide) => {

                    slide.classList.remove(
                        "slide-out-left",
                        "slide-out-right",
                        "slide-in-left",
                        "slide-in-right"
                    );
                }
            );


            isAnimating = false;

        },
        CONFIG.ANIMATION_DURATION
    );
}


function nextSlide() {

    if (isAnimating) {
        return;
    }


    if (
        currentSlide ===
        slides.length - 1
    ) {

        finishOnboarding();

        return;
    }


    goToSlide(
        currentSlide + 1
    );
}


function previousSlide() {

    if (
        isAnimating ||
        currentSlide <= 0
    ) {
        return;
    }


    goToSlide(
        currentSlide - 1
    );
}


/* =========================================================
   FLOW REDIRECTIONS
   ========================================================= */

/*
   GET STARTED

   User reached the final onboarding slide
   and clicked Get Started.

   Mark onboarding as completed.
*/

function finishOnboarding() {

    markOnboardingCompleted();

    window.location.replace(
        CONFIG.LOGIN_PAGE
    );
}


/*
   SKIP

   User intentionally skipped onboarding.

   Mark onboarding as completed so it does
   not appear again on future visits.
*/

function skipOnboarding() {

    markOnboardingCompleted();

    window.location.replace(
        CONFIG.LOGIN_PAGE
    );
}


/* =========================================================
   EVENT HANDLERS
   ========================================================= */

function handleDotClick(event) {

    const targetIndex =
        dots.indexOf(
            event.currentTarget
        );


    if (targetIndex !== -1) {

        goToSlide(
            targetIndex
        );
    }
}


function handleDotKeydown(event) {

    if (
        event.key === "Enter" ||
        event.key === " "
    ) {

        event.preventDefault();


        const targetIndex =
            dots.indexOf(
                event.currentTarget
            );


        if (targetIndex !== -1) {

            goToSlide(
                targetIndex
            );
        }
    }
}


/* =========================================================
   TOUCH / SWIPE
   ========================================================= */

function handleTouchStart(event) {

    if (
        !event.touches ||
        !event.touches.length
    ) {
        return;
    }


    touchStartX =
        event.touches[0].clientX;

    touchStartY =
        event.touches[0].clientY;

    touchEndX =
        touchStartX;

    touchEndY =
        touchStartY;
}


function handleTouchMove(event) {

    if (
        !event.touches ||
        !event.touches.length
    ) {
        return;
    }


    touchEndX =
        event.touches[0].clientX;

    touchEndY =
        event.touches[0].clientY;
}


function handleTouchEnd() {

    const deltaX =
        touchEndX - touchStartX;

    const deltaY =
        touchEndY - touchStartY;


    /* Ignore vertical scrolling */

    if (
        Math.abs(deltaY) >
        Math.abs(deltaX)
    ) {
        return;
    }


    /* Ignore small gestures */

    if (
        Math.abs(deltaX) <
        CONFIG.SWIPE_THRESHOLD
    ) {
        return;
    }


    if (deltaX < 0) {

        nextSlide();

    } else {

        previousSlide();
    }
}


/* =========================================================
   KEYBOARD
   ========================================================= */

function handleKeyboard(event) {

    const activeElement =
        document.activeElement;

    const tagName =
        activeElement?.tagName;


    if (
        [
            "INPUT",
            "TEXTAREA",
            "SELECT"
        ].includes(tagName)
    ) {
        return;
    }


    switch (event.key) {

        case "ArrowRight":

            event.preventDefault();

            nextSlide();

            break;


        case "ArrowLeft":

            event.preventDefault();

            previousSlide();

            break;


        case "Enter":

            if (
                tagName !== "BUTTON"
            ) {

                event.preventDefault();

                nextSlide();
            }

            break;


        case "Escape":

            event.preventDefault();

            skipOnboarding();

            break;
    }
}


/* =========================================================
   BUTTON INITIALIZATION
   ========================================================= */

function initializeButtons() {

    if (nextButton) {

        nextButton.addEventListener(
            "click",
            nextSlide
        );
    }


    if (backButton) {

        backButton.addEventListener(
            "click",
            previousSlide
        );
    }


    if (skipButton) {

        skipButton.addEventListener(
            "click",
            skipOnboarding
        );
    }


    if (brandLink) {

        brandLink.addEventListener(
            "click",
            (event) => {

                event.preventDefault();
            }
        );
    }
}


/* =========================================================
   DOT INITIALIZATION
   ========================================================= */

function initializeDots() {

    dots.forEach(
        (dot) => {

            dot.addEventListener(
                "click",
                handleDotClick
            );


            dot.addEventListener(
                "keydown",
                handleDotKeydown
            );


            dot.setAttribute(
                "role",
                "tab"
            );


            dot.setAttribute(
                "tabindex",
                "0"
            );
        }
    );
}


/* =========================================================
   TOUCH INITIALIZATION
   ========================================================= */

function initializeTouch() {

    if (!onboarding) {
        return;
    }


    onboarding.addEventListener(
        "touchstart",
        handleTouchStart,
        { passive: true }
    );


    onboarding.addEventListener(
        "touchmove",
        handleTouchMove,
        { passive: true }
    );


    onboarding.addEventListener(
        "touchend",
        handleTouchEnd,
        { passive: true }
    );
}


/* =========================================================
   KEYBOARD INITIALIZATION
   ========================================================= */

function initializeKeyboard() {

    document.addEventListener(
        "keydown",
        handleKeyboard
    );
}


/* =========================================================
   INITIALIZE ONBOARDING
   ========================================================= */

function initializeOnboarding() {

    if (!onboarding) {

        console.error(
            "Task Gullak: #onboarding container not found. Check onboarding.html."
        );

        return;
    }


    if (!slides.length) {

        console.error(
            "Task Gullak: No .onboarding-slide elements found."
        );

        return;
    }


    /*
     * IMPORTANT:
     *
     * This file is normally opened only when
     * Core decides onboarding is required.
     *
     * If somebody directly opens onboarding.html
     * after completing it, redirect to Login.
     */

    if (isOnboardingCompleted()) {

        window.location.replace(
            CONFIG.LOGIN_PAGE
        );

        return;
    }


    currentSlide = 0;

    isAnimating = false;


    updateSlides();

    initializeButtons();

    initializeDots();

    initializeTouch();

    initializeKeyboard();

    waitForIcons();

    refreshIcons();
}


/* =========================================================
   BOOTSTRAP
   ========================================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeOnboarding,
        { once: true }
    );

} else {

    initializeOnboarding();
}