import {
    checkActionCode,
    applyActionCode,
    onAuthStateChanged,
    reload,
    signOut
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import { auth } from "../config.js";

/* =========================================================
   TASK GULLAK — EMAIL ACTION
   email-action.js
   ========================================================= */


/* =========================================================
   CONFIG
   ========================================================= */

const LOGIN_PAGE = "../LOGIN/login.html";
const VERIFY_EMAIL_PAGE = "../VERIFY-EMAIL/verify-email.html";
const HOME_PAGE = "../../04-HOME/home.html";


/* =========================================================
   DOM
   ========================================================= */

const actionIcon = document.getElementById("actionIcon");

const loadingIcon = document.getElementById("loadingIcon");
const successIcon = document.getElementById("successIcon");
const errorIcon = document.getElementById("errorIcon");

const actionBadge = document.getElementById("actionBadge");
const badgeDot = document.getElementById("badgeDot");
const badgeText = document.getElementById("badgeText");

const actionTitle = document.getElementById("actionTitle");
const actionMessage = document.getElementById("actionMessage");

const actionInfo = document.getElementById("actionInfo");
const actionEmail = document.getElementById("actionEmail");

const actionStatus = document.getElementById("actionStatus");
const statusTitle = document.getElementById("statusTitle");
const statusMessage = document.getElementById("statusMessage");

const continueButton = document.getElementById("continueButton");
const loginButton = document.getElementById("loginButton");


/* =========================================================
   STATE
   ========================================================= */

let actionCompleted = false;
let currentActionEmail = null;
let safeContinueUrl = null;


/* =========================================================
   INITIALIZATION
   ========================================================= */

console.log("Task Gullak Email Action initialized successfully.");


/* =========================================================
   URL PARAMETERS
   ========================================================= */

const urlParams = new URLSearchParams(window.location.search);

const mode = urlParams.get("mode");
const oobCode = urlParams.get("oobCode");
const continueUrl = urlParams.get("continueUrl");


/* =========================================================
   SAFE CONTINUE URL
   ========================================================= */

function getSafeContinueUrl(value) {

    if (!value) {
        return null;
    }

    try {

        const parsedUrl = new URL(value, window.location.origin);

        /*
         * Only allow redirects back to the same website.
         * This prevents an external/open redirect.
         */

        if (parsedUrl.origin !== window.location.origin) {
            return null;
        }

        /*
         * Do not allow javascript: or other dangerous schemes.
         */

        if (parsedUrl.protocol !== "http:" &&
            parsedUrl.protocol !== "https:") {
            return null;
        }

        return parsedUrl.href;

    } catch (error) {

        console.warn(
            "Task Gullak: Invalid continueUrl ignored.",
            error
        );

        return null;
    }
}


safeContinueUrl = getSafeContinueUrl(continueUrl);


/* =========================================================
   UI HELPERS
   ========================================================= */

function setStatus(title, message, type = "info") {

    if (!actionStatus) {
        return;
    }

    actionStatus.hidden = false;

    actionStatus.classList.remove(
        "success",
        "error",
        "info"
    );

    actionStatus.classList.add(type);

    statusTitle.textContent = title;
    statusMessage.textContent = message;
}


function hideStatus() {

    if (!actionStatus) {
        return;
    }

    actionStatus.hidden = true;

    actionStatus.classList.remove(
        "success",
        "error",
        "info"
    );
}


function setLoadingState() {

    actionIcon.classList.remove(
        "success",
        "error"
    );

    actionIcon.classList.add("loading");

    loadingIcon.style.display = "block";
    successIcon.style.display = "none";
    errorIcon.style.display = "none";

    actionBadge.classList.remove(
        "success",
        "error"
    );

    badgeDot.style.background = "";
    badgeText.textContent = "Verifying Email";

    actionTitle.textContent = "Verifying Your Email";

    actionMessage.textContent =
        "Please wait while we securely verify your email address.";

    continueButton.hidden = true;
    loginButton.hidden = true;

    hideStatus();
}


function setSuccessState() {

    actionIcon.classList.remove(
        "loading",
        "error"
    );

    actionIcon.classList.add("success");

    loadingIcon.style.display = "none";
    successIcon.style.display = "block";
    errorIcon.style.display = "none";

    badgeText.textContent = "Email Verified";

    actionTitle.textContent = "Email Verified!";

    actionMessage.textContent =
        "Your email address has been successfully verified with Task Gullak.";

    setStatus(
        "Verification successful",
        "Your Task Gullak account is now email verified.",
        "success"
    );

    continueButton.hidden = false;

    continueButton.querySelector("span:last-child").textContent =
        "Continue to Task Gullak";

    loginButton.hidden = true;
}


function setErrorState(title, message) {

    actionIcon.classList.remove(
        "loading",
        "success"
    );

    actionIcon.classList.add("error");

    loadingIcon.style.display = "none";
    successIcon.style.display = "none";
    errorIcon.style.display = "block";

    badgeText.textContent = "Verification Failed";

    actionTitle.textContent = title;

    actionMessage.textContent =
        "We couldn't complete your email verification.";

    setStatus(
        title,
        message,
        "error"
    );

    continueButton.hidden = true;
    loginButton.hidden = false;
}


function setAlreadyVerifiedState() {

    actionIcon.classList.remove(
        "loading",
        "error"
    );

    actionIcon.classList.add("success");

    loadingIcon.style.display = "none";
    successIcon.style.display = "block";
    errorIcon.style.display = "none";

    badgeText.textContent = "Already Verified";

    actionTitle.textContent = "Email Already Verified";

    actionMessage.textContent =
        "This email address has already been verified with Task Gullak.";

    setStatus(
        "Already verified",
        "You can continue to your Task Gullak account.",
        "success"
    );

    continueButton.hidden = false;
    loginButton.hidden = false;

    continueButton.querySelector("span:last-child").textContent =
        "Continue to Task Gullak";
}


/* =========================================================
   DISPLAY EMAIL
   ========================================================= */

function displayEmail(email) {

    if (!actionEmail) {
        return;
    }

    if (!email) {

        actionEmail.textContent =
            "Task Gullak account";

        return;
    }

    currentActionEmail = email;

    actionEmail.textContent = email;
}


/* =========================================================
   FIREBASE ERROR HANDLING
   ========================================================= */

function handleFirebaseError(error) {

    console.error(
        "Task Gullak Email Action Firebase error:",
        error
    );

    const code = error?.code || "";


    /* -----------------------------------------------------
       Invalid / expired / already-used verification link
       ----------------------------------------------------- */

    if (
        code === "auth/invalid-action-code" ||
        code === "auth/expired-action-code"
    ) {

        setErrorState(
            "Verification Link Expired",
            "This verification link is invalid or has expired. Please request a new verification email."
        );

        return;
    }


    /* -----------------------------------------------------
       Too many requests
       ----------------------------------------------------- */

    if (code === "auth/too-many-requests") {

        setErrorState(
            "Too Many Attempts",
            "Too many verification attempts were made. Please wait a little and try again."
        );

        return;
    }


    /* -----------------------------------------------------
       Network
       ----------------------------------------------------- */

    if (code === "auth/network-request-failed") {

        setErrorState(
            "Connection Problem",
            "Unable to connect to Firebase. Please check your internet connection and try again."
        );

        return;
    }


    /* -----------------------------------------------------
       Unauthorized domain
       ----------------------------------------------------- */

    if (code === "auth/unauthorized-continue-uri") {

        setErrorState(
            "Website Not Authorized",
            "This Task Gullak website address is not authorized in Firebase Authentication."
        );

        return;
    }


    /* -----------------------------------------------------
       API key
       ----------------------------------------------------- */

    if (code === "auth/api-key-not-valid") {

        setErrorState(
            "Firebase Configuration Error",
            "The Firebase API key is invalid or unavailable. Please check the Firebase configuration."
        );

        return;
    }


    /* -----------------------------------------------------
       Default
       ----------------------------------------------------- */

    setErrorState(
        "Verification Failed",
        "We couldn't verify this email right now. Please request a new verification email and try again."
    );
}


/* =========================================================
   CHECK ACTION CODE
   ========================================================= */

async function validateActionCode() {

    if (!oobCode) {

        setErrorState(
            "Invalid Verification Link",
            "This verification link is incomplete or invalid."
        );

        return null;
    }

    try {

        const actionInfo =
            await checkActionCode(auth, oobCode);

        /*
         * Firebase returns the account email
         * associated with the action code.
         */

        if (
            actionInfo &&
            actionInfo.data &&
            actionInfo.data.email
        ) {

            displayEmail(
                actionInfo.data.email
            );
        }

        return actionInfo;

    } catch (error) {

        handleFirebaseError(error);

        return null;
    }
}


/* =========================================================
   APPLY EMAIL VERIFICATION
   ========================================================= */

async function verifyEmailAction() {

    if (!oobCode) {

        setErrorState(
            "Invalid Verification Link",
            "The verification code is missing from this link."
        );

        return;
    }


    try {

        /*
         * First validate the action code.
         */

        const actionInfo =
            await checkActionCode(auth, oobCode);


        /*
         * Show the email associated with
         * this Firebase verification action.
         */

        if (
            actionInfo &&
            actionInfo.data &&
            actionInfo.data.email
        ) {

            displayEmail(
                actionInfo.data.email
            );
        }


        /*
         * This is the actual Firebase operation
         * that marks the email as verified.
         */

        await applyActionCode(
            auth,
            oobCode
        );


        actionCompleted = true;

        setSuccessState();

        console.log(
            "Task Gullak: Email verification completed successfully."
        );


    } catch (error) {

        /*
         * If the code was already consumed,
         * Firebase can return invalid-action-code.
         *
         * In that case we check whether the current
         * signed-in account is already verified.
         */

        if (
            error?.code === "auth/invalid-action-code" &&
            auth.currentUser
        ) {

            try {

                await reload(
                    auth.currentUser
                );

                if (
                    auth.currentUser.emailVerified
                ) {

                    actionCompleted = true;

                    setAlreadyVerifiedState();

                    return;
                }

            } catch (reloadError) {

                console.warn(
                    "Task Gullak: Unable to confirm existing verification.",
                    reloadError
                );
            }
        }

        handleFirebaseError(error);
    }
}


/* =========================================================
   CONTINUE BUTTON
   ========================================================= */

continueButton.addEventListener(
    "click",
    async () => {

        if (!actionCompleted) {
            return;
        }


        /*
         * If the user is already signed in,
         * refresh Firebase Auth state first.
         */

        if (auth.currentUser) {

            try {

                await reload(
                    auth.currentUser
                );

            } catch (error) {

                console.warn(
                    "Task Gullak: Unable to reload current user.",
                    error
                );
            }


            if (auth.currentUser) {

                /*
                 * Verified account can continue.
                 */

                if (auth.currentUser.emailVerified) {

                    window.location.href =
                        safeContinueUrl ||
                        HOME_PAGE;

                    return;
                }
            }
        }


        /*
         * If there is no active session,
         * go to login.
         */

        window.location.href =
            LOGIN_PAGE;
    }
);


/* =========================================================
   LOGIN BUTTON
   ========================================================= */

loginButton.addEventListener(
    "click",
    async () => {

        try {

            /*
             * We intentionally don't keep
             * authentication tokens in localStorage.
             */

            if (auth.currentUser) {

                await signOut(auth);
            }

        } catch (error) {

            console.warn(
                "Task Gullak: Sign out before login failed.",
                error
            );

        } finally {

            window.location.href =
                LOGIN_PAGE;
        }
    }
);


/* =========================================================
   INITIAL ROUTING
   ========================================================= */

async function initializeEmailAction() {

    setLoadingState();


    /* -----------------------------------------------------
       Only email verification is supported here.
       ----------------------------------------------------- */

    if (mode !== "verifyEmail") {

        setErrorState(
            "Invalid Action",
            "This link is not a Task Gullak email verification link."
        );

        return;
    }


    /*
     * Validate first so we can show the
     * email address before applying the action.
     */

    const actionInfo =
        await validateActionCode();


    if (!actionInfo) {
        return;
    }


    /*
     * Now perform the actual verification.
     */

    await verifyEmailAction();
}


/* =========================================================
   OPTIONAL AUTH STATE OBSERVER
   ========================================================= */

onAuthStateChanged(
    auth,
    (user) => {

        if (!user) {
            return;
        }

        console.log(
            "Task Gullak: Auth state available for email action."
        );
    }
);


/* =========================================================
   START
   ========================================================= */

initializeEmailAction();