/* =========================================================
   TASK GULLAK — SIGNUP.JS
   Firebase Authentication (Strict Complex Password & Name Length)
========================================================= */

import {
    createUserWithEmailAndPassword,
    updateProfile,
    sendEmailVerification,
    signInWithPopup,
    signInWithRedirect,
    getRedirectResult,
    signOut
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

import {
    auth,
    googleProvider
} from "../config.js";

/* DOM ELEMENTS */
const signupForm = document.getElementById("signupForm");
const nameInput = document.getElementById("nameInput");
const nameInputBox = document.getElementById("nameInputBox");
const nameMessage = document.getElementById("nameMessage");

const emailInput = document.getElementById("emailInput");
const emailInputBox = document.getElementById("emailInputBox");
const emailMessage = document.getElementById("emailMessage");

const passwordInput = document.getElementById("passwordInput");
const passwordInputBox = document.getElementById("passwordInputBox");
const passwordMessage = document.getElementById("passwordMessage");
const passwordToggle = document.getElementById("passwordToggle");
const eyeClosed = document.getElementById("eyeClosed");
const eyeOpen = document.getElementById("eyeOpen");

const confirmPasswordInput = document.getElementById("confirmPasswordInput");
const confirmPasswordInputBox = document.getElementById("confirmPasswordInputBox");
const confirmPasswordMessage = document.getElementById("confirmPasswordMessage");
const confirmPasswordToggle = document.getElementById("confirmPasswordToggle");
const confirmEyeClosed = document.getElementById("confirmEyeClosed");
const confirmEyeOpen = document.getElementById("confirmEyeOpen");

const termsCheckbox = document.getElementById("termsCheckbox");
const termsMessage = document.getElementById("termsMessage");

const signupButton = document.getElementById("signupButton");
const signupButtonText = document.getElementById("signupButtonText");
const signupLoader = document.getElementById("signupLoader");
const googleSignupButton = document.getElementById("googleSignupButton");

const LOGIN_PAGE = "../LOGIN/login.html";
const HOME_PAGE = "../../04-HOME/home.html";

let signupInProgress = false;
let googleSignupInProgress = false;

/* INITIALIZE */
function initializeSignup() {
    if (!signupForm || !auth) return;

    setupPasswordToggles();
    setupInputValidation();
    setupSignupForm();
    setupGoogleSignup();
    handleGoogleRedirectResult();
}

/* PASSWORD SHOW/HIDE TOGGLE WITH WORKING ICON SWITCH */
function setupPasswordToggles() {
    if (passwordInput && passwordToggle) {
        passwordToggle.addEventListener("click", function (e) {
            e.preventDefault();
            const isPassword = passwordInput.type === "password";
            passwordInput.type = isPassword ? "text" : "password";

            if (eyeClosed && eyeOpen) {
                if (isPassword) {
                    eyeClosed.classList.remove("active");
                    eyeOpen.classList.add("active");
                } else {
                    eyeOpen.classList.remove("active");
                    eyeClosed.classList.add("active");
                }
            }
            passwordInput.focus();
        });
    }

    if (confirmPasswordInput && confirmPasswordToggle) {
        confirmPasswordToggle.addEventListener("click", function (e) {
            e.preventDefault();
            const isPassword = confirmPasswordInput.type === "password";
            confirmPasswordInput.type = isPassword ? "text" : "password";

            if (confirmEyeClosed && confirmEyeOpen) {
                if (isPassword) {
                    confirmEyeClosed.classList.remove("active");
                    confirmEyeOpen.classList.add("active");
                } else {
                    confirmEyeOpen.classList.remove("active");
                    confirmEyeClosed.classList.add("active");
                }
            }
            confirmPasswordInput.focus();
        });
    }
}

/* REAL-TIME VALIDATION CLEAR */
function setupInputValidation() {
    if (nameInput) {
        nameInput.addEventListener("input", () => clearFieldError(nameInputBox, nameMessage));
    }
    if (emailInput) {
        emailInput.addEventListener("input", () => clearFieldError(emailInputBox, emailMessage));
    }
    if (passwordInput) {
        passwordInput.addEventListener("input", () => clearFieldError(passwordInputBox, passwordMessage));
    }
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener("input", () => clearFieldError(confirmPasswordInputBox, confirmPasswordMessage));
    }
    if (termsCheckbox) {
        termsCheckbox.addEventListener("change", () => clearFieldError(null, termsMessage));
    }
}

/* SPECIFIC PASSWORD COMPLEXITY CHECK */
function checkPasswordComplexity(password) {
    if (password.length < 12) {
        return "Password must be at least 12 characters long.";
    }
    if (!/[A-Z]/.test(password)) {
        return "Password must contain at least one uppercase letter (A-Z).";
    }
    if (!/[a-z]/.test(password)) {
        return "Password must contain at least one lowercase letter (a-z).";
    }
    if (!/[0-9]/.test(password)) {
        return "Password must contain at least one number (0-9).";
    }
    if (!/[@$!%*?&]/.test(password)) {
        return "Password must contain at least one special character (@, $, !, %, *, ?, &).";
    }
    return null;
}

/* FORM SUBMIT VALIDATIONS */
function setupSignupForm() {
    signupForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        if (signupInProgress) return;

        const name = nameInput?.value?.trim() || "";
        const email = emailInput?.value?.trim()?.toLowerCase() || "";
        const password = passwordInput?.value || "";
        const confirmPassword = confirmPasswordInput?.value || "";
        const isTermsAccepted = termsCheckbox?.checked || false;

        clearAllErrors();

        // 1. Name Check (Minimum 5 Characters)
        if (!name || name.length < 5) {
            showFieldError(nameInputBox, nameMessage, "Full name must be at least 5 characters long.");
            nameInput?.focus();
            return;
        }

        // 2. Email Validation
        if (!email || !isValidEmail(email)) {
            showFieldError(emailInputBox, emailMessage, "Please enter a valid email address.");
            emailInput?.focus();
            return;
        }

        // 3. Strict Specific Password Complexity Check
        const passwordError = checkPasswordComplexity(password);
        if (passwordError) {
            showFieldError(passwordInputBox, passwordMessage, passwordError);
            passwordInput?.focus();
            return;
        }

        // 4. Confirm Password Match Check
        if (!confirmPassword || password !== confirmPassword) {
            showFieldError(confirmPasswordInputBox, confirmPasswordMessage, "Passwords do not match.");
            confirmPasswordInput?.focus();
            return;
        }

        // 5. Mandatory Checkbox Check
        if (!isTermsAccepted) {
            showFieldError(
                null,
                termsMessage,
                "You must agree to the Terms of Service and Privacy Policy to create an account."
            );
            return;
        }

        await registerUserWithEmail(name, email, password);
    });
}

/* FIREBASE REGISTER USER */
async function registerUserWithEmail(name, email, password) {
    signupInProgress = true;
    setSignupLoading(true);

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;

        await updateProfile(user, { displayName: name });

        try {
            await sendEmailVerification(user);
        } catch (vErr) {
            console.warn("Could not send verification email:", vErr);
        }

        await signOut(auth);

        alert("Account created successfully! Please check your email to verify before logging in.");
        window.location.href = LOGIN_PAGE;

    } catch (error) {
        handleFirebaseSignupError(error);
    } finally {
        signupInProgress = false;
        setSignupLoading(false);
    }
}

/* GOOGLE OAUTH */
function setupGoogleSignup() {
    if (!googleSignupButton) return;

    googleSignupButton.addEventListener("click", async function () {
        if (googleSignupInProgress || signupInProgress) return;

        googleSignupInProgress = true;
        setGoogleLoading(true);
        clearAllErrors();

        try {
            const result = await signInWithPopup(auth, googleProvider);
            if (result?.user) {
                localStorage.setItem("tg_has_ever_logged_in", "true");
                window.location.href = HOME_PAGE;
            }
        } catch (error) {
            if (error?.code === "auth/popup-blocked") {
                await signInWithRedirect(auth, googleProvider);
            } else {
                handleFirebaseSignupError(error);
            }
        } finally {
            googleSignupInProgress = false;
            setGoogleLoading(false);
        }
    });
}

async function handleGoogleRedirectResult() {
    try {
        const result = await getRedirectResult(auth);
        if (result?.user) {
            localStorage.setItem("tg_has_ever_logged_in", "true");
            window.location.href = HOME_PAGE;
        }
    } catch (error) {
        handleFirebaseSignupError(error);
    }
}

/* FIREBASE ERRORS */
function handleFirebaseSignupError(error) {
    const code = error?.code || "";
    clearAllErrors();

    if (code === "auth/email-already-in-use") {
        showFieldError(emailInputBox, emailMessage, "This email is already registered. Please log in.");
    } else if (code === "auth/invalid-email") {
        showFieldError(emailInputBox, emailMessage, "Invalid email address format.");
    } else if (code === "auth/weak-password") {
        showFieldError(passwordInputBox, passwordMessage, "Password is too weak.");
    } else {
        showFieldError(emailInputBox, emailMessage, "Unable to register. Please check details.");
    }
}

/* HELPERS */
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showFieldError(inputBox, messageElement, message) {
    if (inputBox) {
        inputBox.classList.add("field-error");
    }
    if (messageElement) {
        messageElement.textContent = message;
    }
}

function clearFieldError(inputBox, messageElement) {
    if (inputBox) {
        inputBox.classList.remove("field-error");
    }
    if (messageElement) {
        messageElement.textContent = "";
    }
}

function clearAllErrors() {
    clearFieldError(nameInputBox, nameMessage);
    clearFieldError(emailInputBox, emailMessage);
    clearFieldError(passwordInputBox, passwordMessage);
    clearFieldError(confirmPasswordInputBox, confirmPasswordMessage);
    clearFieldError(null, termsMessage);
}

function setSignupLoading(isLoading) {
    if (!signupButton || !signupButtonText || !signupLoader) return;
    signupButton.disabled = isLoading;
    signupButtonText.textContent = isLoading ? "Creating Account..." : "Create Account with Task Gullak";
    signupLoader.hidden = !isLoading;
}

function setGoogleLoading(isLoading) {
    if (!googleSignupButton) return;
    googleSignupButton.disabled = isLoading;
    googleSignupButton.innerHTML = isLoading ? `<span class="google-loading-text">Signing up...</span>` : `Sign up with Google`;
}

initializeSignup();
