package com.example.taskgullak.screens

import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.taskgullak.components.CssGridOverlay
import com.example.taskgullak.components.Floating3DOrb
import com.example.taskgullak.components.ShinyGradientButton
import com.example.taskgullak.theme.InterFontFamily
import com.example.taskgullak.theme.PoppinsFontFamily
import com.example.taskgullak.theme.TgActionOrange
import com.example.taskgullak.theme.TgActionPink
import com.example.taskgullak.theme.TgAuthError
import com.example.taskgullak.theme.TgOrangeEnd
import com.example.taskgullak.theme.TgOrangePrimary
import com.example.taskgullak.theme.TgOrangeStart
import com.example.taskgullak.theme.TgVerifySuccess
import com.example.taskgullak.theme.TgVerifySuccessDark
import com.example.taskgullak.theme.TgWarmTextMain
import com.example.taskgullak.theme.TgWarmTextMuted
import com.example.taskgullak.theme.TgWarmTextSoft
import com.example.data.remote.FirebaseEmailDispatchService
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val EMAIL_CHECK_REGEX = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")

/**
 * Exact 100% UI replica of forgot-password.html + forgot-password.css + forgot-password.js
 */
@Composable
fun ForgotPasswordScreen(
    initialEmail: String = "",
    onBackToLogin: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var email by remember { mutableStateOf(initialEmail) }
    var fieldMessage by remember { mutableStateOf<String?>(null) }
    var isFieldSuccess by remember { mutableStateOf(false) }

    var statusTitle by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusType by remember { mutableStateOf("info") } // "success", "error", "info"

    var isLoading by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "forgotFloat")
    val logoOffsetY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logoOffsetY"
    )

    fun handleSendResetLink() {
        if (isLoading) return
        val cleanEmail = email.trim().lowercase()
        fieldMessage = null
        isFieldSuccess = false
        statusTitle = null

        if (cleanEmail.isEmpty()) {
            fieldMessage = "Please enter your email address."
            isFieldSuccess = false
            return
        }
        if (!EMAIL_CHECK_REGEX.matches(cleanEmail)) {
            fieldMessage = "Please enter a valid email address."
            isFieldSuccess = false
            statusTitle = "Invalid email address"
            statusMessage = "Please check the email address and enter a valid email."
            statusType = "error"
            return
        }

        isLoading = true
        coroutineScope.launch {
            try {
                val result = FirebaseEmailDispatchService.sendPasswordResetLinkEmail(
                    context = context,
                    rawEmail = cleanEmail
                )
                isFieldSuccess = result.success
                fieldMessage = if (result.success) "Email address looks good." else result.title
                statusTitle = result.title
                statusMessage = result.message
                statusType = result.statusType
                if (result.success) {
                    email = ""
                }
            } finally {
                isLoading = false
            }
        }
    }

    WarmOrangeBackground(testTag = "forgot_password_screen") {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            // FORGOT PASSWORD CARD (.forgot-card)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .shadow(
                        elevation = 18.dp,
                        shape = RoundedCornerShape(32.dp),
                        ambientColor = TgOrangePrimary.copy(alpha = 0.12f),
                        spotColor = TgOrangePrimary.copy(alpha = 0.16f)
                    )
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color.White.copy(alpha = 0.86f))
                    .border(1.5.dp, TgOrangePrimary.copy(alpha = 0.20f), RoundedCornerShape(32.dp))
            ) {
                // Bold Gradient Top Line (.card-top-line)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.5.dp)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(TgOrangeStart, TgOrangePrimary, TgOrangeEnd)
                            )
                        )
                )

                // Soft decorative side circles (.circle-left, .circle-right)
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .offset(x = (-35).dp, y = (-20).dp)
                        .size(70.dp)
                        .clip(CircleShape)
                        .background(TgOrangePrimary.copy(alpha = 0.08f))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = 35.dp, y = (-60).dp)
                        .size(70.dp)
                        .clip(CircleShape)
                        .background(TgOrangePrimary.copy(alpha = 0.08f))
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 22.dp, end = 22.dp, top = 28.dp, bottom = 34.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // 3D ILLUSTRATION (.auth-illustration-container)
                    Image(
                        painter = painterResource(id = R.drawable.img_forgot_password),
                        contentDescription = "Forgot Password Illustration",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(145.dp)
                            .offset(y = logoOffsetY.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // HEADER (.forgot-header)
                    Text(
                        text = "Forgot Your Password?",
                        style = TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF5E62),
                                    Color(0xFFFF9966),
                                    Color(0xFFE84393)
                                )
                            ),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 23.sp,
                            letterSpacing = (-0.4).sp,
                            textAlign = TextAlign.Center
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Enter your Gmail address and we'll send you a link to reset your password.",
                        color = TgWarmTextSoft,
                        fontFamily = PoppinsFontFamily,
                        fontSize = 11.5.sp,
                        lineHeight = 17.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )

                    Spacer(modifier = Modifier.height(22.dp))

                    // EMAIL INPUT (.input-box)
                    val hasError = fieldMessage != null && !isFieldSuccess
                    val borderColor = when {
                        hasError -> TgAuthError.copy(alpha = 0.6f)
                        isFieldSuccess -> TgVerifySuccess.copy(alpha = 0.55f)
                        else -> TgOrangePrimary.copy(alpha = 0.22f)
                    }
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White.copy(alpha = 0.90f))
                                .border(1.dp, borderColor, RoundedCornerShape(14.dp)),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(44.dp)
                                    .height(48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                // Gmail Icon Circle (.gmail-icon-circle)
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(TgOrangePrimary.copy(alpha = 0.08f))
                                        .border(1.dp, TgOrangePrimary.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.MailOutline,
                                        contentDescription = null,
                                        tint = TgOrangePrimary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 16.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (email.isEmpty()) {
                                    Text(
                                        text = "Enter your Gmail address",
                                        color = TgWarmTextMuted,
                                        fontFamily = PoppinsFontFamily,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.5.sp
                                    )
                                }
                                BasicTextField(
                                    value = email,
                                    onValueChange = {
                                        email = it
                                        fieldMessage = null
                                        isFieldSuccess = false
                                        statusTitle = null
                                    },
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        color = TgWarmTextMain,
                                        fontFamily = PoppinsFontFamily,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.5.sp
                                    ),
                                    cursorBrush = SolidColor(TgOrangePrimary),
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Email,
                                        imeAction = ImeAction.Send
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("forgot_email_input")
                                )
                            }
                        }

                        if (!fieldMessage.isNullOrEmpty()) {
                            Text(
                                text = fieldMessage ?: "",
                                color = if (isFieldSuccess) TgVerifySuccess else TgAuthError,
                                fontFamily = InterFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(top = 5.dp, start = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // STATUS MESSAGE (.forgot-status)
                    if (statusTitle != null) {
                        StatusAlertBox(
                            title = statusTitle ?: "",
                            message = statusMessage ?: "",
                            type = statusType,
                            modifier = Modifier.padding(bottom = 14.dp)
                        )
                    }

                    // SUBMIT BUTTON (.forgot-submit-btn)
                    ShinyGradientButton(
                        text = if (isLoading) "Sending reset link..." else "Send Reset Link →",
                        onClick = { handleSendResetLink() },
                        gradientColors = listOf(TgOrangeStart, TgOrangeEnd),
                        height = 48.dp,
                        cornerRadius = 14.dp,
                        fontSizeSp = 12f,
                        isLoading = isLoading,
                        testTag = "forgot_submit_button"
                    )

                    // BACK TO LOGIN (.signup-switch)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Remember your password? ",
                            color = TgWarmTextSoft,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "Back to Login",
                            color = TgOrangePrimary,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .clickable { onBackToLogin() }
                                .padding(vertical = 2.dp)
                                .testTag("forgot_back_to_login")
                        )
                    }

                    // FOOTER NOTE (.forgot-footer-note)
                    HorizontalDivider(
                        color = TgOrangePrimary.copy(alpha = 0.08f),
                        modifier = Modifier.padding(top = 14.dp, bottom = 12.dp)
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Send,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "We'll send the reset link to your Gmail shortly.",
                            color = Color(0xFF64748B),
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Exact 100% UI replica of verify-email.html + verify-email.css + verify-email.js
 */
@Composable
fun VerifyEmailScreen(
    userEmail: String,
    onVerifiedContinue: () -> Unit,
    onOpenEmailActionScreen: () -> Unit,
    onBackToLogin: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var remainingSeconds by remember { mutableIntStateOf(0) }
    var isResending by remember { mutableStateOf(false) }
    var isChecking by remember { mutableStateOf(false) }

    var statusTitle by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusType by remember { mutableStateOf("info") }

    val activeEmail = userEmail.ifBlank { Firebase.auth.currentUser?.email ?: "" }

    val infiniteTransition = rememberInfiniteTransition(label = "verifyFloat")
    val illustrationOffsetY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "verifyOffsetY"
    )

    // Automatically dispatch verification email when arriving on VerifyEmailScreen if not just sent on signup
    LaunchedEffect(activeEmail) {
        if (activeEmail.isNotBlank() && statusTitle == null) {
            if (FirebaseEmailDispatchService.wasVerificationJustSent(context)) {
                remainingSeconds = 60
            } else {
                val result = FirebaseEmailDispatchService.sendVerificationLinkEmail(
                    context = context,
                    fallbackEmail = activeEmail
                )
                if (result.success) {
                    remainingSeconds = 60
                }
            }
        }
    }

    // Automatically poll Firebase verification status every 2.5 seconds so as soon as the user
    // clicks the verification link in their email, they are automatically taken to the Home page.
    LaunchedEffect(activeEmail) {
        while (true) {
            delay(2500L)
            val isVerified = runCatching {
                FirebaseEmailDispatchService.checkAndSyncVerificationStatus(
                    context = context,
                    fallbackEmail = activeEmail
                )
            }.getOrDefault(false)
            if (isVerified) {
                FirebaseEmailDispatchService.setUserLoggedIn(context, true)
                statusTitle = "Email verified successfully"
                statusMessage = "Your Task Gullak account is verified! Taking you to Home..."
                statusType = "success"
                delay(350L)
                onVerifiedContinue()
                break
            }
        }
    }

    // Cooldown countdown timer matching RESEND_COOLDOWN = 60 in verify-email.js
    LaunchedEffect(remainingSeconds) {
        if (remainingSeconds > 0) {
            delay(1000)
            remainingSeconds -= 1
        }
    }

    // Matches resendVerificationEmail() in verify-email.js
    fun handleResendVerificationEmail() {
        if (isResending) return
        if (remainingSeconds > 0) {
            statusTitle = "Please wait"
            statusMessage =
                "You can request another verification email in $remainingSeconds seconds."
            statusType = "info"
            return
        }

        isResending = true
        coroutineScope.launch {
            try {
                val result = FirebaseEmailDispatchService.sendVerificationLinkEmail(
                    context = context,
                    fallbackEmail = activeEmail
                )
                statusTitle = result.title
                statusMessage = result.message
                statusType = result.statusType
                if (result.success) {
                    remainingSeconds = 60
                }
            } finally {
                isResending = false
            }
        }
    }

    // Matches checkVerificationStatus() in verify-email.js
    fun handleCheckVerificationStatus() {
        if (isChecking) return
        isChecking = true
        statusTitle = "Checking verification"
        statusMessage = "We're checking your email verification status..."
        statusType = "info"

        coroutineScope.launch {
            try {
                val isVerified = FirebaseEmailDispatchService.checkAndSyncVerificationStatus(
                    context = context,
                    fallbackEmail = activeEmail
                )
                delay(300)
                if (isVerified) {
                    FirebaseEmailDispatchService.setUserLoggedIn(context, true)
                    statusTitle = "Email verified successfully"
                    statusMessage = "Your Task Gullak account is now verified. Welcome aboard!"
                    statusType = "success"
                    delay(350)
                    onVerifiedContinue()
                } else {
                    statusTitle = "Not verified yet"
                    statusMessage =
                        "Your email is still not verified. Please click the link in your email first, then try again."
                    statusType = "info"
                }
            } finally {
                isChecking = false
            }
        }
    }

    WarmOrangeBackground(testTag = "verify_email_screen") {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 22.dp),
            contentAlignment = Alignment.Center
        ) {
            // VERIFY CARD (.verify-card)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .shadow(
                        elevation = 18.dp,
                        shape = RoundedCornerShape(32.dp),
                        ambientColor = TgOrangePrimary.copy(alpha = 0.10f),
                        spotColor = TgOrangePrimary.copy(alpha = 0.14f)
                    )
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color.White.copy(alpha = 0.88f))
                    .border(1.5.dp, TgOrangePrimary.copy(alpha = 0.19f), RoundedCornerShape(32.dp))
            ) {
                // Top gradient line (.card-top-line)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.5.dp)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(TgOrangeStart, TgOrangePrimary, TgOrangeEnd)
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 22.dp, end = 22.dp, top = 24.dp, bottom = 25.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // 3D EMAIL ILLUSTRATION (.verify-illustration-container)
                    Image(
                        painter = painterResource(id = R.drawable.img_verify_email),
                        contentDescription = "Email verification illustration",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(172.dp)
                            .offset(y = illustrationOffsetY.dp)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // HEADER (.verify-header)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(TgVerifySuccess.copy(alpha = 0.07f))
                            .border(1.dp, TgVerifySuccess.copy(alpha = 0.14f), RoundedCornerShape(999.dp))
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(15.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF22C55E)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "✓",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Text(
                            text = "Email Verification",
                            color = TgVerifySuccessDark,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(7.dp))

                    Text(
                        text = "Verify Your Email",
                        style = TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF5E62),
                                    Color(0xFFFF9966),
                                    Color(0xFFE84393)
                                )
                            ),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 23.sp,
                            letterSpacing = (-0.5).sp
                        )
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "We've sent a verification link to your email address.",
                        color = TgWarmTextSoft,
                        fontFamily = InterFontFamily,
                        fontSize = 10.5.sp,
                        lineHeight = 16.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(15.dp))

                    // EMAIL DISPLAY (.email-display)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(43.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(Color.White.copy(alpha = 0.88f))
                            .border(1.dp, TgOrangePrimary.copy(alpha = 0.13f), RoundedCornerShape(13.dp))
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(27.dp)
                                .clip(CircleShape)
                                .background(TgOrangePrimary.copy(alpha = 0.08f))
                                .border(1.dp, TgOrangePrimary.copy(alpha = 0.13f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.MailOutline,
                                contentDescription = null,
                                tint = TgOrangePrimary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = activeEmail.ifBlank { "member@taskgullak.app" },
                            color = TgWarmTextMain,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // STATUS ALERT (.verify-status)
                    if (statusTitle != null) {
                        StatusAlertBox(
                            title = statusTitle ?: "",
                            message = statusMessage ?: "",
                            type = statusType,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    // CHECK VERIFICATION BUTTON (.verify-btn)
                    ShinyGradientButton(
                        text = if (isChecking) "Checking verification..." else "I've Verified My Email →",
                        onClick = { handleCheckVerificationStatus() },
                        gradientColors = listOf(TgOrangeStart, TgOrangeEnd),
                        height = 46.dp,
                        cornerRadius = 13.dp,
                        fontSizeSp = 11.5f,
                        isLoading = isChecking,
                        testTag = "verify_check_button"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // OPEN EMAIL ACTION SCREEN BUTTON (.email-action-btn)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(TgOrangePrimary.copy(alpha = 0.08f))
                            .border(1.dp, TgOrangePrimary.copy(alpha = 0.20f), RoundedCornerShape(11.dp))
                            .clickable { onOpenEmailActionScreen() }
                            .testTag("open_email_action_screen_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Having Trouble? Open Action Screen ✉️",
                            color = TgOrangePrimary,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // RESEND LINK (.resend-row)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Didn't receive the email? ",
                            color = TgWarmTextSoft,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 10.sp
                        )
                        Text(
                            text = if (remainingSeconds > 0) "Resend in ${remainingSeconds}s" else "Resend Link",
                            color = if (remainingSeconds > 0) TgWarmTextMuted else TgOrangePrimary,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .clickable(enabled = remainingSeconds == 0 && !isResending) {
                                    handleResendVerificationEmail()
                                }
                                .padding(vertical = 2.dp)
                                .testTag("verify_resend_link")
                        )
                    }

                    // BOTTOM LOGOUT / BACK (.verify-footer-nav)
                    HorizontalDivider(
                        color = TgOrangePrimary.copy(alpha = 0.08f),
                        modifier = Modifier.padding(top = 14.dp, bottom = 12.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "← Back to Login",
                            color = TgWarmTextSoft,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .clickable { onBackToLogin() }
                                .testTag("verify_back_to_login")
                        )

                        Text(
                            text = "Logout",
                            color = TgAuthError,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .clickable { onLogout() }
                                .testTag("verify_logout_btn")
                        )
                    }
                }
            }
        }
    }
}

/**
 * Exact 100% UI replica of email-action.html + email-action.css + email-action.js
 */
@Composable
fun EmailActionScreen(
    userEmail: String,
    onContinueToApp: () -> Unit,
    onBackToLogin: () -> Unit,
    onNavigateToTerms: () -> Unit,
    onNavigateToPrivacy: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var statusTitle by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusType by remember { mutableStateOf("info") }
    var isChecking by remember { mutableStateOf(false) }

    val activeEmail = userEmail.ifBlank { Firebase.auth.currentUser?.email ?: "member@taskgullak.app" }

    val infiniteTransition = rememberInfiniteTransition(label = "actionFloat")
    val boxOffsetY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2100),
            repeatMode = RepeatMode.Reverse
        ),
        label = "boxOffsetY"
    )

    fun handleCheckStatus() {
        if (isChecking) return
        isChecking = true
        statusTitle = "Checking account status"
        statusMessage = "Verifying authentication and email status with Firebase..."
        statusType = "info"

        coroutineScope.launch {
            try {
                val isVerified = FirebaseEmailDispatchService.checkAndSyncVerificationStatus(
                    context = context,
                    fallbackEmail = activeEmail
                )
                delay(350)
                if (isVerified || Firebase.auth.currentUser != null) {
                    FirebaseEmailDispatchService.setUserLoggedIn(context, true)
                    statusTitle = "Ready to enter Task Gullak"
                    statusMessage = "Email session verified successfully! Entering app..."
                    statusType = "success"
                    delay(400)
                    onContinueToApp()
                } else {
                    statusTitle = "Action pending"
                    statusMessage = "Please open the verification link sent to $activeEmail first."
                    statusType = "info"
                }
            } finally {
                isChecking = false
            }
        }
    }

    WarmOrangeBackground(testTag = "email_action_screen") {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 22.dp),
            contentAlignment = Alignment.Center
        ) {
            // ACTION CARD (.action-card)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .shadow(
                        elevation = 18.dp,
                        shape = RoundedCornerShape(32.dp),
                        ambientColor = TgOrangePrimary.copy(alpha = 0.10f),
                        spotColor = TgOrangePrimary.copy(alpha = 0.14f)
                    )
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color.White.copy(alpha = 0.88f))
                    .border(1.5.dp, TgOrangePrimary.copy(alpha = 0.19f), RoundedCornerShape(32.dp))
            ) {
                // Top gradient line (.card-top-line)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.5.dp)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(TgOrangeStart, TgOrangePrimary, TgOrangeEnd)
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 22.dp, end = 22.dp, top = 26.dp, bottom = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // 3D ACTION ILLUSTRATION (.action-illustration-container)
                    Image(
                        painter = painterResource(id = R.drawable.img_verify_email),
                        contentDescription = "Email action illustration",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(165.dp)
                            .offset(y = boxOffsetY.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // HEADER (.action-header)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(TgActionOrange.copy(alpha = 0.08f))
                            .border(1.dp, TgActionOrange.copy(alpha = 0.18f), RoundedCornerShape(999.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(TgActionOrange)
                        )
                        Text(
                            text = "Email Link Action",
                            color = TgActionPink,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Email Action Handler",
                        style = TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF5E62),
                                    Color(0xFFFF9966),
                                    Color(0xFFE84393)
                                )
                            ),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp,
                            letterSpacing = (-0.4).sp
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "You clicked a verification or password reset link for $activeEmail.",
                        color = TgWarmTextSoft,
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // STATUS ALERT (.action-status)
                    if (statusTitle != null) {
                        StatusAlertBox(
                            title = statusTitle ?: "",
                            message = statusMessage ?: "",
                            type = statusType,
                            modifier = Modifier.padding(bottom = 14.dp)
                        )
                    }

                    // CONTINUE BUTTON (.action-btn)
                    ShinyGradientButton(
                        text = if (isChecking) "Checking action..." else "Continue to Task Gullak →",
                        onClick = { handleCheckStatus() },
                        gradientColors = listOf(TgOrangeStart, TgOrangeEnd),
                        height = 46.dp,
                        cornerRadius = 13.dp,
                        fontSizeSp = 11.5f,
                        isLoading = isChecking,
                        testTag = "email_action_continue_btn"
                    )

                    // BACK TO LOGIN (.signup-switch)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Finished? ",
                            color = TgWarmTextSoft,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "Back to Login",
                            color = TgOrangePrimary,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .clickable { onBackToLogin() }
                                .padding(vertical = 2.dp)
                                .testTag("email_action_back_to_login")
                        )
                    }

                    // FOOTER LINKS (.auth-footer-links)
                    HorizontalDivider(
                        color = TgOrangePrimary.copy(alpha = 0.08f),
                        modifier = Modifier.padding(top = 14.dp, bottom = 12.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Terms",
                            color = TgWarmTextMuted,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 9.5.sp,
                            modifier = Modifier
                                .clickable { onNavigateToTerms() }
                                .testTag("email_action_terms_link")
                        )
                        Text(text = "•", color = TgWarmTextMuted, fontSize = 9.5.sp)
                        Text(
                            text = "Privacy",
                            color = TgWarmTextMuted,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 9.5.sp,
                            modifier = Modifier
                                .clickable { onNavigateToPrivacy() }
                                .testTag("email_action_privacy_link")
                        )
                    }
                }
            }
        }
    }
}

/**
 * Shared Warm Orange Background shell for Recovery & Verification pages.
 */
@Composable
fun WarmOrangeBackground(
    testTag: String = "warm_background",
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFFAF7),
                        Color(0xFFFFF4EC),
                        Color(0xFFFFECE0)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .testTag(testTag)
    ) {
        Floating3DOrb(
            size = 220.dp,
            colors = listOf(TgOrangePrimary.copy(alpha = 0.14f), Color(0xFFFF416C).copy(alpha = 0.03f)),
            offsetX = (-35).dp,
            offsetY = 30.dp,
            durationMillis = 4800
        )
        Floating3DOrb(
            size = 240.dp,
            colors = listOf(Color(0xFFE84393).copy(alpha = 0.12f), TgOrangePrimary.copy(alpha = 0.03f)),
            offsetX = 200.dp,
            offsetY = 480.dp,
            durationMillis = 5200,
            delayMillis = 700
        )

        CssGridOverlay(
            gridSizeDp = 28.dp,
            lineColor = Color(0x0AFF6B35)
        )

        content()
    }
}

@Composable
fun StatusAlertBox(
    title: String,
    message: String,
    type: String, // "success", "error", "info"
    modifier: Modifier = Modifier
) {
    val (bgColor, borderColor, textColor, iconTint) = when (type) {
        "success" -> listOf(
            Color(0xFFDCFCE7),
            Color(0xFF86EFAC),
            Color(0xFF14532D),
            Color(0xFF15803D)
        )
        "error" -> listOf(
            Color(0xFFFFE4E6),
            Color(0xFFFDA4AF),
            Color(0xFF881337),
            Color(0xFFE11D48)
        )
        else -> listOf(
            Color(0xFFEEF2FF),
            Color(0xFFC7D2FE),
            Color(0xFF312E81),
            Color(0xFF4F46E5)
        )
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor as Color)
            .border(1.dp, borderColor as Color, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(RoundedCornerShape(6.dp))
                .background((iconTint as Color).copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Info,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(13.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = textColor as Color,
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
            Text(
                text = message,
                color = (textColor as Color).copy(alpha = 0.85f),
                fontFamily = InterFontFamily,
                fontSize = 10.5.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
fun ResetPasswordActionScreen(
    oobCode: String,
    onPasswordResetSuccess: () -> Unit,
    onBackToLogin: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var statusTitle by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusType by remember { mutableStateOf("info") }
    var isDone by remember { mutableStateOf(false) }

    WarmOrangeBackground(testTag = "reset_password_action_screen") {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .shadow(
                        elevation = 18.dp,
                        shape = RoundedCornerShape(32.dp),
                        ambientColor = TgOrangePrimary.copy(alpha = 0.12f),
                        spotColor = TgOrangePrimary.copy(alpha = 0.16f)
                    )
                    .clip(RoundedCornerShape(32.dp))
                    .background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.88f))
                    .border(1.5.dp, TgOrangePrimary.copy(alpha = 0.20f), RoundedCornerShape(32.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.5.dp)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(TgOrangeStart, TgOrangePrimary, TgOrangeEnd)
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 22.dp, end = 22.dp, top = 26.dp, bottom = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Reset Your Password",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold,
                        fontSize = 20.sp,
                        color = androidx.compose.ui.graphics.Color(0xFF17142E)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Enter a new secure password for your Task Gullak account.",
                        fontFamily = InterFontFamily,
                        fontSize = 11.5.sp,
                        color = TgWarmTextSoft,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (statusTitle != null) {
                        StatusAlertBox(
                            title = statusTitle ?: "",
                            message = statusMessage ?: "",
                            type = statusType,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    if (!isDone) {
                        Text(
                            text = "New Password",
                            modifier = Modifier.fillMaxWidth(),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = androidx.compose.ui.graphics.Color(0xFF374151)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        BasicTextField(
                            value = newPassword,
                            onValueChange = { newPassword = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(androidx.compose.ui.graphics.Color(0xFFF9FAFB))
                                .border(1.dp, androidx.compose.ui.graphics.Color(0xFFE5E7EB), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Password),
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Confirm Password",
                            modifier = Modifier.fillMaxWidth(),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = androidx.compose.ui.graphics.Color(0xFF374151)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        BasicTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(androidx.compose.ui.graphics.Color(0xFFF9FAFB))
                                .border(1.dp, androidx.compose.ui.graphics.Color(0xFFE5E7EB), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Password),
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        ShinyGradientButton(
                            text = if (isLoading) "Updating Password..." else "Save New Password",
                            onClick = {
                                if (newPassword.length < 6) {
                                    statusTitle = "Invalid Password"
                                    statusMessage = "Password must be at least 6 characters."
                                    statusType = "error"
                                    return@ShinyGradientButton
                                }
                                if (newPassword != confirmPassword) {
                                    statusTitle = "Mismatch"
                                    statusMessage = "Passwords do not match."
                                    statusType = "error"
                                    return@ShinyGradientButton
                                }
                                isLoading = true
                                coroutineScope.launch {
                                    val res = FirebaseEmailDispatchService.confirmPasswordResetWithOobCode(
                                        context = context,
                                        oobCode = oobCode,
                                        newPassword = newPassword
                                    )
                                    isLoading = false
                                    statusTitle = res.title
                                    statusMessage = res.message
                                    statusType = res.statusType
                                    if (res.success) {
                                        isDone = true
                                        onPasswordResetSuccess()
                                    }
                                }
                            },
                            gradientColors = listOf(TgOrangeStart, TgOrangeEnd),
                            isLoading = isLoading
                        )
                    } else {
                        ShinyGradientButton(
                            text = "Continue to Login →",
                            onClick = onBackToLogin,
                            gradientColors = listOf(TgOrangeStart, TgOrangeEnd)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Cancel & Return to Login",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 10.5.sp,
                        color = TgOrangePrimary,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        modifier = Modifier.clickable { onBackToLogin() }
                    )
                }
            }
        }
    }
}
