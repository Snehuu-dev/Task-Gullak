package com.example.taskgullak.screens

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.HourglassEmpty
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.LocalOffer
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.PeopleOutline
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.PrivacyTip
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import com.example.data.remote.AchievementBatchInfo
import com.example.data.remote.FirebaseEmailDispatchService
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AiTaskVerificationResult
import com.example.data.model.AvailableTask
import com.example.data.model.BroadcastNotification
import com.example.data.model.TaskSubmission
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.taskgullak.components.ShinyGradientButton
import com.example.taskgullak.theme.InterFontFamily
import com.example.taskgullak.theme.PoppinsFontFamily
import com.example.taskgullak.theme.TgBluePrimary
import com.example.taskgullak.theme.TgSlateMuted
import com.example.taskgullak.theme.TgSuccessGreen
import com.example.util.TaskGullakNotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

private val RemoteIconBitmapCache = ConcurrentHashMap<String, ImageBitmap>()

/**
 * Automatically fetches and renders the App Icon / Logo from the Admin Panel's link or iconUrl,
 * with a sleek stylized gradient emblem fallback.
 */
@Composable
internal fun RemoteAppIconBox(
    iconUrl: String,
    appTitle: String,
    size: Dp = 54.dp,
    cornerRadius: Dp = 15.dp
) {
    val cleanUrl = iconUrl.trim()
    var loadedBitmap by remember(cleanUrl) {
        mutableStateOf(if (cleanUrl.isNotEmpty()) RemoteIconBitmapCache[cleanUrl] else null)
    }

    LaunchedEffect(cleanUrl) {
        if (cleanUrl.isNotEmpty() && loadedBitmap == null) {
            val fetched = withContext(Dispatchers.IO) {
                runCatching {
                    if (cleanUrl.startsWith("data:image")) {
                        val raw = cleanUrl.substringAfter("base64,")
                        val bytes = Base64.decode(raw, Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                    } else {
                        val connection = (URL(cleanUrl).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 6000
                            readTimeout = 6000
                            instanceFollowRedirects = true
                            setRequestProperty("User-Agent", "Mozilla/5.0")
                        }
                        connection.inputStream.use { stream ->
                            BitmapFactory.decodeStream(stream)?.asImageBitmap()
                        }
                    }
                }.getOrNull()
            }
            if (fetched != null) {
                RemoteIconBitmapCache[cleanUrl] = fetched
                loadedBitmap = fetched
            }
        }
    }

    Box(
        modifier = Modifier
            .size(size)
            .shadow(4.dp, RoundedCornerShape(cornerRadius), spotColor = Color(0xFF1E293B).copy(alpha = 0.2f))
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                )
            )
            .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.35f), RoundedCornerShape(cornerRadius)),
        contentAlignment = Alignment.Center
    ) {
        if (loadedBitmap != null) {
            Image(
                bitmap = loadedBitmap!!,
                contentDescription = appTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(cornerRadius))
            )
        } else {
            Text(
                text = appTitle.trim().take(2).uppercase().ifBlank { "TG" },
                color = Color(0xFF38BDF8),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = (size.value * 0.34f).sp
            )
        }
    }
}

/**
 * Shared contextual page header for non-Home tabs (Offers, Refer, Wallet, Profile).
 * Does NOT show the "Task Gullak" top branding header so each screen remains minimal and contextual.
 */
@Composable
internal fun ContextualTabHeader(
    eyebrowIcon: ImageVector,
    eyebrowText: String,
    title: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp)
            .padding(top = 4.dp, bottom = 2.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(Color(0xFF7B3FE4).copy(alpha = 0.10f))
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = eyebrowIcon,
                contentDescription = null,
                tint = Color(0xFF7B3FE4),
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = eyebrowText,
                color = Color(0xFF7B3FE4),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 9.5.sp,
                letterSpacing = 1.1.sp,
                style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
            )
        }

        Text(
            text = title,
            color = Color(0xFF17142E),
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 26.sp,
            letterSpacing = (-0.6).sp,
            style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
        )
    }
}

/**
 * Full-width Account Suspended / Banned Screen rendered immediately when Admin Panel sets isBanned = true on /users/{userId}.
 */
@Composable
internal fun AccountBannedOverlayCard(
    userName: String,
    userEmail: String,
    banReason: String,
    onSignOut: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp)
            .padding(top = 24.dp)
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0xFFE11D48).copy(alpha = 0.25f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.98f))
            .border(1.5.dp, Color(0xFFFECDD3), RoundedCornerShape(24.dp))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(Color(0xFFFFE4E6)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Block,
                contentDescription = "Account Suspended",
                tint = Color(0xFFE11D48),
                modifier = Modifier.size(32.dp)
            )
        }

        Text(
            text = "Account Access Restricted",
            color = Color(0xFF9F1239),
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            textAlign = TextAlign.Center
        )

        Text(
            text = "Hi $userName ($userEmail), your Task Gullak account access has been restricted by the compliance team.",
            color = Color(0xFF475569),
            fontFamily = InterFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )

        if (banReason.isNotBlank()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFFFF1F2))
                    .border(1.dp, Color(0xFFFECDD3), RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "RESTRICTION NOTICE",
                    color = Color(0xFFE11D48),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = banReason,
                    color = Color(0xFF881337),
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        ShinyGradientButton(
            text = "Sign Out",
            onClick = onSignOut,
            gradientColors = listOf(Color(0xFFE11D48), Color(0xFFBE123C)),
            height = 44.dp,
            cornerRadius = 14.dp,
            fontSizeSp = 12.5f,
            testTag = "banned_sign_out_button"
        )
    }
}

/**
 * Live Notifications Panel showing real-time Broadcasts from the Admin Panel (/broadcasts)
 */
@Composable
internal fun LiveNotificationsBannerPanel(
    firstName: String,
    broadcasts: List<BroadcastNotification>,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp)
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0xFF4628BE).copy(alpha = 0.16f)
            )
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.97f))
            .border(1.dp, Color(0xFFE0E7FF), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF3E8FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Campaign,
                        contentDescription = null,
                        tint = Color(0xFF7B3FE4),
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = "Live Notifications & Broadcasts",
                    color = Color(0xFF17142E),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp
                )
            }

            Icon(
                imageVector = Icons.Outlined.Close,
                contentDescription = "Close notifications",
                tint = Color(0xFF6F6E8A),
                modifier = Modifier
                    .size(18.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onDismiss() }
            )
        }

        if (broadcasts.isEmpty()) {
            Text(
                text = "Welcome to Task Gullak, $firstName! Any new projects, announcements, or task approvals will trigger a real notification on your phone and appear here.",
                color = Color(0xFF475569),
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 11.5.sp,
                lineHeight = 16.sp
            )
        } else {
            broadcasts.take(5).forEach { item ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF8F7FF))
                        .border(1.dp, Color(0xFFEDE9FE), RoundedCornerShape(12.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = item.title,
                        color = Color(0xFF17142E),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = item.message,
                        color = Color(0xFF6F6E8A),
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

/**
 * 1. TASKS SCREEN SHELL + LIVE ADMIN TASKS + SCREENSHOT PROOF SUBMISSION (Separate Task Detail Page Navigation)
 */
@Composable
internal fun TasksTabShellContent(
    availableTasks: List<AvailableTask>,
    submissions: List<TaskSubmission>,
    pendingCount: Int,
    approvedCount: Int,
    rejectedCount: Int,
    walletBalance: Long,
    isSubmitting: Boolean = false,
    feedbackMessage: String? = null,
    onClearFeedback: () -> Unit = {},
    onSubmitTaskProof: (AvailableTask, String, String, (AiTaskVerificationResult?) -> Unit) -> Unit = { _, _, _, _ -> }
) {
    val context = LocalContext.current
    var selectedPeriodIndex by remember { mutableIntStateOf(0) }
    val periods = remember { listOf("Today", "7 Days", "30 Days") }
    var selectedTaskFilter by remember { mutableIntStateOf(0) }
    val taskFilterLabels = remember { listOf("All Tasks", "Single Tasks", "Bulk Tasks") }
    val submittedTotal = pendingCount + approvedCount + rejectedCount

    var activeTaskForProof by remember { mutableStateOf<AvailableTask?>(null) }
    var appliedTasksRefreshTick by remember { mutableIntStateOf(0) }
    var celebratedSubmittedTask by remember {
        mutableStateOf<Pair<AvailableTask, AiTaskVerificationResult?>?>(null)
    }

    val filteredTasks = remember(availableTasks, selectedTaskFilter) {
        when (selectedTaskFilter) {
            1 -> availableTasks.filter { !it.isBulk && it.targetCount <= 1 }
            2 -> availableTasks.filter { it.isBulk || it.targetCount > 1 }
            else -> availableTasks
        }
    }

    if (celebratedSubmittedTask != null) {
        val (doneTask, aiResult) = celebratedSubmittedTask!!
        TaskSubmittedCelebrationDialog(
            task = doneTask,
            aiVerificationResult = aiResult,
            onDismiss = { celebratedSubmittedTask = null }
        )
    }

    // IF A TASK IS SELECTED, OPEN IN A SEPARATE DEDICATED PAGE VIEW (per client requirement: "alag page mein open hoga")
    if (activeTaskForProof != null) {
        val detailTask = activeTaskForProof!!
        val taskSubmissions = remember(submissions, detailTask.id, detailTask.title) {
            submissions.filter { it.taskId == detailTask.id || it.taskTitle.equals(detailTask.title, ignoreCase = true) }
        }
        val isReworkRequired = taskSubmissions.any { it.status.lowercase() == "rejected" || it.status.lowercase() == "rework" }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Separate Page Back Navigation Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFEDE9FE))
                    .border(1.dp, Color(0xFFDDD6FE), RoundedCornerShape(14.dp))
                    .clickable { activeTaskForProof = null }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFF5B21B6),
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "← Back to Tasks List",
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF5B21B6)
                )
            }

            TaskSubmissionFormPanel(
                task = detailTask,
                isSubmitting = isSubmitting,
                isRework = isReworkRequired,
                onCancel = { activeTaskForProof = null },
                onSubmit = { proofMsg, screenshotB64 ->
                    onSubmitTaskProof(detailTask, proofMsg, screenshotB64) { aiResult ->
                        activeTaskForProof = null
                        celebratedSubmittedTask = Pair(detailTask, aiResult)
                    }
                }
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ContextualTabHeader(
            eyebrowIcon = Icons.Outlined.LocalOffer,
            eyebrowText = "EARN REWARDS",
            title = "Tasks"
        )

        if (!feedbackMessage.isNullOrBlank()) {
            val isRejectedBanner = feedbackMessage.contains("Rejected", ignoreCase = true) ||
                feedbackMessage.contains("Re-work", ignoreCase = true)
            val isPartialBanner = feedbackMessage.contains("Quality Review Complete", ignoreCase = true)
            val bannerBg = when {
                isRejectedBanner -> Color(0xFFFFE4E6)
                isPartialBanner -> Color(0xFFFEF3C7)
                else -> Color(0xFFDCFCE7)
            }
            val bannerBorder = when {
                isRejectedBanner -> Color(0xFFFDA4AF)
                isPartialBanner -> Color(0xFFFDE68A)
                else -> Color(0xFF86EFAC)
            }
            val bannerTint = when {
                isRejectedBanner -> Color(0xFFE11D48)
                isPartialBanner -> Color(0xFFD97706)
                else -> Color(0xFF15803D)
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(bannerBg)
                    .border(1.dp, bannerBorder, RoundedCornerShape(14.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onClearFeedback() }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (isRejectedBanner) Icons.Outlined.Cancel else Icons.Outlined.CheckCircle,
                    contentDescription = null,
                    tint = bannerTint,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = feedbackMessage,
                    color = Color(0xFF1E293B),
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Available Tasks Header + Single/Bulk Filter Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Available Tasks",
                    color = Color(0xFF17142E),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.5.sp
                )
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEDE9FE)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${filteredTasks.size}",
                        color = Color(0xFF6D28D9),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                    )
                }
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color(0xFFEDEAF6))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                taskFilterLabels.forEachIndexed { idx, label ->
                    val isSelected = selectedTaskFilter == idx
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                if (isSelected) {
                                    Brush.horizontalGradient(
                                        listOf(Color(0xFF635BFF), Color(0xFF8B5CF6))
                                    )
                                } else {
                                    Brush.horizontalGradient(
                                        listOf(Color.Transparent, Color.Transparent)
                                    )
                                }
                            )
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { selectedTaskFilter = idx }
                            .padding(horizontal = 9.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else Color(0xFF6F6E8A),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 9.5.sp
                        )
                    }
                }
            }
        }

        // Available Tasks List or Empty State Card
        if (filteredTasks.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(22.dp),
                        ambientColor = Color(0xFF32238C).copy(alpha = 0.08f),
                        spotColor = Color(0xFF32238C).copy(alpha = 0.14f)
                    )
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.White.copy(alpha = 0.94f))
                    .border(1.dp, Color.White, RoundedCornerShape(22.dp))
                    .padding(horizontal = 24.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF3E8FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.HourglassEmpty,
                        contentDescription = null,
                        tint = Color(0xFF7B3FE4),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Tasks not available",
                    color = Color(0xFF17142E),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.5.sp
                )
                Text(
                    text = "New tasks will appear here soon",
                    color = Color(0xFF6F6E8A),
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Normal,
                    fontSize = 11.5.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            filteredTasks.forEachIndexed { index, task ->
                val isSelectedTask = activeTaskForProof?.id == task.id
                val targetTotal = task.targetCount.coerceAtLeast(1)
                val remainingTasks = (targetTotal - task.completedCount).coerceAtLeast(0)
                val appDisplayTitle = task.appName.ifBlank { task.title }

                // Check user's submission status for this specific project/task
                val taskSubmissions = remember(submissions, task.id, task.title) {
                    submissions.filter {
                        it.taskId == task.id || it.taskTitle.equals(task.title, ignoreCase = true)
                    }
                }
                val latestSub = taskSubmissions.maxByOrNull { it.createdAt?.seconds ?: 0L }
                val subStatus = latestSub?.status?.lowercase() ?: ""
                val isApproved = subStatus == "approved" || subStatus == "verified"
                val isPending = subStatus == "pending" || subStatus == "submitted" || subStatus == "under_review"
                val isRejected = subStatus == "rejected" || subStatus == "declined"

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(
                            elevation = 8.dp,
                            shape = RoundedCornerShape(20.dp),
                            spotColor = Color(0xFF32238C).copy(alpha = 0.10f)
                        )
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.96f))
                        .border(
                            width = if (isApproved) 1.5.dp else 1.dp,
                            color = if (isApproved) Color(0xFF86EFAC) else Color(0xFFEDE9FE),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable {
                            if (!isApproved) {
                                activeTaskForProof = task
                            }
                        }
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                RemoteAppIconBox(
                                    iconUrl = task.iconUrl,
                                    appTitle = appDisplayTitle,
                                    size = 50.dp,
                                    cornerRadius = 15.dp
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = appDisplayTitle,
                                        color = Color(0xFF17142E),
                                        fontFamily = PoppinsFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.5.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = task.category.ifBlank { "App Task & Campaign" },
                                        color = Color(0xFF6F6E8A),
                                        fontFamily = InterFontFamily,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Reward Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(Color(0xFFDCFCE7))
                                    .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(11.dp))
                                    .padding(horizontal = 11.dp, vertical = 7.dp)
                            ) {
                                Text(
                                    text = "+₹${task.rewardInr}",
                                    color = Color(0xFF15803D),
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp,
                                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                                )
                            }
                        }

                        if (task.subtitle.isNotBlank()) {
                            Text(
                                text = task.subtitle,
                                color = Color(0xFF475569),
                                fontFamily = InterFontFamily,
                                fontSize = 11.5.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                lineHeight = 16.sp
                            )
                        }

                        // Status Badge / Action Button Footer
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.AccessTime,
                                    contentDescription = null,
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "Duration: 2 Mins",
                                    color = Color(0xFF94A3B8),
                                    fontFamily = InterFontFamily,
                                    fontSize = 11.sp
                                )
                            }

                            when {
                                isApproved -> {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(999.dp))
                                            .background(Color(0xFFDCFCE7))
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.CheckCircle,
                                                contentDescription = null,
                                                tint = Color(0xFF15803D),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = "Completed & Credited",
                                                color = Color(0xFF15803D),
                                                fontFamily = PoppinsFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                                isPending -> {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(999.dp))
                                            .background(Color(0xFFFEF3C7))
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "Review in Progress...",
                                            color = Color(0xFFB45309),
                                            fontFamily = PoppinsFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                isRejected -> {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(999.dp))
                                            .background(Color(0xFFFFE4E6))
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "Re-work Required (Tap to Retry)",
                                            color = Color(0xFFE11D48),
                                            fontFamily = PoppinsFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                else -> {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(999.dp))
                                            .background(
                                                Brush.horizontalGradient(
                                                    listOf(Color(0xFF4F46E5), Color(0xFF7B3FE4))
                                                )
                                            )
                                            .padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Text(
                                                text = "Start Task",
                                                color = Color.White,
                                                fontFamily = PoppinsFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.5.sp
                                            )
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(13.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2. SEPARATE TASK DETAIL & SCREENSHOT PROOF UPLOAD PAGE
 */
@Composable
internal fun TaskSubmissionFormPanel(
    task: AvailableTask,
    isSubmitting: Boolean,
    isRework: Boolean,
    onCancel: () -> Unit,
    onSubmit: (String, String) -> Unit
) {
    val context = LocalContext.current
    val appDisplayTitle = task.appName.ifBlank { task.title }
    var proofTextInput by remember { mutableStateOf("") }
    var attachedScreenshotBase64 by remember { mutableStateOf("") }
    var showReferenceSampleModal by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    val outputStream = java.io.ByteArrayOutputStream()
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, outputStream)
                    val bytes = outputStream.toByteArray()
                    attachedScreenshotBase64 = Base64.encodeToString(bytes, Base64.DEFAULT)
                }
            }
        }
    }

    if (showReferenceSampleModal) {
        Dialog(onDismissRequest = { showReferenceSampleModal = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 16.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Reference Sample Screenshot",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = Color(0xFF17142E)
                    )
                    Text(
                        text = "Your uploaded screenshot should match this sample to pass verification and receive 100% reward.",
                        fontFamily = InterFontFamily,
                        fontSize = 11.5.sp,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    RemoteAppIconBox(
                        iconUrl = task.referenceScreenshotUrl.ifBlank { task.iconUrl },
                        appTitle = appDisplayTitle,
                        size = 140.dp,
                        cornerRadius = 22.dp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    ShinyGradientButton(
                        text = "Got It, Close Preview",
                        onClick = { showReferenceSampleModal = false },
                        gradientColors = listOf(Color(0xFF4F46E5), Color(0xFF7B3FE4)),
                        height = 44.dp,
                        cornerRadius = 12.dp
                    )
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 14.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0xFF32238C).copy(alpha = 0.15f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White)
            .border(1.5.dp, Color(0xFFEDE9FE), RoundedCornerShape(24.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RemoteAppIconBox(
                    iconUrl = task.iconUrl,
                    appTitle = appDisplayTitle,
                    size = 56.dp,
                    cornerRadius = 16.dp
                )

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = appDisplayTitle,
                        color = Color(0xFF17142E),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = task.category.ifBlank { "Task Verification" },
                        color = Color(0xFF7B3FE4),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFDCFCE7))
                    .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "+₹${task.rewardInr}",
                    color = Color(0xFF15803D),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                )
            }
        }

        if (isRework) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFFFE4E6))
                    .border(1.dp, Color(0xFFFDA4AF), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "RE-WORK REQUIRED",
                    color = Color(0xFFE11D48),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                Text(
                    text = "Your previous submission was below the 80% quality threshold. Please review the instructions & sample, then upload a clear screenshot.",
                    color = Color(0xFF881337),
                    fontFamily = InterFontFamily,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        }

        if (task.instructions.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF8F7FF))
                    .border(1.dp, Color(0xFFEDE9FE), RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "📋 Task Instructions",
                    color = Color(0xFF5B21B6),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = task.instructions.joinToString("\n"),
                    color = Color(0xFF334155),
                    fontFamily = InterFontFamily,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )

                if (task.assignedComment.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "💬 Required Review Text to Post: \"${task.assignedComment}\"",
                        color = Color(0xFF0F766E),
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.5.sp
                    )
                }
            }
        }

        if (task.referenceScreenshotUrl.isNotBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF0FDF4))
                    .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(12.dp))
                    .clickable { showReferenceSampleModal = true }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Image,
                        contentDescription = null,
                        tint = Color(0xFF15803D),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "View Reference Sample Screenshot 🖼️",
                        color = Color(0xFF15803D),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Upload Screenshot Proof Button
        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Upload Screenshot Proof (Required)",
                color = Color(0xFF17142E),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (attachedScreenshotBase64.isNotBlank()) Color(0xFFDCFCE7) else Color(0xFFF1F5F9))
                        .border(
                            width = 1.dp,
                            color = if (attachedScreenshotBase64.isNotBlank()) Color(0xFF86EFAC) else Color(0xFFCBD5E1),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (attachedScreenshotBase64.isNotBlank()) Icons.Outlined.CheckCircle else Icons.Outlined.AddPhotoAlternate,
                            contentDescription = null,
                            tint = if (attachedScreenshotBase64.isNotBlank()) Color(0xFF15803D) else Color(0xFF64748B),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (attachedScreenshotBase64.isNotBlank()) "Screenshot Attached Successfully ✓" else "Tap to Choose Screenshot from Gallery",
                            color = if (attachedScreenshotBase64.isNotBlank()) Color(0xFF14532D) else Color(0xFF475569),
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Proof Comment Input
        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Submission Note or Username (Optional)",
                color = Color(0xFF17142E),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (proofTextInput.isEmpty()) {
                    Text(
                        text = "e.g. Completed with username @divyanshu...",
                        color = Color(0xFF94A3B8),
                        fontFamily = InterFontFamily,
                        fontSize = 11.5.sp
                    )
                }
                BasicTextField(
                    value = proofTextInput,
                    onValueChange = { proofTextInput = it },
                    singleLine = true,
                    textStyle = TextStyle(
                        color = Color(0xFF1E1B24),
                        fontFamily = InterFontFamily,
                        fontSize = 12.sp
                    ),
                    cursorBrush = SolidColor(Color(0xFF7B3FE4)),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Submit & Cancel Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Color(0xFFF1F5F9))
                    .clickable { onCancel() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Cancel",
                    color = Color(0xFF475569),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Box(
                modifier = Modifier
                    .weight(1.5f)
                    .height(46.dp)
                    .shadow(
                        elevation = if (attachedScreenshotBase64.isNotBlank()) 8.dp else 0.dp,
                        shape = RoundedCornerShape(13.dp),
                        spotColor = Color(0xFF7B3FE4).copy(alpha = 0.3f)
                    )
                    .clip(RoundedCornerShape(13.dp))
                    .background(
                        if (attachedScreenshotBase64.isNotBlank()) {
                            Brush.horizontalGradient(listOf(Color(0xFF4F46E5), Color(0xFF7B3FE4)))
                        } else {
                            Brush.horizontalGradient(listOf(Color(0xFFCBD5E1), Color(0xFF94A3B8)))
                        }
                    )
                    .clickable(enabled = attachedScreenshotBase64.isNotBlank() && !isSubmitting) {
                        onSubmit(proofTextInput.ifBlank { "Screenshot proof uploaded" }, attachedScreenshotBase64)
                    },
                contentAlignment = Alignment.Center
            ) {
                if (isSubmitting) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        Text(
                            text = "Analyzing Proof...",
                            color = Color.White,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                } else {
                    Text(
                        text = "Submit Proof for Reward ✨",
                        color = Color.White,
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

/**
 * 3. CELEBRATION DIALOG AFTER SUCCESSFUL TASK SUBMISSION
 */
@Composable
internal fun TaskSubmittedCelebrationDialog(
    task: AvailableTask,
    aiVerificationResult: AiTaskVerificationResult?,
    onDismiss: () -> Unit
) {
    val percent = aiVerificationResult?.completionPercentage ?: 98
    val credited = aiVerificationResult?.creditedRewardInr ?: task.rewardInr.toLong()
    val isSuccess = aiVerificationResult?.status == "approved"

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            shadowElevation = 18.dp,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 380.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFF8FAFC),
                                Color(0xFFF3F5FF),
                                Color.White
                            )
                        )
                    )
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .shadow(10.dp, CircleShape, spotColor = Color(0xFF22C55E).copy(alpha = 0.3f))
                        .clip(CircleShape)
                        .background(
                            if (isSuccess) Color(0xFF22C55E) else Color(0xFFF59E0B)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSuccess) Icons.Default.Check else Icons.Outlined.HourglassEmpty,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }

                Text(
                    text = if (isSuccess) "Verification Complete! 🎉" else "Review In Progress",
                    color = Color(0xFF17142E),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = aiVerificationResult?.adminNote ?: "Your submission for '${task.appName.ifBlank { task.title }}' has been verified ($percent% Match). +₹$credited credited to your wallet!",
                    color = Color(0xFF475569),
                    fontFamily = InterFontFamily,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                ShinyGradientButton(
                    text = "Awesome! Return to Tasks ✨",
                    onClick = onDismiss,
                    gradientColors = listOf(Color(0xFF4F46E5), Color(0xFF7B3FE4)),
                    height = 46.dp,
                    cornerRadius = 14.dp
                )
            }
        }
    }
}

/**
 * 2. REFER & EARN TAB SHELL CONTENT (Wraps ExactReferAndEarnScreen)
 */
@Composable
internal fun ReferTabShellContent(
    referredUsers: List<UserProfile>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ContextualTabHeader(
            eyebrowIcon = Icons.Outlined.CardGiftcard,
            eyebrowText = "REFERRAL PROGRAM",
            title = "Refer & Earn"
        )

        ExactReferAndEarnScreen(
            liveReferredUsers = referredUsers
        )
    }
}

/**
 * 3. WALLET TAB SHELL CONTENT + TRANSACTIONS & UPI WITHDRAWAL
 */
@Composable
internal fun WalletTabShellContent(
    walletBalance: Long,
    transactions: List<WalletTransaction>,
    submissions: List<TaskSubmission>,
    upiId: String,
    isWithdrawing: Boolean,
    withdrawFeedback: String?,
    onSaveUpi: (String) -> Unit,
    onRequestWithdrawal: (Long, String, String) -> Unit,
    onClearWithdrawFeedback: () -> Unit
) {
    var upiInput by remember(upiId) { mutableStateOf(upiId) }
    var selectedWithdrawAmount by remember { mutableLongStateOf(50L) }
    var selectedPayoutMethod by remember { mutableStateOf("UPI") }
    var showWithdrawModal by remember { mutableStateOf(false) }

    val presetAmounts = remember { listOf(50L, 100L, 250L, 500L, 1000L) }

    if (showWithdrawModal) {
        Dialog(onDismissRequest = { showWithdrawModal = false }) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Color.White,
                shadowElevation = 18.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Instant UPI Payout",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = Color(0xFF17142E)
                    )
                    Text(
                        text = "Withdraw ₹$selectedWithdrawAmount instantly to UPI ID: ${upiInput.ifBlank { "Not Set" }}",
                        fontFamily = InterFontFamily,
                        fontSize = 11.5.sp,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    ShinyGradientButton(
                        text = if (isWithdrawing) "Processing Payout..." else "Confirm & Withdraw ₹$selectedWithdrawAmount 💸",
                        onClick = {
                            if (upiInput.isNotBlank() && walletBalance >= selectedWithdrawAmount) {
                                onRequestWithdrawal(selectedWithdrawAmount, selectedPayoutMethod, upiInput.trim())
                                showWithdrawModal = false
                            }
                        },
                        gradientColors = listOf(Color(0xFF059669), Color(0xFF10B981)),
                        height = 46.dp,
                        cornerRadius = 14.dp,
                        isLoading = isWithdrawing,
                        testTag = "confirm_withdrawal_modal_btn"
                    )
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ContextualTabHeader(
            eyebrowIcon = Icons.Outlined.AccountBalanceWallet,
            eyebrowText = "EARNINGS & PAYOUTS",
            title = "Wallet"
        )

        if (!withdrawFeedback.isNullOrBlank()) {
            val isSuccess = withdrawFeedback.contains("submitted", ignoreCase = true) ||
                withdrawFeedback.contains("success", ignoreCase = true)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isSuccess) Color(0xFFDCFCE7) else Color(0xFFFFE4E6))
                    .border(1.dp, if (isSuccess) Color(0xFF86EFAC) else Color(0xFFFDA4AF), RoundedCornerShape(14.dp))
                    .clickable { onClearWithdrawFeedback() }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (isSuccess) Icons.Outlined.CheckCircle else Icons.Outlined.Cancel,
                    contentDescription = null,
                    tint = if (isSuccess) Color(0xFF15803D) else Color(0xFFE11D48),
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = withdrawFeedback,
                    color = Color(0xFF1E293B),
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Wallet Balance Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(
                    elevation = 16.dp,
                    shape = RoundedCornerShape(24.dp),
                    spotColor = Color(0xFF4628BE).copy(alpha = 0.22f)
                )
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0F172A),
                            Color(0xFF1E293B),
                            Color(0xFF334155)
                        )
                    )
                )
                .padding(22.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "AVAILABLE WITHDRAWAL BALANCE",
                    color = Color(0xFF94A3B8),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "₹$walletBalance",
                    color = Color.White,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Black,
                    fontSize = 38.sp,
                    letterSpacing = (-1.2).sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Select Amount Chips
                Text(
                    text = "Select Withdrawal Amount",
                    color = Color(0xFFE2E8F0),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetAmounts.forEach { amt ->
                        val isSelected = selectedWithdrawAmount == amt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) Color(0xFF7B3FE4) else Color(0xFF334155))
                                .clickable { selectedWithdrawAmount = amt },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹$amt",
                                color = Color.White,
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // UPI ID Configuration Input
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Your UPI ID (GPay / PhonePe / Paytm)",
                        color = Color(0xFFE2E8F0),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, Color(0xFF475569), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (upiInput.isEmpty()) {
                                Text(
                                    text = "e.g. username@oksbi",
                                    color = Color(0xFF64748B),
                                    fontFamily = InterFontFamily,
                                    fontSize = 11.5.sp
                                )
                            }
                            BasicTextField(
                                value = upiInput,
                                onValueChange = { upiInput = it },
                                singleLine = true,
                                textStyle = TextStyle(
                                    color = Color.White,
                                    fontFamily = InterFontFamily,
                                    fontSize = 12.sp
                                ),
                                cursorBrush = SolidColor(Color(0xFF38BDF8)),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Box(
                            modifier = Modifier
                                .height(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF38BDF8))
                                .clickable {
                                    if (upiInput.isNotBlank()) {
                                        onSaveUpi(upiInput.trim())
                                    }
                                }
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Save",
                                color = Color(0xFF0F172A),
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                ShinyGradientButton(
                    text = "Request Payout of ₹$selectedWithdrawAmount →",
                    onClick = {
                        if (upiInput.isBlank()) {
                            // prompt or notify
                        } else {
                            showWithdrawModal = true
                        }
                    },
                    gradientColors = listOf(Color(0xFF10B981), Color(0xFF059669)),
                    height = 46.dp,
                    cornerRadius = 14.dp,
                    enabled = walletBalance >= selectedWithdrawAmount && upiInput.isNotBlank(),
                    testTag = "request_withdrawal_button"
                )
            }
        }

        // Transactions History Header
        Text(
            text = "Transaction History",
            color = Color(0xFF17142E),
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.5.sp
        )

        if (transactions.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 8.dp,
                        shape = RoundedCornerShape(20.dp),
                        spotColor = Color(0xFF32238C).copy(alpha = 0.08f)
                    )
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.ReceiptLong,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = "No Transactions Yet",
                    color = Color(0xFF17142E),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "Your task rewards and UPI payouts will appear here.",
                    color = Color(0xFF64748B),
                    fontFamily = InterFontFamily,
                    fontSize = 11.5.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            transactions.forEach { tx ->
                val isCredit = !tx.type.lowercase().contains("deduct") && !tx.type.lowercase().contains("debit")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(
                            elevation = 6.dp,
                            shape = RoundedCornerShape(16.dp),
                            spotColor = Color(0xFF32238C).copy(alpha = 0.08f)
                        )
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFEDE9FE), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(if (isCredit) Color(0xFFDCFCE7) else Color(0xFFFFE4E6)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCredit) Icons.Outlined.AccountBalanceWallet else Icons.Outlined.AccountBalance,
                            contentDescription = null,
                            tint = if (isCredit) Color(0xFF15803D) else Color(0xFFE11D48),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = tx.note.ifBlank { if (isCredit) "Task Reward Credit" else "UPI Withdrawal" },
                            color = Color(0xFF17142E),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Status: ${tx.status.replaceFirstChar { it.uppercase() }} • ${tx.payoutMethod.ifBlank { "UPI" }}",
                            color = Color(0xFF64748B),
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp
                        )
                    }

                    Text(
                        text = "${if (isCredit) "+" else "-"}₹${tx.amount}",
                        color = if (isCredit) Color(0xFF15803D) else Color(0xFFE11D48),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * 4. PROFILE TAB SHELL CONTENT + AVATAR PICKER + EDIT NAME + SUPPORT
 */
@Composable
internal fun ProfileTabShellContent(
    displayName: String,
    displayEmail: String,
    walletIdCode: String,
    currentAvatarId: String,
    submissions: List<TaskSubmission>,
    onUpdateAvatar: (String) -> Unit,
    onUpdateDisplayName: (String, (Boolean, String) -> Unit) -> Unit,
    onReplayOnboarding: () -> Unit,
    onSignOut: () -> Unit
) {
    var showAvatarPicker by remember { mutableStateOf(false) }
    var showEditNameDialog by remember { mutableStateOf(false) }
    var showSupportSheet by remember { mutableStateOf(false) }
    var showAchievementsSheet by remember { mutableStateOf(false) }
    var showFlowerDialog by remember { mutableStateOf<AchievementBatchInfo?>(null) }
    var editNameInput by remember { mutableStateOf(displayName) }
    var profileFeedback by remember { mutableStateOf<String?>(null) }

    val completedTasksCount = remember(submissions) {
        submissions.count { it.status.lowercase() == "approved" || it.status.lowercase() == "verified" }
    }

    val allBatches = remember(completedTasksCount) {
        FirebaseEmailDispatchService.getAchievementBatches(completedTasksCount)
    }
    val currentBatch = remember(completedTasksCount) {
        FirebaseEmailDispatchService.getCurrentUnlockedOrNextBatch(completedTasksCount)
    }
    val unlockedBatchesCount = remember(allBatches) {
        allBatches.count { it.isUnlocked }
    }

    if (showAvatarPicker) {
        AvatarPickerModalBottomSheet(
            currentAvatarId = currentAvatarId,
            userInitial = displayName.firstOrNull()?.uppercaseChar()?.toString() ?: "D",
            onSelectAvatar = { newId ->
                onUpdateAvatar(newId)
                profileFeedback = "3D avatar updated successfully!"
            },
            onDismiss = { showAvatarPicker = false }
        )
    }

    if (showSupportSheet) {
        HelpAndSupportBottomSheet(
            userName = displayName,
            userEmail = displayEmail,
            walletIdCode = walletIdCode,
            onDismiss = { showSupportSheet = false }
        )
    }

    if (showAchievementsSheet) {
        AchievementsBatchesModalSheet(
            batches = allBatches,
            completedTasksCount = completedTasksCount,
            onSelectBatchForFlowerAnimation = { batch ->
                showAchievementsSheet = false
                showFlowerDialog = batch
            },
            onDismiss = { showAchievementsSheet = false }
        )
    }

    if (showFlowerDialog != null) {
        FlowerUnlockAnimationDialog(
            batch = showFlowerDialog!!,
            onDismiss = { showFlowerDialog = null }
        )
    }

    if (showEditNameDialog) {
        Dialog(onDismissRequest = { showEditNameDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 16.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Edit Display Name",
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = Color(0xFF17142E)
                    )

                    OutlinedTextField(
                        value = editNameInput,
                        onValueChange = { editNameInput = it },
                        singleLine = true,
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    ShinyGradientButton(
                        text = "Save Name",
                        onClick = {
                            if (editNameInput.isNotBlank()) {
                                onUpdateDisplayName(editNameInput.trim()) { success, msg ->
                                    profileFeedback = msg
                                    showEditNameDialog = false
                                }
                            }
                        },
                        gradientColors = listOf(Color(0xFF4F46E5), Color(0xFF7B3FE4)),
                        height = 44.dp,
                        cornerRadius = 12.dp,
                        testTag = "save_display_name_button"
                    )
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 520.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ContextualTabHeader(
            eyebrowIcon = Icons.Outlined.PersonOutline,
            eyebrowText = "ACCOUNT & PROFILE",
            title = "Profile"
        )

        if (!profileFeedback.isNullOrBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFDCFCE7))
                    .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(14.dp))
                    .clickable { profileFeedback = null }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF15803D),
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = profileFeedback ?: "",
                    color = Color(0xFF1E293B),
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Profile Card with Pastel Banner + 3D Avatar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(
                    elevation = 16.dp,
                    shape = RoundedCornerShape(24.dp),
                    spotColor = Color(0xFF32238C).copy(alpha = 0.12f)
                )
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                EditableProfilePastelBanner(
                    bannerId = "banner_sky_blossom",
                    onEditBannerClick = { showAvatarPicker = true }
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .offset(y = (-38).dp)
                            .size(78.dp)
                            .shadow(8.dp, CircleShape, spotColor = Color(0xFF7B3FE4).copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        UserAvatar3DBadge(
                            avatarId = currentAvatarId,
                            userInitial = displayName.firstOrNull()?.uppercaseChar()?.toString() ?: "D",
                            size = 78.dp,
                            showEditBadge = true,
                            onClick = { showAvatarPicker = true },
                            testTag = "profile_avatar_edit_badge"
                        )
                    }

                    Spacer(modifier = Modifier.height((-24).dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = displayName,
                            color = Color(0xFF17142E),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp
                        )
                        IconButton(
                            onClick = {
                                editNameInput = displayName
                                showEditNameDialog = true
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Edit,
                                contentDescription = "Edit name",
                                tint = Color(0xFF7B3FE4),
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }

                    Text(
                        text = displayEmail,
                        color = Color(0xFF6F6E8A),
                        fontFamily = InterFontFamily,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xFFEDE9FE))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Wallet ID: $walletIdCode",
                            color = Color(0xFF6D28D9),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Featured Achievement Batch Card
        FeaturedAchievementBatchCard(
            currentBatch = currentBatch,
            completedTasksCount = completedTasksCount,
            unlockedBatchesCount = unlockedBatchesCount,
            onTriggerFlowerUnlock = { batch ->
                showFlowerDialog = batch
            },
            onOpenAllBatches = {
                showAchievementsSheet = true
            }
        )

        // Account Action Rows
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(
                    elevation = 8.dp,
                    shape = RoundedCornerShape(20.dp),
                    spotColor = Color(0xFF32238C).copy(alpha = 0.08f)
                )
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .border(1.dp, Color(0xFFEDE9FE), RoundedCornerShape(20.dp))
                .padding(4.dp)
        ) {
            ProfileMenuActionRow(
                icon = Icons.Outlined.SupportAgent,
                iconTint = Color(0xFF0284C7),
                iconBg = Color(0xFFE0F2FE),
                title = "Help & Support Desk",
                subtitle = "Contact support & submit inquiries",
                onClick = { showSupportSheet = true },
                testTag = "menu_help_support"
            )

            HorizontalDivider(color = Color(0xFFF1F5F9), modifier = Modifier.padding(horizontal = 14.dp))

            ProfileMenuActionRow(
                icon = Icons.Outlined.Explore,
                iconTint = Color(0xFF7B3FE4),
                iconBg = Color(0xFFF3E8FF),
                title = "Replay Onboarding Guide",
                subtitle = "View app introduction walkthrough",
                onClick = onReplayOnboarding,
                testTag = "menu_replay_onboarding"
            )

            HorizontalDivider(color = Color(0xFFF1F5F9), modifier = Modifier.padding(horizontal = 14.dp))

            ProfileMenuActionRow(
                icon = Icons.Outlined.Block,
                iconTint = Color(0xFFE11D48),
                iconBg = Color(0xFFFFE4E6),
                title = "Sign Out of Task Gullak",
                subtitle = "Securely sign out of your account",
                onClick = onSignOut,
                testTag = "menu_sign_out"
            )
        }
    }
}

@Composable
private fun ProfileMenuActionRow(
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color(0xFF17142E),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = subtitle,
                color = Color(0xFF6F6E8A),
                fontFamily = InterFontFamily,
                fontSize = 11.sp
            )
        }

        Icon(
            imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight,
            contentDescription = null,
            tint = Color(0xFF94A3B8),
            modifier = Modifier.size(18.dp)
        )
    }
}
