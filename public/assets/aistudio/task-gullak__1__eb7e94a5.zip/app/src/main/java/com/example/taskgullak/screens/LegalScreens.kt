package com.example.taskgullak.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.taskgullak.components.CssGridOverlay
import com.example.taskgullak.components.Floating3DOrb
import com.example.taskgullak.theme.*
import kotlinx.coroutines.launch

/**
 * Exact 100% UI replica of terms.html + terms.css
 */
@Composable
fun TermsScreen(
    fromSource: String = "login",
    onBack: () -> Unit,
    onSwitchToPrivacy: () -> Unit
) {
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val backButtonLabel = if (fromSource == "signup") "Back to Sign Up" else "Back to Login"

    val tocItems = listOf(
        "Acceptance of Terms" to 1,
        "Eligibility" to 2,
        "Account & Security" to 3,
        "Tasks & Participation" to 4,
        "Proof & Submissions" to 5,
        "Rewards & Payments" to 6,
        "Prohibited Activities" to 7,
        "Verification & Review" to 8,
        "Suspension & Termination" to 9,
        "Privacy" to 10,
        "Third-Party Services" to 11,
        "Changes to Terms" to 12,
        "Contact Us" to 13
    )

    LegalSkyBackground(testTag = "terms_screen") {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(18.dp))
                // Start of Main Card Top Header + Intro + TOC
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 760.dp)
                        .clip(RoundedCornerShape(topStart = 21.dp, topEnd = 21.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .border(
                            width = 1.dp,
                            color = Color(0xFFBFE0F1).copy(alpha = 0.86f),
                            shape = RoundedCornerShape(topStart = 21.dp, topEnd = 21.dp)
                        )
                        .padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LegalHeaderBlock(
                        badgeText = "LEGAL",
                        title = "Terms & Conditions",
                        subtitle = "Please read these terms carefully before using Task Gullak.",
                        metaRight = "User Agreement"
                    )

                    // INTRODUCTION (.terms-intro)
                    LegalIntroBox(
                        paragraphs = listOf(
                            "These Terms & Conditions explain the rules that apply when you create an account, use Task Gullak, complete tasks, submit proof, receive rewards, or use any other part of our platform.",
                            "By creating an account or using Task Gullak, you agree to follow these Terms. If you do not agree with them, please do not use the platform."
                        )
                    )

                    // TABLE OF CONTENTS (.terms-toc)
                    LegalTocGrid(
                        heading = "Contents",
                        items = tocItems,
                        onSelectSection = { sectionIndex ->
                            coroutineScope.launch {
                                listState.animateScrollToItem(sectionIndex)
                            }
                        }
                    )
                }
            }

            // SECTION 01
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "01",
                        title = "Acceptance of Terms",
                        paragraphs = listOf(
                            "By accessing or using Task Gullak, you confirm that you understand and agree to these Terms & Conditions.",
                            "These Terms apply to the Task Gullak website, user account, tasks, submissions, rewards, wallet features, verification systems and other services provided through the platform.",
                            "If you are using Task Gullak on behalf of another person or organization, you confirm that you have the authority to accept these Terms on their behalf."
                        )
                    )
                }
            }

            // SECTION 02
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "02",
                        title = "Eligibility",
                        paragraphs = listOf(
                            "You must meet the minimum age and other legal requirements applicable to use Task Gullak in your location.",
                            "You are responsible for making sure that your participation in tasks and receipt of rewards is lawful for you."
                        ),
                        bullets = listOf(
                            "You must provide truthful information.",
                            "You must not create an account using someone else's identity.",
                            "You must not use Task Gullak if doing so would violate applicable law.",
                            "You must follow the requirements shown for each task."
                        ),
                        warningBox = "Important" to "Task availability may depend on age, location, eligibility, verification, task requirements or other conditions."
                    )
                }
            }

            // SECTION 03
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "03",
                        title = "Account & Security",
                        paragraphs = listOf(
                            "Some Task Gullak features require an account. You are responsible for keeping your account information accurate and protecting your login credentials."
                        ),
                        bullets = listOf(
                            "Use your own email address or permitted authentication method.",
                            "Keep your password confidential.",
                            "Do not share your account with another person.",
                            "Notify us if you believe your account has been accessed without permission.",
                            "Do not attempt to access another user's account."
                        ),
                        closingParagraph = "Task Gullak may require email verification or additional checks before allowing certain account actions."
                    )
                }
            }

            // SECTION 04
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "04",
                        title = "Tasks & Participation",
                        paragraphs = listOf(
                            "Task Gullak may display different types of tasks, such as surveys, research activities, app testing, beta testing, feedback requests, bug reporting, data-related activities or other authorized user tasks.",
                            "Each task may have its own instructions, eligibility requirements, deadline, reward, proof requirements and verification criteria.",
                            "You should read the complete task instructions before accepting or starting a task."
                        ),
                        bullets = listOf(
                            "Complete the task according to its instructions.",
                            "Do not intentionally submit incomplete work.",
                            "Do not claim a task that you do not intend to complete.",
                            "Do not use unauthorized automation, bots or scripts.",
                            "Do not manipulate task results or verification."
                        )
                    )
                }
            }

            // SECTION 05
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "05",
                        title = "Proof & Submissions",
                        paragraphs = listOf(
                            "Some tasks require you to submit proof that you completed the requested activity.",
                            "Proof may include screenshots, photographs, written responses, recordings, links, task-specific information or other material requested in the task instructions.",
                            "You are responsible for ensuring that your submission is clear, relevant and follows the requirements of the specific task."
                        ),
                        bullets = listOf(
                            "Submit genuine proof of your own work.",
                            "Do not upload fake, edited or misleading evidence when genuine proof is required.",
                            "Do not submit the same proof for unrelated tasks unless the task specifically allows it.",
                            "Do not include unnecessary private information belonging to another person.",
                            "Follow all instructions regarding screenshot or image quality."
                        ),
                        infoBox = "Simple rule" to "If a task asks for proof, submit proof that clearly shows that you completed the required activity."
                    )
                }
            }

            // SECTION 06
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "06",
                        title = "Rewards & Payments",
                        paragraphs = listOf(
                            "Task Gullak may provide rewards for eligible tasks that are completed and properly verified according to the applicable task requirements."
                        ),
                        paymentWarning = "Payment is not automatic" to "Completing a task does not guarantee payment. Payment will be added only if the submitted task and proof are properly verified and approved according to the applicable task requirements.",
                        extraParagraphsAfterPaymentWarning = listOf(
                            "A task may be rejected when the submitted work does not satisfy the stated requirements, proof is insufficient, information is inaccurate, or there is evidence of misuse or manipulation.",
                            "Reward amounts, eligibility conditions and withdrawal requirements may vary between tasks and may be displayed before participation."
                        ),
                        bullets = listOf(
                            "Rewards are subject to successful verification.",
                            "A displayed reward is not a promise that the task will be approved.",
                            "Duplicate, fraudulent or invalid submissions may not receive rewards.",
                            "Withdrawal availability may depend on the applicable minimum balance and other conditions.",
                            "Payment or withdrawal processing may take reasonable processing time."
                        ),
                        warningBox = "Important" to "Never assume that simply claiming or submitting a task creates an unconditional right to payment."
                    )
                }
            }

            // SECTION 07
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "07",
                        title = "Prohibited Activities",
                        paragraphs = listOf(
                            "To keep Task Gullak fair and safe, you must not misuse the platform, tasks, verification systems or other users."
                        ),
                        bullets = listOf(
                            "Creating multiple accounts to gain unauthorized benefits.",
                            "Using fake or stolen identities.",
                            "Providing false or misleading information.",
                            "Submitting fabricated proof.",
                            "Manipulating screenshots or other evidence to falsely show task completion.",
                            "Using bots, unauthorized automation or scripts to abuse task systems.",
                            "Attempting to bypass security or verification.",
                            "Interfering with another user's account.",
                            "Exploiting technical bugs for unauthorized rewards or benefits.",
                            "Using Task Gullak for illegal activities."
                        ),
                        warningBox = "Zero tolerance" to "Serious fraud, abuse, account manipulation or attempts to defeat platform security may result in immediate restriction or termination."
                    )
                }
            }

            // SECTION 08
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "08",
                        title = "Verification & Review",
                        paragraphs = listOf(
                            "Task Gullak may review task submissions before approving rewards.",
                            "Verification may be performed using automated systems, manual review, task-specific checks, or a combination of these methods.",
                            "A submission may remain under review for a reasonable period depending on the task and verification requirements."
                        ),
                        bullets = listOf(
                            "Verification does not guarantee approval.",
                            "A submission can be rejected if it does not meet the task requirements.",
                            "Additional information or proof may sometimes be requested.",
                            "Repeated suspicious activity may trigger additional review."
                        ),
                        infoBox = "Why verification exists" to "Verification helps protect task providers, genuine users and the platform from inaccurate, duplicate or fraudulent submissions."
                    )
                }
            }

            // SECTION 09
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "09",
                        title = "Suspension & Termination",
                        paragraphs = listOf(
                            "Task Gullak may temporarily restrict, suspend or terminate an account when necessary to protect the platform, users or task providers.",
                            "This may happen when we reasonably believe that an account has:"
                        ),
                        bullets = listOf(
                            "Violated these Terms.",
                            "Participated in fraud or abuse.",
                            "Submitted repeatedly invalid information.",
                            "Attempted to manipulate rewards or verification.",
                            "Created a security or safety risk."
                        ),
                        closingParagraph = "Where appropriate and permitted, users may contact support regarding an account restriction or review.",
                        warningBox = "Account safety" to "Do not create another account to bypass an existing suspension or restriction."
                    )
                }
            }

            // SECTION 10
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "10",
                        title = "Privacy",
                        paragraphs = listOf(
                            "Your use of Task Gullak may involve the collection and processing of information required to provide our services.",
                            "Our Privacy Policy explains what information may be collected, why it may be used, how it may be protected and what choices may be available to you."
                        ),
                        infoBox = "Read the Privacy Policy" to "Please review the Task Gullak Privacy Policy before using the platform so that you understand how your information is handled."
                    )
                }
            }

            // SECTION 11
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "11",
                        title = "Third-Party Services",
                        paragraphs = listOf(
                            "Task Gullak may use third-party services to provide certain features or infrastructure.",
                            "These services may include authentication, hosting, storage, analytics, communication, payment processing or other technical services.",
                            "Some third-party services may have their own terms and privacy policies. You may be required to follow those policies when using their services.",
                            "Task Gullak is not responsible for the independent policies or availability of third-party services that are outside our control."
                        )
                    )
                }
            }

            // SECTION 12
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "12",
                        title = "Changes to These Terms",
                        paragraphs = listOf(
                            "We may update these Terms & Conditions when necessary to reflect changes in our services, technology, legal requirements, security practices or business operations.",
                            "Updated Terms may be published on the Task Gullak website or communicated through other reasonable methods.",
                            "If you continue to use Task Gullak after updated Terms become effective, your continued use may mean that you accept the updated Terms."
                        ),
                        infoBox = "Keep checking this page" to "We recommend reviewing these Terms from time to time so you remain aware of the current rules."
                    )
                }
            }

            // SECTION 13 + FINAL + BACK BUTTON + FOOTER
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 760.dp)
                        .clip(RoundedCornerShape(bottomStart = 21.dp, bottomEnd = 21.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .border(
                            width = 1.dp,
                            color = Color(0xFFBFE0F1).copy(alpha = 0.86f),
                            shape = RoundedCornerShape(bottomStart = 21.dp, bottomEnd = 21.dp)
                        )
                        .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 22.dp)
                ) {
                    LegalSectionArticle(
                        number = "13",
                        title = "Contact Us",
                        paragraphs = listOf(
                            "If you have questions about these Terms, task requirements, account restrictions or other matters related to Task Gullak, you can contact our support team through the official support channel provided on the platform."
                        ),
                        contactBox = "Need help?" to "When contacting support, provide enough information for us to understand your question or issue."
                    )

                    // FINAL MESSAGE (.terms-final)
                    LegalFinalBox(
                        boldTitle = "Use Task Gullak fairly.",
                        bodyText = "Complete genuine tasks, submit accurate proof and follow the requirements shown on the platform."
                    )

                    // BACK BUTTON (.terms-actions)
                    LegalBackButton(
                        text = backButtonLabel,
                        onClick = onBack,
                        testTag = "terms_back_button"
                    )

                    // FOOTER (.terms-footer)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 19.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Terms & Conditions",
                            color = TgLegalBlue600,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 9.sp
                        )
                        Text(
                            text = "  •  ",
                            color = TgLegalMuted,
                            fontSize = 9.sp
                        )
                        Text(
                            text = "Privacy Policy",
                            color = TgLegalMuted,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 9.sp,
                            modifier = Modifier
                                .clickable { onSwitchToPrivacy() }
                                .testTag("terms_switch_to_privacy")
                        )
                    }
                }
                Spacer(modifier = Modifier.height(34.dp))
            }
        }
    }
}

/**
 * Exact 100% UI replica of privacy.html + privacy.css
 */
@Composable
fun PrivacyScreen(
    fromSource: String = "login",
    onBack: () -> Unit,
    onSwitchToTerms: () -> Unit
) {
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val backButtonLabel = if (fromSource == "signup") "Back to Sign Up" else "Back to Login"

    val tocItems = listOf(
        "01. Information We Collect" to 1,
        "02. How We Use Your Information" to 2,
        "03. Task & Submission Data" to 3,
        "04. Device & Technical Information" to 4,
        "05. Cookies & Similar Technologies" to 5,
        "06. Information Sharing" to 6,
        "07. Data Security" to 7,
        "08. Data Retention" to 8,
        "09. Your Privacy Rights" to 9,
        "10. Children's Privacy" to 10,
        "11. Third-Party Services" to 11,
        "12. Changes to This Policy" to 12,
        "13. Contact Us" to 13
    )

    LegalSkyBackground(testTag = "privacy_screen") {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(18.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 760.dp)
                        .clip(RoundedCornerShape(topStart = 21.dp, topEnd = 21.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .border(
                            width = 1.dp,
                            color = Color(0xFFBFE0F1).copy(alpha = 0.86f),
                            shape = RoundedCornerShape(topStart = 21.dp, topEnd = 21.dp)
                        )
                        .padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LegalHeaderBlock(
                        badgeText = "PRIVACY & DATA",
                        title = "Privacy Policy",
                        subtitle = "Learn how Task Gullak collects, uses, protects, and manages your information.",
                        metaRight = "Last updated: 2026"
                    )

                    LegalIntroBox(
                        paragraphs = listOf(
                            "Your privacy matters to us. This Privacy Policy explains what information Task Gullak may collect when you use our website, services, tasks, and related features.",
                            "By using Task Gullak, you acknowledge that your information may be collected and processed as described in this Privacy Policy."
                        )
                    )

                    LegalTocGrid(
                        heading = "Quick Overview",
                        items = tocItems,
                        onSelectSection = { sectionIndex ->
                            coroutineScope.launch {
                                listState.animateScrollToItem(sectionIndex)
                            }
                        }
                    )
                }
            }

            // SECTION 01
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "01",
                        title = "Information We Collect",
                        paragraphs = listOf(
                            "Task Gullak may collect information that you provide directly when creating an account, using our services, participating in tasks, or contacting us."
                        ),
                        bullets = listOf(
                            "Name or display name",
                            "Email address",
                            "Account and authentication information",
                            "Task participation and activity information",
                            "Information you voluntarily submit"
                        ),
                        infoBox = "Account Information" to "We collect only the information reasonably required to operate your Task Gullak account, provide services, and maintain platform security."
                    )
                }
            }

            // SECTION 02
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "02",
                        title = "How We Use Your Information",
                        paragraphs = listOf(
                            "Information collected through Task Gullak may be used to operate and improve the platform, manage accounts, process tasks, and provide relevant services."
                        ),
                        bullets = listOf(
                            "Create and manage your account",
                            "Authenticate your identity",
                            "Provide available tasks and services",
                            "Process task submissions and verification",
                            "Communicate important account information",
                            "Detect fraud, abuse, or suspicious activity",
                            "Improve platform performance and security"
                        )
                    )
                }
            }

            // SECTION 03
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "03",
                        title = "Task & Submission Data",
                        paragraphs = listOf(
                            "When you participate in a task, you may provide information required to complete and verify that task.",
                            "Depending on the task, this information may include screenshots, images, written responses, timestamps, task results, feedback, or other proof submitted through the platform."
                        ),
                        warningBox = "Important" to "Providing information for a task does not automatically guarantee payment or approval. Submitted work may need to pass the applicable verification requirements."
                    )
                }
            }

            // SECTION 04
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "04",
                        title = "Device & Technical Information",
                        paragraphs = listOf(
                            "We may collect basic technical information about the device, browser, or app environment used to access Task Gullak to ensure security and proper operation."
                        ),
                        bullets = listOf(
                            "Device type and operating system version",
                            "App version and settings",
                            "IP address and network connection info",
                            "Basic diagnostic and error logs"
                        )
                    )
                }
            }

            // SECTION 05
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "05",
                        title = "Cookies & Similar Technologies",
                        paragraphs = listOf(
                            "Task Gullak may use local storage, cookies, or similar technologies to keep you signed in, remember your preferences, and maintain session security."
                        ),
                        bullets = listOf(
                            "Maintaining your signed-in session",
                            "Remembering your onboarding status",
                            "Storing app preferences securely",
                            "Analyzing platform performance"
                        ),
                        infoBox = "Session persistence" to "Clearing browser data or resetting app storage may require you to sign in again."
                    )
                }
            }

            // SECTION 06
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "06",
                        title = "Information Sharing",
                        paragraphs = listOf(
                            "We do not sell your personal information. We may share information only in specific circumstances:"
                        ),
                        bullets = listOf(
                            "With trusted service providers assisting our platform (authentication, hosting, database, notification services)",
                            "To comply with legal obligations or valid government requests",
                            "To protect the rights, safety, and security of Task Gullak, users, or the public",
                            "With your explicit consent"
                        )
                    )
                }
            }

            // SECTION 07
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "07",
                        title = "Data Security",
                        paragraphs = listOf(
                            "We implement reasonable security measures designed to protect your information against unauthorized access, alteration, disclosure, or destruction.",
                            "However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security."
                        ),
                        warningBox = "Your responsibility" to "Keep your password and account credentials confidential and do not share them with anyone."
                    )
                }
            }

            // SECTION 08
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "08",
                        title = "Data Retention",
                        paragraphs = listOf(
                            "We retain your account information, task submissions, and transaction records for as long as your account remains active or as needed to provide services, comply with legal obligations, resolve disputes, and enforce our agreements.",
                            "If you request account deletion, we will remove or anonymize your personal information subject to legal and operational requirements."
                        )
                    )
                }
            }

            // SECTION 09
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "09",
                        title = "Your Privacy Rights",
                        paragraphs = listOf(
                            "Depending on your location, you may have certain rights regarding your personal information, such as the right to access, correct, or request deletion of your data."
                        ),
                        bullets = listOf(
                            "Access your account information at any time",
                            "Update your profile name, avatar, or settings",
                            "Request account deactivation or deletion",
                            "Opt out of non-essential communications"
                        )
                    )
                }
            }

            // SECTION 10
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "10",
                        title = "Children's Privacy",
                        paragraphs = listOf(
                            "Task Gullak is not directed to individuals under the minimum required age in their jurisdiction. We do not knowingly collect personal information from children under the applicable age limit.",
                            "If you believe a child has provided us with personal information, please contact support so we can take appropriate steps."
                        )
                    )
                }
            }

            // SECTION 11
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "11",
                        title = "Third-Party Services",
                        paragraphs = listOf(
                            "Our platform may integrate with third-party services (such as Firebase Authentication, Google Sign-In, Cloud Firestore, and hosting infrastructure).",
                            "These third parties operate under their own privacy policies. We encourage you to review their privacy policies to understand how they handle data."
                        )
                    )
                }
            }

            // SECTION 12
            item {
                LegalSectionCardWrapper {
                    LegalSectionArticle(
                        number = "12",
                        title = "Changes to This Policy",
                        paragraphs = listOf(
                            "We may update this Privacy Policy from time to time to reflect changes in our practices, technology, legal requirements, or platform features.",
                            "The updated policy will be posted on this page with a revised effective date. Continued use of Task Gullak after changes indicates your acceptance of the updated policy."
                        )
                    )
                }
            }

            // SECTION 13 + FINAL + BACK BUTTON + FOOTER
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 760.dp)
                        .clip(RoundedCornerShape(bottomStart = 21.dp, bottomEnd = 21.dp))
                        .background(Color.White.copy(alpha = 0.94f))
                        .border(
                            width = 1.dp,
                            color = Color(0xFFBFE0F1).copy(alpha = 0.86f),
                            shape = RoundedCornerShape(bottomStart = 21.dp, bottomEnd = 21.dp)
                        )
                        .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 22.dp)
                ) {
                    LegalSectionArticle(
                        number = "13",
                        title = "Contact Us",
                        paragraphs = listOf(
                            "If you have questions, concerns, or requests regarding this Privacy Policy or how your data is handled, please contact our support team through the platform."
                        ),
                        contactBox = "Privacy Support" to "We are committed to helping you with any privacy-related questions or requests."
                    )

                    LegalFinalBox(
                        boldTitle = "Your privacy is respected.",
                        bodyText = "We collect only what is needed to provide our services and protect your account."
                    )

                    LegalBackButton(
                        text = backButtonLabel,
                        onClick = onBack,
                        testTag = "privacy_back_button"
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 19.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Terms & Conditions",
                            color = TgLegalMuted,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 9.sp,
                            modifier = Modifier
                                .clickable { onSwitchToTerms() }
                                .testTag("privacy_switch_to_terms")
                        )
                        Text(
                            text = "  •  ",
                            color = TgLegalMuted,
                            fontSize = 9.sp
                        )
                        Text(
                            text = "Privacy Policy",
                            color = TgLegalBlue600,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 9.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(34.dp))
            }
        }
    }
}

/**
 * Shared Sky Blue background shell for Legal screens matching terms.css / privacy.css
 */
@Composable
fun LegalSkyBackground(
    testTag: String = "legal_background",
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFEBF5FF),
                        Color(0xFFF0F8FF),
                        Color(0xFFF7FBFF)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .testTag(testTag)
    ) {
        Floating3DOrb(
            size = 240.dp,
            colors = listOf(Color(0xFF3AAEF4).copy(alpha = 0.12f), Color(0xFF1597ED).copy(alpha = 0.03f)),
            offsetX = (-50).dp,
            offsetY = 50.dp,
            durationMillis = 6000
        )
        Floating3DOrb(
            size = 220.dp,
            colors = listOf(Color(0xFF7C3AED).copy(alpha = 0.10f), Color(0xFF3AAEF4).copy(alpha = 0.02f)),
            offsetX = 190.dp,
            offsetY = 520.dp,
            durationMillis = 5500,
            delayMillis = 900
        )

        CssGridOverlay(
            gridSizeDp = 30.dp,
            lineColor = Color(0x0A1597ED)
        )

        content()
    }
}

@Composable
fun LegalHeaderBlock(
    badgeText: String,
    title: String,
    subtitle: String,
    metaRight: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(TgLegalBlue100)
                    .border(1.dp, TgLegalBlue200, RoundedCornerShape(999.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(TgLegalBlue600)
                )
                Text(
                    text = badgeText,
                    color = TgLegalBlue700,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    letterSpacing = 1.sp
                )
            }

            Text(
                text = metaRight,
                color = TgLegalMuted,
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.height(11.dp))

        Text(
            text = title,
            style = TextStyle(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF0F2C44),
                        Color(0xFF087BD0),
                        Color(0xFF1597ED)
                    )
                ),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 25.sp,
                letterSpacing = (-0.6).sp,
                textAlign = TextAlign.Center
            )
        )

        Spacer(modifier = Modifier.height(5.dp))

        Text(
            text = subtitle,
            color = TgLegalTextSoft,
            fontFamily = PoppinsFontFamily,
            fontSize = 11.5.sp,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = TgLegalBlue200.copy(alpha = 0.55f))
    }
}

@Composable
fun LegalIntroBox(paragraphs: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 14.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(TgLegalBlue50)
            .border(1.dp, TgLegalBlue200, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        paragraphs.forEach { p ->
            Text(
                text = p,
                color = TgLegalText,
                fontFamily = InterFontFamily,
                fontSize = 11.5.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LegalTocGrid(
    heading: String,
    items: List<Pair<String, Int>>,
    onSelectSection: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF8FBFE))
            .border(1.dp, Color(0xFFE2EEF8), RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = heading,
            color = TgLegalBlue700,
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            letterSpacing = 0.8.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items.forEachIndexed { idx, pair ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFD2EDFB), RoundedCornerShape(8.dp))
                        .clickable { onSelectSection(pair.second) }
                        .padding(horizontal = 9.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${idx + 1}. ${pair.first}",
                        color = TgLegalBlue600,
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun LegalSectionCardWrapper(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 760.dp)
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.94f))
            .border(1.dp, Color(0xFFBFE0F1).copy(alpha = 0.86f), RoundedCornerShape(16.dp))
            .padding(18.dp)
    ) {
        content()
    }
}

@Composable
fun LegalSectionArticle(
    number: String,
    title: String,
    paragraphs: List<String>,
    bullets: List<String> = emptyList(),
    closingParagraph: String? = null,
    infoBox: Pair<String, String>? = null,
    warningBox: Pair<String, String>? = null,
    paymentWarning: Pair<String, String>? = null,
    extraParagraphsAfterPaymentWarning: List<String> = emptyList(),
    contactBox: Pair<String, String>? = null
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(TgLegalBlue100),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = number,
                    color = TgLegalBlue700,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 11.sp
                )
            }

            Text(
                text = title,
                color = TgLegalText,
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp
            )
        }

        paragraphs.forEach { p ->
            Text(
                text = p,
                color = TgLegalTextSoft,
                fontFamily = InterFontFamily,
                fontSize = 11.5.sp,
                lineHeight = 17.sp
            )
        }

        if (paymentWarning != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TgLegalOrangeSoft)
                    .border(1.dp, TgLegalOrangeBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = paymentWarning.first,
                    color = TgLegalOrange,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    text = paymentWarning.second,
                    color = Color(0xFF7A3E12),
                    fontFamily = InterFontFamily,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        extraParagraphsAfterPaymentWarning.forEach { ep ->
            Text(
                text = ep,
                color = TgLegalTextSoft,
                fontFamily = InterFontFamily,
                fontSize = 11.5.sp,
                lineHeight = 17.sp
            )
        }

        if (bullets.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                bullets.forEach { b ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "•",
                            color = TgLegalBlue600,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = b,
                            color = TgLegalTextSoft,
                            fontFamily = InterFontFamily,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (infoBox != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TgLegalBlue50)
                    .border(1.dp, TgLegalBlue200, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = infoBox.first,
                    color = TgLegalBlue600,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    text = infoBox.second,
                    color = TgLegalText,
                    fontFamily = InterFontFamily,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        if (warningBox != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TgLegalYellowSoft)
                    .border(1.dp, TgLegalYellowBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = warningBox.first,
                    color = Color(0xFFB45309),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    text = warningBox.second,
                    color = Color(0xFF78350F),
                    fontFamily = InterFontFamily,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        if (contactBox != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TgLegalGreenSoft)
                    .border(1.dp, TgLegalGreenBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = contactBox.first,
                    color = TgLegalGreen,
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    text = contactBox.second,
                    color = Color(0xFF064E3B),
                    fontFamily = InterFontFamily,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        if (!closingParagraph.isNullOrBlank()) {
            Text(
                text = closingParagraph,
                color = TgLegalTextSoft,
                fontFamily = InterFontFamily,
                fontSize = 11.5.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
fun LegalFinalBox(boldTitle: String, bodyText: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 14.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(TgLegalGreenSoft)
            .border(1.dp, TgLegalGreenBorder, RoundedCornerShape(14.dp))
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = boldTitle,
            color = TgLegalGreen,
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
        Text(
            text = bodyText,
            color = Color(0xFF064E3B),
            fontFamily = InterFontFamily,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp
        )
    }
}

@Composable
fun LegalBackButton(
    text: String,
    onClick: () -> Unit,
    testTag: String = "legal_back_button"
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(13.dp),
                spotColor = TgLegalBlue600.copy(alpha = 0.20f)
            )
            .clip(RoundedCornerShape(13.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(TgLegalBlue600, TgLegalBlue700)
                )
            )
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = text,
                color = Color.White,
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}
