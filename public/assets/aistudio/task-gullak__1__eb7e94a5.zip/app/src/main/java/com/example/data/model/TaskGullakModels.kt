package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val walletBalance: Long = 0L,
    val completedTasksCount: Long = 0L,
    val pendingRewards: Long = 0L,
    val emailVerified: Boolean = false,
    @get:PropertyName("isBanned") @set:PropertyName("isBanned")
    var isBanned: Boolean = false,
    val banReason: String = "",
    val avatarId: String = "",
    val bannerId: String = "",
    val username: String = "",
    val bio: String = "",
    val upiId: String = "",
    @get:PropertyName("isDeleted") @set:PropertyName("isDeleted")
    var isDeleted: Boolean = false,
    val accountStatus: String = "active",
    val firstWithdrawalBonusClaimed: Boolean = false,
    val maintenanceLocked: Boolean = false,
    val referralCode: String = "",
    val referredByCode: String = "",
    val referredByUserId: String = "",
    val referralCommissionRatePercent: Long = 5L,
    val referralCommissionEarned: Long = 0L,
    val lastCreditedCompletedTasksCount: Long = 0L,
    val lastCompletedTaskReward: Long = 50L,
    val dailyStreakDays: Long = 1L,
    val lastStreakDate: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class MaintenanceConfig(
    @DocumentId val id: String = "",
    val enabled: Boolean = false,
    val maintenanceMode: Boolean = false,
    val active: Boolean = false,
    val message: String = "Our team is currently working on system upgrades and improvements to bring you a better experience. Everything will be back to normal shortly."
) {
    val isMaintenanceActive: Boolean
        get() = enabled || maintenanceMode || active
}

@IgnoreExtraProperties
data class ReferralCommissionEvent(
    @DocumentId val id: String = "",
    val referrerUserId: String = "",
    val referrerCode: String = "",
    val referredUserId: String = "",
    val referredUserName: String = "",
    val referredUserEmail: String = "",
    val completedTasksCountSnapshot: Long = 1L,
    val taskRewardAmount: Long = 50L,
    val commissionPercent: Long = 5L,
    val commissionAmount: Long = 1L,
    val taskTitle: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class AiTaskVerificationResult(
    val completionPercentage: Int,
    val matchedTaskName: String,
    val status: String, // "approved" or "rejected"
    val originalRewardInr: Long,
    val creditedRewardInr: Long,
    val aiVerdict: String, // "ABOVE_95_FULL_100", "90_PERCENT_40_CREDIT", "85_PERCENT_15_CREDIT", "80_PERCENT_10_CREDIT", "BELOW_80_REJECTED"
    val adminNote: String,
    val aiSummary: String
)

@IgnoreExtraProperties
data class TaskSubmission(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val taskId: String = "",
    val taskTitle: String = "",
    val category: String = "",
    val rewardAmount: Long = 0L,
    val originalRewardAmount: Long = 0L,
    val proofText: String = "",
    val screenshotBase64: String = "",
    val referenceScreenshotUrl: String = "",
    val status: String = "pending",
    val adminNote: String = "",
    val aiVerified: Boolean = false,
    val aiCompletionPercent: Long = 0L,
    val aiVerdict: String = "",
    val aiSummary: String = "",
    val matchedTaskName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AdminTask(
    @DocumentId val id: String = "",
    val title: String = "",
    val subtitle: String = "Install App and Rate",
    val category: String = "Task",
    val rewardInr: Long = 5L,
    val price: Long = 0L,
    val reward: Long = 0L,
    val durationMinutes: Long = 15L,
    val timeLimit: Long = 0L,
    val instructions: List<String> = emptyList(),
    val proofRequirement: String = "Upload a clear screenshot showing the completed task as proof.",
    val active: Boolean = true,
    val appName: String = "",
    val iconUrl: String = "",
    val logoUrl: String = "",
    val appIcon: String = "",
    val imageUrl: String = "",
    val storeUrl: String = "",
    val appLink: String = "",
    val link: String = "",
    val referenceScreenshotUrl: String = "",
    val sampleScreenshotUrl: String = "",
    val exampleScreenshotUrl: String = "",
    val sampleProofUrl: String = "",
    val referenceImage: String = "",
    val referenceScreenshotBase64: String = "",
    val exampleScreenshotBase64: String = "",
    val rating: Double = 4.5,
    val ratingCountLabel: String = "12.8K",
    val installsLabel: String = "10K+ Installs",
    val targetCount: Long = 100L,
    val completedCount: Long = 0L,
    val assignedComment: String = "",
    val comment: String = "",
    val commentsList: List<String> = emptyList(),
    @get:PropertyName("isBulk") @set:PropertyName("isBulk")
    var isBulk: Boolean = false,
    val timerEnabled: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toAvailableTask(): AvailableTask {
        val effectiveReward = when {
            rewardInr > 0L -> rewardInr.toInt()
            price > 0L -> price.toInt()
            reward > 0L -> reward.toInt()
            else -> 5
        }
        val effectiveDuration = when {
            durationMinutes > 0L -> durationMinutes.toInt()
            timeLimit > 0L -> timeLimit.toInt()
            else -> 15
        }
        val resolvedAppName = appName.ifBlank { title.ifBlank { "App Name" } }
        val resolvedStoreUrl = storeUrl.ifBlank { appLink.ifBlank { link } }
        val resolvedIconUrl = iconUrl
            .ifBlank { logoUrl }
            .ifBlank { appIcon }
            .ifBlank { imageUrl }
            .ifBlank { deriveIconUrlFromLink(resolvedStoreUrl) }
        val resolvedReferenceScreenshot = referenceScreenshotUrl
            .ifBlank { sampleScreenshotUrl }
            .ifBlank { exampleScreenshotUrl }
            .ifBlank { sampleProofUrl }
            .ifBlank { referenceImage }
            .ifBlank { referenceScreenshotBase64 }
            .ifBlank { exampleScreenshotBase64 }
        val resolvedComment = assignedComment
            .ifBlank { comment }
            .ifBlank { commentsList.firstOrNull().orEmpty() }
            .ifBlank {
                "Great app! Very easy to use and helpful features. Highly recommended! 👍"
            }

        return AvailableTask(
            id = id.ifBlank { "task_${resolvedAppName.lowercase().replace(Regex("[^a-z0-9]+"), "_")}" },
            title = title.ifBlank { resolvedAppName },
            subtitle = subtitle.ifBlank { "Install App and Rate" },
            category = category.ifBlank { "Task" },
            rewardInr = effectiveReward.coerceAtLeast(1),
            durationMinutes = effectiveDuration.coerceAtLeast(1),
            instructions = if (instructions.isNotEmpty()) {
                instructions
            } else {
                listOf(
                    "Install the app",
                    "Open and use for a few minutes",
                    "Give 5 Star Rating & post the assigned comment",
                    "Take a Screenshot of the completed task"
                )
            },
            proofRequirement = proofRequirement
                .replace("admin panel", "verification team", ignoreCase = true)
                .replace("within the timer", "after completing the steps", ignoreCase = true)
                .ifBlank {
                    "Upload a clear screenshot showing the completed task as proof."
                },
            appName = resolvedAppName,
            iconUrl = resolvedIconUrl,
            storeUrl = resolvedStoreUrl,
            referenceScreenshotUrl = resolvedReferenceScreenshot,
            rating = if (rating > 0.0) rating else 4.5,
            ratingCountLabel = ratingCountLabel.ifBlank { "12.8K" },
            installsLabel = installsLabel.ifBlank { "10K+ Installs" },
            targetCount = targetCount.toInt().coerceAtLeast(1),
            completedCount = completedCount.toInt().coerceAtLeast(0),
            assignedComment = resolvedComment,
            commentsList = commentsList,
            isBulk = isBulk || category.contains("bulk", ignoreCase = true) || targetCount > 1L,
            timerEnabled = false
        )
    }

    companion object {
        fun deriveIconUrlFromLink(rawUrl: String): String {
            val trimmed = rawUrl.trim()
            if (trimmed.isBlank()) return ""
            // If it's already a direct image link, return it directly
            if (trimmed.endsWith(".png", ignoreCase = true) ||
                trimmed.endsWith(".jpg", ignoreCase = true) ||
                trimmed.endsWith(".jpeg", ignoreCase = true) ||
                trimmed.endsWith(".webp", ignoreCase = true) ||
                trimmed.contains("googleusercontent.com", ignoreCase = true) ||
                trimmed.contains("imgur.com", ignoreCase = true)
            ) {
                return trimmed
            }
            // Otherwise use Google high-res favicon/app icon service for the domain/link
            return try {
                val uri = java.net.URI(if (trimmed.startsWith("http")) trimmed else "https://$trimmed")
                val host = uri.host ?: return ""
                "https://www.google.com/s2/favicons?domain=$host&sz=128"
            } catch (_: Exception) {
                ""
            }
        }
    }
}

@IgnoreExtraProperties
data class BroadcastNotification(
    @DocumentId val id: String = "",
    val title: String = "",
    val message: String = "",
    val type: String = "broadcast",
    val targetUserId: String = "all",
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WalletTransaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val amount: Long = 0L,
    val type: String = "admin_credit", // admin_credit, admin_deduct, task_reward, withdrawal, referral_commission
    val note: String = "",
    val status: String = "completed", // pending, approved, processing, paid, completed, rejected
    val payoutMethod: String = "",
    val upiId: String = "",
    val withdrawalId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class AvailableTask(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val rewardInr: Int,
    val durationMinutes: Int,
    val instructions: List<String>,
    val proofRequirement: String,
    val appName: String = "",
    val iconUrl: String = "",
    val storeUrl: String = "",
    val referenceScreenshotUrl: String = "",
    val rating: Double = 4.5,
    val ratingCountLabel: String = "12.8K",
    val installsLabel: String = "10K+ Installs",
    val targetCount: Int = 100,
    val completedCount: Int = 0,
    val assignedComment: String = "Great app! Very easy to use and helpful features. Highly recommended! 👍",
    val commentsList: List<String> = emptyList(),
    val isBulk: Boolean = false,
    val timerEnabled: Boolean = false
)

val DEFAULT_AVAILABLE_TASKS = emptyList<AvailableTask>()
