package com.example.service

import android.app.job.JobParameters
import android.app.job.JobService
import com.example.R
import com.example.data.model.AdminTask
import com.example.data.model.BroadcastNotification
import com.example.data.model.TaskSubmission
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.data.remote.FirebaseEmailDispatchService
import com.example.util.TaskGullakNotificationHelper
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class TaskGullakSyncJobService : JobService() {

    override fun onStartJob(params: JobParameters?): Boolean {
        val ctx = applicationContext
        TaskGullakBackgroundSyncService.startAndEnsureActive(ctx)

        val uid = FirebaseAuth.getInstance().currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: FirebaseEmailDispatchService.resolveActiveFirestoreUserId(ctx)
        if (uid.isNullOrBlank()) {
            jobFinished(params, false)
            return false
        }
        val databaseId = try {
            ctx.getString(R.string.firestore_database_id)
        } catch (_: Exception) {
            "ai-studio-android-taskgull-45f454e1-e861-4298-9c4d-06f7fc422981"
        }

        val firestore = try {
            FirebaseFirestore.getInstance(databaseId)
        } catch (_: Exception) {
            jobFinished(params, false)
            return false
        }

        val broadcastsTask = firestore.collection("broadcasts").get()
        val tasksTask = firestore.collection("tasks").get()
        val submissionsTask = firestore.collection("submissions").whereEqualTo("userId", uid).get()
        val profileTask = firestore.collection("users").document(uid).get()
        val txTask = firestore.collection("users").document(uid).collection("transactions").get()

        Tasks.whenAllComplete(broadcastsTask, tasksTask, submissionsTask, profileTask, txTask)
            .addOnCompleteListener {
                try {
                    if (broadcastsTask.isSuccessful) {
                        val broadcasts = broadcastsTask.result?.documents?.mapNotNull { doc ->
                            try {
                                doc.toObject(BroadcastNotification::class.java)?.copy(id = doc.id)
                            } catch (_: Exception) {
                                null
                            }
                        }.orEmpty()
                        TaskGullakNotificationHelper.processBroadcastsSnapshot(ctx, broadcasts)
                    }

                    if (tasksTask.isSuccessful) {
                        val activeTasks = tasksTask.result?.documents?.mapNotNull { doc ->
                            try {
                                doc.toObject(AdminTask::class.java)?.copy(id = doc.id)
                            } catch (_: Exception) {
                                null
                            }
                        }?.filter { it.active }?.map { it.toAvailableTask() }.orEmpty()
                        TaskGullakNotificationHelper.processTasksSnapshot(ctx, activeTasks)
                    }

                    if (submissionsTask.isSuccessful) {
                        val submissions = submissionsTask.result?.documents?.mapNotNull { doc ->
                            try {
                                doc.toObject(TaskSubmission::class.java)?.copy(id = doc.id)
                            } catch (_: Exception) {
                                null
                            }
                        }.orEmpty()
                        TaskGullakNotificationHelper.processSubmissionsSnapshot(ctx, submissions)
                    }

                    if (profileTask.isSuccessful) {
                        val doc = profileTask.result
                        if (doc != null && doc.exists()) {
                            val profile = try {
                                doc.toObject(UserProfile::class.java)?.copy(userId = uid)
                            } catch (_: Exception) {
                                null
                            }
                            if (profile != null) {
                                TaskGullakNotificationHelper.processUserProfileSnapshot(ctx, profile)
                            }
                        }
                    }

                    if (txTask.isSuccessful) {
                        val transactions = txTask.result?.documents?.mapNotNull { doc ->
                            try {
                                doc.toObject(WalletTransaction::class.java)?.copy(id = doc.id)
                            } catch (_: Exception) {
                                null
                            }
                        }.orEmpty()
                        TaskGullakNotificationHelper.processTransactionsSnapshot(ctx, transactions)
                    }
                } catch (_: Exception) {
                } finally {
                    jobFinished(params, false)
                }
            }

        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        return true
    }
}
