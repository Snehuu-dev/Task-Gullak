package com.example.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.SystemClock
import com.example.R
import com.example.data.model.AdminTask
import com.example.data.model.BroadcastNotification
import com.example.data.model.TaskSubmission
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.data.remote.FirebaseEmailDispatchService
import com.example.util.TaskGullakNotificationHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class TaskGullakBackgroundSyncService : Service() {

    private val activeListeners = mutableListOf<ListenerRegistration>()
    private var attachedUserId: String? = null

    override fun onCreate() {
        super.onCreate()
        TaskGullakNotificationHelper.ensureNotificationChannel(applicationContext)
        attachFirestoreListenersIfNeeded()
        scheduleBackgroundSyncJobs(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        attachFirestoreListenersIfNeeded()
        scheduleBackgroundSyncJobs(applicationContext)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        // When user swipes Task Gullak away from Recent Apps ("Close All"),
        // immediately schedule both a service restart and a JobScheduler wakeup
        // so real-time Admin Panel notifications continue arriving in the background.
        scheduleImmediateServiceRestart(applicationContext)
        scheduleBackgroundSyncJobs(applicationContext, immediateWakeup = true)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        clearListeners()
        super.onDestroy()
    }

    @Synchronized
    private fun attachFirestoreListenersIfNeeded() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: FirebaseEmailDispatchService.resolveActiveFirestoreUserId(applicationContext)
        if (uid.isNullOrBlank()) {
            clearListeners()
            return
        }
        if (attachedUserId == uid && activeListeners.isNotEmpty()) {
            return
        }

        clearListeners()
        attachedUserId = uid

        val ctx = applicationContext
        val databaseId = try {
            ctx.getString(R.string.firestore_database_id)
        } catch (_: Exception) {
            "ai-studio-android-taskgull-45f454e1-e861-4298-9c4d-06f7fc422981"
        }
        val firestore = try {
            FirebaseFirestore.getInstance(databaseId)
        } catch (_: Exception) {
            return
        }

        // 1. Listen for Admin Panel Broadcast Notifications (/broadcasts)
        val broadcastsReg = firestore.collection("broadcasts")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val broadcasts = snapshot.documents.mapNotNull { doc ->
                    try {
                        doc.toObject(BroadcastNotification::class.java)?.copy(id = doc.id)
                    } catch (_: Exception) {
                        null
                    }
                }
                TaskGullakNotificationHelper.processBroadcastsSnapshot(ctx, broadcasts)
            }
        activeListeners.add(broadcastsReg)

        // 2. Listen for Admin Panel Newly Added Tasks (/tasks)
        val tasksReg = firestore.collection("tasks")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val tasks = snapshot.documents.mapNotNull { doc ->
                    try {
                        doc.toObject(AdminTask::class.java)?.copy(id = doc.id)
                    } catch (_: Exception) {
                        null
                    }
                }.filter { it.active }.map { it.toAvailableTask() }
                TaskGullakNotificationHelper.processTasksSnapshot(ctx, tasks)
            }
        activeListeners.add(tasksReg)

        // 3. Listen for Task Approval / Rejection updates (/submissions where userId == uid)
        val submissionsReg = firestore.collection("submissions")
            .whereEqualTo("userId", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val submissions = snapshot.documents.mapNotNull { doc ->
                    try {
                        doc.toObject(TaskSubmission::class.java)?.copy(id = doc.id)
                    } catch (_: Exception) {
                        null
                    }
                }
                TaskGullakNotificationHelper.processSubmissionsSnapshot(ctx, submissions)
            }
        activeListeners.add(submissionsReg)

        // 4. Listen for User Profile Wallet Credit/Deduct & Ban/Unban (/users/{uid})
        val profileReg = firestore.collection("users")
            .document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                val profile = try {
                    snapshot.toObject(UserProfile::class.java)?.copy(userId = uid)
                } catch (_: Exception) {
                    null
                } ?: return@addSnapshotListener
                TaskGullakNotificationHelper.processUserProfileSnapshot(ctx, profile)
            }
        activeListeners.add(profileReg)

        // 5. Listen for Wallet Transactions (/users/{uid}/transactions)
        val txReg = firestore.collection("users")
            .document(uid)
            .collection("transactions")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val transactions = snapshot.documents.mapNotNull { doc ->
                    try {
                        doc.toObject(WalletTransaction::class.java)?.copy(id = doc.id)
                    } catch (_: Exception) {
                        null
                    }
                }
                TaskGullakNotificationHelper.processTransactionsSnapshot(ctx, transactions)
            }
        activeListeners.add(txReg)

        // 6. Real-Time Listener on Referred Users' Firestore Documents (/users where referredByCode == userReferralCode)
        // Tracks successful task completions by referred users and calculates & credits a percentage-based
        // commission to the referrer's wallet in real-time without deducting from the referred user.
        val userReferralCode = FirebaseEmailDispatchService.getOrCreateReferralCode(ctx)
        if (userReferralCode.isNotBlank()) {
            val referredUsersReg = firestore.collection("users")
                .whereEqualTo("referredByCode", userReferralCode)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    snapshot.documents.forEach { doc ->
                        val referredUid = doc.id
                        if (referredUid == uid) return@forEach
                        val completedCount = doc.getLong("completedTasksCount") ?: 0L
                        val alreadyCredited = doc.getLong("lastCreditedCompletedTasksCount") ?: 0L
                        if (completedCount > alreadyCredited) {
                            val referredName = doc.getString("fullName").orEmpty().ifBlank { "Referred Friend" }
                            val taskReward = (doc.getLong("lastCompletedTaskReward") ?: 50L).coerceAtLeast(1L)
                            val ratePercent = (doc.getLong("referralCommissionRatePercent") ?: 5L).coerceIn(1L, 100L)
                            val deltaTasks = (completedCount - alreadyCredited).coerceAtLeast(1L)
                            val singleCommission = ((taskReward * ratePercent) / 100L).coerceAtLeast(1L)
                            val totalCommission = singleCommission * deltaTasks

                            // Advance lastCreditedCompletedTasksCount on the referred user's document first
                            doc.reference.update(
                                mapOf(
                                    "lastCreditedCompletedTasksCount" to completedCount,
                                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                                )
                            ).addOnSuccessListener {
                                // Credit referrer's Firestore wallet in real-time
                                val referrerRef = firestore.collection("users").document(uid)
                                referrerRef.get().addOnSuccessListener { refSnap ->
                                    if (refSnap.exists()) {
                                        val currentBal = refSnap.getLong("walletBalance") ?: 0L
                                        val currentEarned = refSnap.getLong("referralCommissionEarned") ?: 0L
                                        referrerRef.update(
                                            mapOf(
                                                "walletBalance" to (currentBal + totalCommission),
                                                "referralCommissionEarned" to (currentEarned + totalCommission),
                                                "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                                            )
                                        )
                                        referrerRef.collection("transactions").add(
                                            mapOf(
                                                "userId" to uid,
                                                "amount" to totalCommission,
                                                "type" to "referral_commission",
                                                "note" to "${ratePercent}% Referral Commission: $referredName completed $deltaTasks task(s) (+₹$totalCommission)",
                                                "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                                            )
                                        )
                                    }
                                }
                                FirebaseEmailDispatchService.creditReferrerLifetimeBonusForTask(
                                    context = ctx,
                                    taskRewardCoins = (taskReward.toInt() * 100 * deltaTasks.toInt()).coerceAtLeast(100),
                                    taskTitle = "$referredName's Task Completion"
                                )
                                TaskGullakNotificationHelper.showSystemNotification(
                                    context = ctx,
                                    uniqueKey = "ref_comm_${referredUid}_$completedCount",
                                    title = "Referral Commission! +₹$totalCommission Credited",
                                    message = "$referredName completed a task! Your $ratePercent% lifetime referral bonus was added to your wallet."
                                )
                            }
                        }
                    }
                }
            activeListeners.add(referredUsersReg)
        }
    }

    @Synchronized
    private fun clearListeners() {
        activeListeners.forEach { reg ->
            try {
                reg.remove()
            } catch (_: Exception) {
            }
        }
        activeListeners.clear()
        attachedUserId = null
    }

    companion object {
        private const val JOB_ID_PERIODIC_SYNC = 4501
        private const val JOB_ID_IMMEDIATE_WAKEUP = 4502
        private const val REQUEST_CODE_RESTART = 4503

        fun startAndEnsureActive(context: Context) {
            val appCtx = context.applicationContext
            TaskGullakNotificationHelper.ensureNotificationChannel(appCtx)
            scheduleBackgroundSyncJobs(appCtx)
            try {
                val intent = Intent(appCtx, TaskGullakBackgroundSyncService::class.java)
                appCtx.startService(intent)
            } catch (_: IllegalStateException) {
                // If app is in restricted background state, trigger immediate JobScheduler sync instead
                scheduleBackgroundSyncJobs(appCtx, immediateWakeup = true)
            } catch (_: Exception) {
            }
        }

        fun stopSyncWhenSignedOut(context: Context) {
            val appCtx = context.applicationContext
            try {
                appCtx.stopService(Intent(appCtx, TaskGullakBackgroundSyncService::class.java))
                val scheduler = appCtx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler
                scheduler?.cancel(JOB_ID_PERIODIC_SYNC)
                scheduler?.cancel(JOB_ID_IMMEDIATE_WAKEUP)
            } catch (_: Exception) {
            }
        }

        internal fun scheduleImmediateServiceRestart(context: Context) {
            try {
                val restartIntent = Intent(context.applicationContext, TaskGullakBackgroundSyncService::class.java).apply {
                    setPackage(context.packageName)
                }
                val pendingIntent = PendingIntent.getService(
                    context.applicationContext,
                    REQUEST_CODE_RESTART,
                    restartIntent,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                alarmManager?.set(
                    AlarmManager.ELAPSED_REALTIME,
                    SystemClock.elapsedRealtime() + 1500L,
                    pendingIntent
                )
            } catch (_: Exception) {
            }
        }

        internal fun scheduleBackgroundSyncJobs(context: Context, immediateWakeup: Boolean = false) {
            try {
                val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler
                    ?: return
                val componentName = ComponentName(context, TaskGullakSyncJobService::class.java)

                val periodicExists = scheduler.allPendingJobs.any { it.id == JOB_ID_PERIODIC_SYNC }
                if (!periodicExists) {
                    val periodicJob = JobInfo.Builder(JOB_ID_PERIODIC_SYNC, componentName)
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                        .setPeriodic(15 * 60 * 1000L)
                        .build()
                    scheduler.schedule(periodicJob)
                }

                if (immediateWakeup) {
                    val oneOffJob = JobInfo.Builder(JOB_ID_IMMEDIATE_WAKEUP, componentName)
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                        .setMinimumLatency(1000L)
                        .setOverrideDeadline(5000L)
                        .build()
                    scheduler.schedule(oneOffJob)
                }
            } catch (_: Exception) {
            }
        }
    }
}
