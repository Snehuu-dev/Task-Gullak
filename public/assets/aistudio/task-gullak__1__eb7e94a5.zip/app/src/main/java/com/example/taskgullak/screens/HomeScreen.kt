package com.example.taskgullak.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocalOffer
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.PersonAddAlt
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.AiTaskVerificationResult
import com.example.data.model.AvailableTask
import com.example.data.model.BroadcastNotification
import com.example.data.model.DEFAULT_AVAILABLE_TASKS
import com.example.data.model.MaintenanceConfig
import com.example.data.model.TaskSubmission
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.taskgullak.components.Glossy3DCheckBadge
import com.example.taskgullak.components.Glossy3DTaskIcon
import com.example.taskgullak.components.ShinyGradientButton
import com.example.taskgullak.components.Task3DIconType
import com.example.taskgullak.theme.InterFontFamily
import com.example.taskgullak.theme.PoppinsFontFamily
import com.example.taskgullak.theme.TgAuthError
import com.example.taskgullak.theme.TgAuthPurple
import com.example.taskgullak.theme.TgBluePrimary
import com.example.taskgullak.theme.TgPurpleSecondary
import com.example.taskgullak.theme.TgRewardGold
import com.example.taskgullak.theme.TgSlateMuted
import com.example.taskgullak.theme.TgSplashDarkText
import com.example.taskgullak.theme.TgSuccessGreen
import com.example.data.remote.FirebaseEmailDispatchService
import com.example.service.TaskGullakFcmClient
import com.example.util.TaskGullakNotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

private enum class HomeBottomTab(val index: Int, val label: String) {
    Tasks(0, "Tasks"),
    Refer(1, "Refer"),
    Home(2, "Home"),
    Wallet(3, "Wallet"),
    Profile(4, "Profile")
}

private enum class SummaryStatKey(val label: String, val color: Color) {
    Pending("Pending Review", Color(0xFFF5A524)),
    Approved("Approved", Color(0xFF10B981)),
    Rejected("Rejected", Color(0xFFF43F5E))
}

private val HomeRiseEasing = CubicBezierEasing(0.2f, 0.75f, 0.25f, 1.0f)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel?,
    fallbackName: String,
    fallbackEmail: String,
    onNavigateToTerms: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onReplayOnboarding: () -> Unit,
    onSignOut: () -> Unit,
    initialOpenNotifications: Boolean = false
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val profileUiState = viewModel?.profileState?.collectAsStateWithLifecycle()?.value
    val submissionsUiState = viewModel?.submissionsState?.collectAsStateWithLifecycle()?.value
    val activeTasksUiState = viewModel?.activeTasksState?.collectAsStateWithLifecycle()?.value
    val broadcastsUiState = viewModel?.broadcastsState?.collectAsStateWithLifecycle()?.value
    val transactionsUiState = viewModel?.transactionsState?.collectAsStateWithLifecycle()?.value
    val vmFeedbackMsg = viewModel?.submissionFeedback?.collectAsStateWithLifecycle()?.value
    val vmIsSubmitting = viewModel?.isSubmitting?.collectAsStateWithLifecycle()?.value ?: false
    val vmIsWithdrawing = viewModel?.isWithdrawing?.collectAsStateWithLifecycle()?.value ?: false
    val vmWithdrawFeedback = viewModel?.withdrawFeedback?.collectAsStateWithLifecycle()?.value
    val vmSelectedAvatarId = viewModel?.selectedAvatarId?.collectAsStateWithLifecycle()?.value.orEmpty()
    val vmNameOverride = viewModel?.nameOverride?.collectAsStateWithLifecycle()?.value
    val vmIsSavingProfile = viewModel?.isSavingProfile?.collectAsStateWithLifecycle()?.value ?: false
    val vmIsRefreshing = viewModel?.isRefreshing?.collectAsStateWithLifecycle()?.value ?: false
    val referredUsers = viewModel?.referredUsersState?.collectAsStateWithLifecycle()?.value.orEmpty()
    val maintenanceConfig = viewModel?.maintenanceState?.collectAsStateWithLifecycle()?.value
    val receivedPushList by TaskGullakNotificationHelper.receivedPushFlow.collectAsStateWithLifecycle()

    val localSubmissions = remember { mutableStateListOf<TaskSubmission>() }
    val localTransactions = remember { mutableStateListOf<WalletTransaction>() }
    var localBalanceDeduction by remember { mutableStateOf(0L) }
    var localFeedbackMsg by remember { mutableStateOf<String?>(null) }
    var localWithdrawFeedback by remember { mutableStateOf<String?>(null) }
    var localAvatarId by remember {
        mutableStateOf(FirebaseEmailDispatchService.getSavedUserAvatarId(context, fallbackEmail))
    }
    var localNameOverride by remember { mutableStateOf<String?>(null) }
    var localIsRefreshing by remember { mutableStateOf(false) }
    val isPullRefreshing = vmIsRefreshing || localIsRefreshing

    val triggerHomeRefresh: () -> Unit = {
        if (viewModel != null) {
            viewModel.refreshData {
                FirebaseEmailDispatchService.syncAllKnownLocalAccountsToFirestore(context)
                TaskGullakNotificationHelper.loadPersistedPushHistory(context)
            }
        } else {
            coroutineScope.launch {
                localIsRefreshing = true
                FirebaseEmailDispatchService.syncAllKnownLocalAccountsToFirestore(context)
                TaskGullakNotificationHelper.loadPersistedPushHistory(context)
                delay(450)
                localIsRefreshing = false
            }
        }
    }

    var activeTab by remember { mutableStateOf(HomeBottomTab.Home) }
    var selectedTask by remember { mutableStateOf<AvailableTask?>(null) }
    var proofInput by remember { mutableStateOf("") }
    var proofError by remember { mutableStateOf<String?>(null) }
    var showNotificationsScreen by remember { mutableStateOf(initialOpenNotifications) }
    var topCardThemeIndex by remember { mutableIntStateOf(0) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* handled gracefully */ }
    )

    // Initial skeleton shimmer state + Notification channel, FCM client & permission initialization
    var initialSkeletonActive by remember { mutableStateOf(true) }
    var enterAnimTriggered by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val savedAvatar = FirebaseEmailDispatchService.getSavedUserAvatarId(context, fallbackEmail)
        if (savedAvatar.isNotBlank()) {
            localAvatarId = savedAvatar
            viewModel?.setInitialAvatarIfBlank(savedAvatar)
        }
        TaskGullakNotificationHelper.ensureNotificationChannel(context)
        TaskGullakFcmClient.initialize(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !TaskGullakNotificationHelper.hasNotificationPermission(context)
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        enterAnimTriggered = true
        delay(850)
        initialSkeletonActive = false
    }

    val isRemoteLoading = (profileUiState is UiState.Loading && submissionsUiState is UiState.Loading)
    val isSkeletonLoading = initialSkeletonActive || isRemoteLoading

    val profile: UserProfile? = (profileUiState as? UiState.Success)?.data
    val remoteSubmissions: List<TaskSubmission> =
        (submissionsUiState as? UiState.Success)?.data ?: emptyList()
    val submissions: List<TaskSubmission> = if (remoteSubmissions.isNotEmpty()) {
        remoteSubmissions
    } else {
        localSubmissions
    }
    val availableTasks: List<AvailableTask> =
        (activeTasksUiState as? UiState.Success)?.data ?: DEFAULT_AVAILABLE_TASKS
    val broadcasts: List<BroadcastNotification> =
        (broadcastsUiState as? UiState.Success)?.data ?: emptyList()
    val remoteTransactions: List<WalletTransaction> =
        (transactionsUiState as? UiState.Success)?.data ?: emptyList()
    val transactions: List<WalletTransaction> = if (remoteTransactions.isNotEmpty()) {
        remoteTransactions
    } else {
        localTransactions
    }

    val feedbackMsg = vmFeedbackMsg ?: localFeedbackMsg
    val withdrawFeedbackMsg = vmWithdrawFeedback ?: localWithdrawFeedback

    val walletBalance = (
        profile?.walletBalance ?: submissions
            .filter { it.status == "verified" || it.status == "approved" }
            .sumOf { it.rewardAmount }
        ).let { (it - localBalanceDeduction).coerceAtLeast(0L) }

    val displayName = (
        localNameOverride?.takeIf { it.isNotBlank() }
            ?: vmNameOverride?.takeIf { it.isNotBlank() }
            ?: profile?.fullName?.takeIf { it.isNotBlank() }
            ?: fallbackName
        )
        .trim()
        .ifBlank { "Divyanshu" }
    val firstName = displayName.substringBefore(" ").ifBlank { "Divyanshu" }
    val userInitial = firstName.firstOrNull()?.uppercaseChar()?.toString() ?: "D"
    val displayEmail = (profile?.email?.takeIf { it.isNotBlank() } ?: fallbackEmail)
        .trim()
        .ifBlank { "member@taskgullak.app" }

    val currentAvatarId = vmSelectedAvatarId.takeIf { it.isNotBlank() }
        ?: localAvatarId.takeIf { it.isNotBlank() }
        ?: profile?.avatarId?.takeIf { it.isNotBlank() }
        ?: ""

    LaunchedEffect(profile?.avatarId) {
        val remoteAvatar = profile?.avatarId?.trim().orEmpty()
        if (remoteAvatar.isNotBlank() && localAvatarId.isBlank()) {
            localAvatarId = remoteAvatar
            FirebaseEmailDispatchService.saveUserAvatarId(context, remoteAvatar, displayEmail)
        }
    }

    // Real-time system notification listeners for Admin Panel actions (shared with background service)
    LaunchedEffect(activeTasksUiState) {
        val tasksList = (activeTasksUiState as? UiState.Success)?.data ?: return@LaunchedEffect
        TaskGullakNotificationHelper.processTasksSnapshot(context, tasksList)
    }

    LaunchedEffect(broadcastsUiState) {
        val list = (broadcastsUiState as? UiState.Success)?.data ?: return@LaunchedEffect
        TaskGullakNotificationHelper.processBroadcastsSnapshot(context, list)
    }

    LaunchedEffect(submissionsUiState) {
        val list = (submissionsUiState as? UiState.Success)?.data ?: return@LaunchedEffect
        TaskGullakNotificationHelper.processSubmissionsSnapshot(context, list)
    }

    LaunchedEffect(transactionsUiState) {
        val list = (transactionsUiState as? UiState.Success)?.data ?: return@LaunchedEffect
        TaskGullakNotificationHelper.processTransactionsSnapshot(context, list)
    }

    LaunchedEffect(profile?.walletBalance, profile?.isBanned) {
        val currentProfile = profile ?: return@LaunchedEffect
        TaskGullakNotificationHelper.processUserProfileSnapshot(context, currentProfile)
    }

    LaunchedEffect(profile?.isDeleted, profile?.accountStatus) {
        val currentProfile = profile ?: return@LaunchedEffect
        if (currentProfile.isDeleted || currentProfile.accountStatus.equals("deleted", ignoreCase = true)) {
            onSignOut()
        }
    }

    val walletIdCode = remember(displayEmail) {
        val seed = displayEmail.uppercase()
        val hash = seed.hashCode().toUInt().toString(36).uppercase().padStart(8, 'Z')
        "TG-${hash.take(8)}"
    }

    val pendingCount = submissions.count {
        val s = it.status.lowercase()
        s == "pending" || s == "submitted" || s == "under_review"
    }
    val approvedCount = submissions.count {
        val s = it.status.lowercase()
        s == "verified" || s == "approved"
    }
    val rejectedCount = submissions.count {
        val s = it.status.lowercase()
        s == "rejected" || s == "declined"
    }
    val totalTasks = pendingCount + approvedCount + rejectedCount

    val pendingPct = if (totalTasks > 0) ((pendingCount * 100f) / totalTasks).roundToInt() else 0
    val approvedPct = if (totalTasks > 0) ((approvedCount * 100f) / totalTasks).roundToInt() else 0
    val rejectedPct = if (totalTasks > 0) ((rejectedCount * 100f) / totalTasks).roundToInt() else 0

    // Infinite shimmer & ambient 3D animations matching home.css
    val infiniteTransition = rememberInfiniteTransition(label = "home_infinite")
    val shimmerProgress by infiniteTransition.animateFloat(
        initialValue = -1.2f,
        targetValue = 2.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1300, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sk_shimmer"
    )
    val ringSpinDegrees by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_spin"
    )
    val walletGlowScale by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wallet_glow_scale"
    )
    val walletGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 0.90f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wallet_glow_alpha"
    )
    val rupeeFloatOffsetY by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rupee_float"
    )
    val auroraShiftX by infiniteTransition.animateFloat(
        initialValue = -14f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aurora_shift"
    )
    val navSheenFraction by infiniteTransition.animateFloat(
        initialValue = -0.4f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "nav_sheen"
    )

    // Staggered rise animations matching body.tg-home-enter #home .rise
    val headRise by animateFloatAsState(
        targetValue = if (enterAnimTriggered) 1f else 0f,
        animationSpec = tween(durationMillis = 500, delayMillis = 0, easing = HomeRiseEasing),
        label = "head_rise"
    )
    val walletRise by animateFloatAsState(
        targetValue = if (enterAnimTriggered) 1f else 0f,
        animationSpec = tween(durationMillis = 500, delayMillis = 45, easing = HomeRiseEasing),
        label = "wallet_rise"
    )
    val summaryRise by animateFloatAsState(
        targetValue = if (enterAnimTriggered) 1f else 0f,
        animationSpec = tween(durationMillis = 500, delayMillis = 90, easing = HomeRiseEasing),
        label = "summary_rise"
    )

    val density = LocalDensity.current.density

    val isUnderMaintenance =
        maintenanceConfig?.isMaintenanceActive == true || profile?.maintenanceLocked == true
    if (isUnderMaintenance) {
        val customMsg = maintenanceConfig?.message?.takeIf { it.isNotBlank() }
            ?: "We are currently upgrading the app to bring you a better experience.\nWe'll be back shortly! Thank you for your patience."
        MaintenanceModeFullScreen(message = customMsg)
        return
    }

    if (showNotificationsScreen) {
        NotificationsScreen(
            firstName = firstName,
            broadcasts = broadcasts,
            submissions = submissions,
            transactions = transactions,
            onBack = { showNotificationsScreen = false },
            onRefresh = triggerHomeRefresh
        )
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFF7F8FF),
                        Color(0xFFF3F5FF),
                        Color(0xFFF9F7FF)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .testTag("home_screen")
    ) {
        // Seamless Background Aura Blobs (.aura i in home.html) drawn with unclipped radial gradients
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            drawCircle(
                brush = Brush.radialGradient(
                    colorStops = arrayOf(
                        0.0f to Color(0xFF9171F4).copy(alpha = 0.14f),
                        0.50f to Color(0xFF9171F4).copy(alpha = 0.05f),
                        1.0f to Color.Transparent
                    ),
                    center = Offset(w * 0.90f, h * 0.06f),
                    radius = w * 0.58f
                ),
                radius = w * 0.58f,
                center = Offset(w * 0.90f, h * 0.06f)
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colorStops = arrayOf(
                        0.0f to Color(0xFFFF4F8B).copy(alpha = 0.09f),
                        0.50f to Color(0xFFFF4F8B).copy(alpha = 0.03f),
                        1.0f to Color.Transparent
                    ),
                    center = Offset(w * 0.05f, h * 0.45f),
                    radius = w * 0.54f
                ),
                radius = w * 0.54f,
                center = Offset(w * 0.05f, h * 0.45f)
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colorStops = arrayOf(
                        0.0f to Color(0xFF5CCBFB).copy(alpha = 0.12f),
                        0.50f to Color(0xFF5CCBFB).copy(alpha = 0.04f),
                        1.0f to Color.Transparent
                    ),
                    center = Offset(w * 0.88f, h * 0.84f),
                    radius = w * 0.55f
                ),
                radius = w * 0.55f,
                center = Offset(w * 0.88f, h * 0.84f)
            )
        }

        PullToRefreshBox(
            isRefreshing = isPullRefreshing,
            onRefresh = triggerHomeRefresh,
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_pull_to_refresh_box")
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 10.dp, bottom = 108.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
            // 1. TOP APP BAR (.top: Brand Logo + "Task Gullak" text rendered ONLY on the Home tab)
            if (activeTab == HomeBottomTab.Home) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 520.dp)
                            .graphicsLayer {
                                alpha = headRise
                                translationY = (1f - headRise) * 13f * density
                            },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // .logo (36x36dp, border-radius 11dp, linear-gradient(135deg, indigo, violet 55%, pink))
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .shadow(
                                        elevation = 8.dp,
                                        shape = RoundedCornerShape(11.dp),
                                        spotColor = Color(0xFF5B34D6).copy(alpha = 0.35f)
                                    )
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(
                                                Color(0xFF4F46E5),
                                                Color(0xFF7B3FE4),
                                                Color(0xFFFF4F8B)
                                            )
                                        )
                                    )
                                    .border(
                                        width = 0.8.dp,
                                        color = Color.White.copy(alpha = 0.38f),
                                        shape = RoundedCornerShape(11.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "₹",
                                    color = Color.White,
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                                )
                            }

                            Text(
                                text = "Task Gullak",
                                color = Color(0xFF17142E),
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                letterSpacing = (-0.5).sp
                            )
                        }

                        // Notification Bell Button (.notification-btn) — opens dedicated full-screen NotificationsScreen
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .shadow(
                                    elevation = 8.dp,
                                    shape = RoundedCornerShape(15.dp),
                                    spotColor = Color(0xFF4628BE).copy(alpha = 0.20f)
                                )
                                .clip(RoundedCornerShape(15.dp))
                                .background(Color.White.copy(alpha = 0.90f))
                                .border(
                                    width = 1.dp,
                                    color = Color(0xFF745ED5).copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(15.dp)
                                )
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) { showNotificationsScreen = true }
                                .testTag("home_notification_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.NotificationsNone,
                                contentDescription = "Open notifications",
                                tint = Color(0xFF51439A),
                                modifier = Modifier.size(21.dp)
                            )
                            if (broadcasts.isNotEmpty() || receivedPushList.any { !it.isRead }) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .offset(x = (-9).dp, y = 9.dp)
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFF4F8B))
                                )
                            }
                        }
                    }
                }
            }

            if (profile?.isBanned == true) {
                item {
                    AccountBannedOverlayCard(
                        userName = displayName,
                        userEmail = displayEmail,
                        banReason = profile.banReason,
                        onSignOut = onSignOut
                    )
                }
            } else {
                // MAIN TAB CONTENT
                when (activeTab) {
                    HomeBottomTab.Home -> {
                    // 2. WELCOME CARD (.welcome-card in home.html / home.css)
                    item {
                        val cardGradientColors = when (topCardThemeIndex % 3) {
                            0 -> listOf(
                                Color.White.copy(alpha = 0.78f),
                                Color(0xFFF8F4FF).copy(alpha = 0.68f),
                                Color(0xFFF0E8FF).copy(alpha = 0.62f)
                            )
                            1 -> listOf(
                                Color(0xFFFFF7ED).copy(alpha = 0.82f),
                                Color(0xFFFFF1F2).copy(alpha = 0.72f),
                                Color(0xFFF3E8FF).copy(alpha = 0.66f)
                            )
                            else -> listOf(
                                Color(0xFFF0F9FF).copy(alpha = 0.82f),
                                Color(0xFFEDE9FE).copy(alpha = 0.70f),
                                Color(0xFFFCE7F3).copy(alpha = 0.65f)
                            )
                        }
                        val eyebrowText = when (topCardThemeIndex % 3) {
                            0 -> "YOUR SAVINGS JOURNEY"
                            1 -> "DAILY REWARDS & EARNINGS"
                            else -> "TASK GULLAK COMMUNITY"
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 520.dp)
                                .shadow(
                                    elevation = 16.dp,
                                    shape = RoundedCornerShape(26.dp),
                                    spotColor = Color(0xFF5B34D6).copy(alpha = 0.16f)
                                )
                                .clip(RoundedCornerShape(26.dp))
                                .background(Brush.linearGradient(cardGradientColors))
                                .border(
                                    width = 1.2.dp,
                                    color = Color.White.copy(alpha = 0.90f),
                                    shape = RoundedCornerShape(26.dp)
                                )
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) { topCardThemeIndex = (topCardThemeIndex + 1) % 3 }
                                .padding(20.dp)
                                .graphicsLayer {
                                    alpha = headRise
                                    translationY = (1f - headRise) * 16f * density
                                }
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        UserAvatar3DBadge(
                                            avatarId = currentAvatarId,
                                            userInitial = userInitial,
                                            size = 46.dp,
                                            onClick = { activeTab = HomeBottomTab.Profile },
                                            testTag = "home_top_avatar_badge"
                                        )

                                        Column {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(
                                                    text = "Hello, $firstName",
                                                    color = Color(0xFF17142E),
                                                    fontFamily = PoppinsFontFamily,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 18.sp,
                                                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                                                )
                                                Text(text = "👋", fontSize = 15.sp)
                                            }
                                            Text(
                                                text = eyebrowText,
                                                color = Color(0xFF7B3FE4),
                                                fontFamily = PoppinsFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp,
                                                letterSpacing = 1.2.sp
                                            )
                                        }
                                    }

                                    // Referral Quick Pill (.ref-pill)
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(999.dp))
                                            .background(Color(0xFFEDE9FE))
                                            .border(1.dp, Color(0xFFDDD6FE), RoundedCornerShape(999.dp))
                                            .clickable { activeTab = HomeBottomTab.Refer }
                                            .padding(horizontal = 11.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.PersonAddAlt,
                                            contentDescription = null,
                                            tint = Color(0xFF6D28D9),
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Text(
                                            text = "Refer & Earn",
                                            color = Color(0xFF6D28D9),
                                            fontFamily = PoppinsFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // 3. WALLET BALANCE CARD (.wallet-box inside home.html)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .shadow(
                                            elevation = 12.dp,
                                            shape = RoundedCornerShape(20.dp),
                                            spotColor = Color(0xFF32238C).copy(alpha = 0.22f)
                                        )
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(
                                                    Color(0xFF4F46E5),
                                                    Color(0xFF7B3FE4),
                                                    Color(0xFF9333EA)
                                                )
                                            )
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = Color.White.copy(alpha = 0.35f),
                                            shape = RoundedCornerShape(20.dp)
                                        )
                                        .clickable { activeTab = HomeBottomTab.Wallet }
                                        .padding(18.dp)
                                ) {
                                    // Soft Aurora Blob background shimmer
                                    Canvas(modifier = Modifier.matchParentSize()) {
                                        drawCircle(
                                            brush = Brush.radialGradient(
                                                colors = listOf(
                                                    Color.White.copy(alpha = 0.18f),
                                                    Color.Transparent
                                                ),
                                                center = Offset(size.width * 0.85f, size.height * 0.2f),
                                                radius = size.width * 0.5f
                                            )
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Outlined.AccountBalanceWallet,
                                                    contentDescription = null,
                                                    tint = Color(0xFFE0E7FF),
                                                    modifier = Modifier.size(13.dp)
                                                )
                                                Text(
                                                    text = "TOTAL WALLET BALANCE",
                                                    color = Color(0xFFE0E7FF),
                                                    fontFamily = PoppinsFontFamily,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.5.sp,
                                                    letterSpacing = 1.2.sp
                                                )
                                            }

                                            Text(
                                                text = "₹$walletBalance",
                                                color = Color.White,
                                                fontFamily = PoppinsFontFamily,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 32.sp,
                                                letterSpacing = (-1.2).sp,
                                                style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
                                            )

                                            Text(
                                                text = "Tap to view transactions & instant UPI withdrawal",
                                                color = Color(0xFFE0E7FF).copy(alpha = 0.85f),
                                                fontFamily = InterFontFamily,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 10.5.sp
                                            )
                                        }

                                        // Animated Floating Coin Badge (.coin-emblem)
                                        Box(
                                            modifier = Modifier
                                                .size(50.dp)
                                                .shadow(
                                                    elevation = 8.dp,
                                                    shape = CircleShape,
                                                    spotColor = Color(0xFFF59E0B).copy(alpha = 0.40f)
                                                )
                                                .clip(CircleShape)
                                                .background(
                                                    Brush.linearGradient(
                                                        colors = listOf(
                                                            Color(0xFFFEF08A),
                                                            Color(0xFFF59E0B),
                                                            Color(0xFFD97706)
                                                        )
                                                    )
                                                )
                                                .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "₹",
                                                color = Color.White,
                                                fontFamily = PoppinsFontFamily,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 24.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 4. TASK STATUS SUMMARY BREAKDOWN CARD (.summary-card)
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 520.dp)
                                .shadow(
                                    elevation = 12.dp,
                                    shape = RoundedCornerShape(22.dp),
                                    spotColor = Color(0xFF32238C).copy(alpha = 0.12f)
                                )
                                .clip(RoundedCornerShape(22.dp))
                                .background(Color.White.copy(alpha = 0.96f))
                                .border(1.dp, Color.White, RoundedCornerShape(22.dp))
                                .padding(18.dp)
                                .graphicsLayer {
                                    alpha = summaryRise
                                    translationY = (1f - summaryRise) * 16f * density
                                }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Task Status Breakdown",
                                    color = Color(0xFF17142E),
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.5.sp
                                )
                                Text(
                                    text = "$totalTasks Total",
                                    color = Color(0xFF7B3FE4),
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 3 Status Bars (Pending | Approved | Rejected)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatusBreakdownBarItem(
                                    label = "Pending Review",
                                    count = pendingCount,
                                    percentage = pendingPct,
                                    color = Color(0xFFF5A524)
                                )
                                StatusBreakdownBarItem(
                                    label = "Approved & Verified",
                                    count = approvedCount,
                                    percentage = approvedPct,
                                    color = Color(0xFF10B981)
                                )
                                StatusBreakdownBarItem(
                                    label = "Rejected / Re-work",
                                    count = rejectedCount,
                                    percentage = rejectedPct,
                                    color = Color(0xFFF43F5E)
                                )
                            }
                        }
                    }

                    // 5. QUICK ACTIVE TASKS CAROUSEL PREVIEW ON HOME TAB
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 520.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Featured Tasks to Earn",
                                    color = Color(0xFF17142E),
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.5.sp
                                )
                                Text(
                                    text = "View All →",
                                    color = Color(0xFF7B3FE4),
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .clickable { activeTab = HomeBottomTab.Tasks }
                                        .testTag("home_view_all_tasks_link")
                                )
                            }

                            val featuredList = availableTasks.take(3)
                            if (featuredList.isEmpty()) {
                                Text(
                                    text = "No featured tasks available right now.",
                                    color = Color(0xFF6F6E8A),
                                    fontFamily = InterFontFamily,
                                    fontSize = 12.sp
                                )
                            } else {
                                featuredList.forEach { task ->
                                    HomeTaskCardPreview(
                                        task = task,
                                        onClick = { activeTab = HomeBottomTab.Tasks }
                                    )
                                }
                            }
                        }
                    }

                    // 6. LIVE NOTIFICATIONS / BROADCASTS BANNER
                    if (broadcasts.isNotEmpty()) {
                        item {
                            LiveNotificationsBannerPanel(
                                firstName = firstName,
                                broadcasts = broadcasts,
                                onDismiss = {}
                            )
                        }
                    }
                }

                HomeBottomTab.Tasks -> {
                    item {
                        TasksTabShellContent(
                            availableTasks = availableTasks,
                            submissions = submissions,
                            pendingCount = pendingCount,
                            approvedCount = approvedCount,
                            rejectedCount = rejectedCount,
                            walletBalance = walletBalance,
                            isSubmitting = vmIsSubmitting,
                            feedbackMessage = feedbackMsg,
                            onClearFeedback = { localFeedbackMsg = null },
                            onSubmitTaskProof = { task, proofText, screenshotB64, onDone ->
                                if (viewModel != null) {
                                    viewModel.submitProof(
                                        taskId = task.id,
                                        taskTitle = task.title,
                                        category = task.category,
                                        rewardAmount = task.rewardInr.toLong(),
                                        proofText = proofText,
                                        screenshotBase64 = screenshotB64,
                                        referenceScreenshotUrl = task.referenceScreenshotUrl,
                                        assignedComment = task.assignedComment,
                                        appName = task.appName,
                                        userName = displayName,
                                        userEmail = displayEmail,
                                        onComplete = onDone
                                    )
                                } else {
                                    val dummyAi = AiTaskVerificationResult(
                                        completionPercentage = 98,
                                        matchedTaskName = task.appName.ifBlank { task.title },
                                        status = "approved",
                                        originalRewardInr = task.rewardInr.toLong(),
                                        creditedRewardInr = task.rewardInr.toLong(),
                                        aiVerdict = "ABOVE_95_FULL_100",
                                        adminNote = "Verified (98% match): 100% reward credited.",
                                        aiSummary = "Verified successfully."
                                    )
                                    localSubmissions.add(
                                        TaskSubmission(
                                            id = "sub_${System.currentTimeMillis()}",
                                            taskId = task.id,
                                            taskTitle = task.title,
                                            category = task.category,
                                            rewardAmount = task.rewardInr.toLong(),
                                            proofText = proofText,
                                            status = "approved",
                                            aiVerified = true,
                                            aiCompletionPercent = dummyAi.completionPercentage.toLong(),
                                            aiVerdict = dummyAi.aiVerdict,
                                            aiSummary = dummyAi.aiSummary
                                        )
                                    )
                                    localFeedbackMsg = "Task verified & +₹${task.rewardInr} credited!"
                                    onDone(dummyAi)
                                }
                            }
                        )
                    }
                }

                HomeBottomTab.Refer -> {
                    item {
                        ExactReferAndEarnScreen(
                            liveReferredUsers = referredUsers
                        )
                    }
                }

                HomeBottomTab.Wallet -> {
                    item {
                        WalletTabShellContent(
                            walletBalance = walletBalance,
                            transactions = transactions,
                            submissions = submissions,
                            upiId = FirebaseEmailDispatchService.getSavedUpiId(context, displayEmail),
                            isWithdrawing = vmIsWithdrawing,
                            withdrawFeedback = withdrawFeedbackMsg,
                            onSaveUpi = { upi ->
                                if (viewModel != null) {
                                    viewModel.updateUpiId(upi) { saved ->
                                        FirebaseEmailDispatchService.saveUpiId(context, saved, displayEmail)
                                    }
                                } else {
                                    FirebaseEmailDispatchService.saveUpiId(context, upi, displayEmail)
                                    localWithdrawFeedback = "UPI ID saved successfully!"
                                }
                            },
                            onRequestWithdrawal = { amt, method, details ->
                                if (viewModel != null) {
                                    viewModel.requestWithdrawal(amt, method, details) { success, msg ->
                                        if (success) {
                                            localBalanceDeduction += amt
                                        }
                                    }
                                } else {
                                    if (walletBalance >= amt) {
                                        localBalanceDeduction += amt
                                        localTransactions.add(
                                            WalletTransaction(
                                                id = "tx_${System.currentTimeMillis()}",
                                                type = "withdrawal",
                                                amount = amt,
                                                status = "pending",
                                                payoutMethod = method,
                                                upiId = details,
                                                note = "Withdrawal request via $method"
                                            )
                                        )
                                        localWithdrawFeedback = "Withdrawal of ₹$amt requested successfully!"
                                    } else {
                                        localWithdrawFeedback = "Insufficient wallet balance."
                                    }
                                }
                            },
                            onClearWithdrawFeedback = {
                                if (viewModel != null) viewModel.clearWithdrawFeedback()
                                else localWithdrawFeedback = null
                            }
                        )
                    }
                }

                HomeBottomTab.Profile -> {
                    item {
                        ProfileTabShellContent(
                            displayName = displayName,
                            displayEmail = displayEmail,
                            walletIdCode = walletIdCode,
                            currentAvatarId = currentAvatarId,
                            submissions = submissions,
                            onUpdateAvatar = { newAvatarId ->
                                if (viewModel != null) {
                                    viewModel.updateAvatar(newAvatarId) { saved ->
                                        FirebaseEmailDispatchService.saveUserAvatarId(context, saved, displayEmail)
                                    }
                                } else {
                                    localAvatarId = newAvatarId
                                    FirebaseEmailDispatchService.saveUserAvatarId(context, newAvatarId, displayEmail)
                                }
                            },
                            onUpdateDisplayName = { newName, onComplete ->
                                if (viewModel != null) {
                                    viewModel.updateDisplayName(newName, { saved ->
                                        localNameOverride = saved
                                        FirebaseEmailDispatchService.saveUpdatedUserName(context, saved, displayEmail)
                                    }, onComplete)
                                } else {
                                    localNameOverride = newName
                                    FirebaseEmailDispatchService.saveUpdatedUserName(context, newName, displayEmail)
                                    onComplete(true, "Display name updated successfully.")
                                }
                            },
                            onReplayOnboarding = onReplayOnboarding,
                            onSignOut = onSignOut
                        )
                    }
                }
            }
            }
        }

        // 7. BOTTOM NAVIGATION DOCK (.bottom-nav in home.html / home.css)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 480.dp)
                    .shadow(
                        elevation = 20.dp,
                        shape = RoundedCornerShape(26.dp),
                        spotColor = Color(0xFF4628BE).copy(alpha = 0.28f)
                    )
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color.White.copy(alpha = 0.95f))
                    .border(
                        width = 1.2.dp,
                        color = Color(0xFF7B3FE4).copy(alpha = 0.16f),
                        shape = RoundedCornerShape(26.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                HomeNavDockItem(
                    tab = HomeBottomTab.Tasks,
                    icon = Icons.Outlined.LocalOffer,
                    label = "Tasks",
                    isSelected = activeTab == HomeBottomTab.Tasks,
                    onClick = { activeTab = HomeBottomTab.Tasks }
                )
                HomeNavDockItem(
                    tab = HomeBottomTab.Refer,
                    icon = Icons.Outlined.PersonAddAlt,
                    label = "Refer",
                    isSelected = activeTab == HomeBottomTab.Refer,
                    onClick = { activeTab = HomeBottomTab.Refer }
                )
                HomeNavDockItem(
                    tab = HomeBottomTab.Home,
                    icon = Icons.Outlined.Home,
                    label = "Home",
                    isSelected = activeTab == HomeBottomTab.Home,
                    onClick = { activeTab = HomeBottomTab.Home }
                )
                HomeNavDockItem(
                    tab = HomeBottomTab.Wallet,
                    icon = Icons.Outlined.AccountBalanceWallet,
                    label = "Wallet",
                    isSelected = activeTab == HomeBottomTab.Wallet,
                    onClick = { activeTab = HomeBottomTab.Wallet }
                )
                HomeNavDockItem(
                    tab = HomeBottomTab.Profile,
                    icon = Icons.Outlined.PersonOutline,
                    label = "Profile",
                    isSelected = activeTab == HomeBottomTab.Profile,
                    onClick = { activeTab = HomeBottomTab.Profile }
                )
            }
        }
    }
}
}

@Composable
private fun StatusBreakdownBarItem(
    label: String,
    count: Int,
    percentage: Int,
    color: Color
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(color)
                )
                Text(
                    text = label,
                    color = Color(0xFF17142E),
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp
                )
            }
            Text(
                text = "$count tasks ($percentage%)",
                color = Color(0xFF6F6E8A),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Color(0xFFF1F5F9))
        ) {
            val progressWidth = (percentage / 100f).coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .fillMaxWidth(progressWidth)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(999.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun HomeTaskCardPreview(
    task: AvailableTask,
    onClick: () -> Unit
) {
    val appDisplayTitle = task.appName.ifBlank { task.title }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(16.dp),
                spotColor = Color(0xFF32238C).copy(alpha = 0.08f)
            )
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFEDE9FE), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        RemoteAppIconBox(
            iconUrl = task.iconUrl,
            appTitle = appDisplayTitle,
            size = 46.dp,
            cornerRadius = 13.dp
        )

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = appDisplayTitle,
                color = Color(0xFF17142E),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = task.category.ifBlank { "Task Reward" },
                color = Color(0xFF6F6E8A),
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFDCFCE7))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = "+₹${task.rewardInr}",
                color = Color(0xFF15803D),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp,
                style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
            )
        }
    }
}

@Composable
private fun HomeNavDockItem(
    tab: HomeBottomTab,
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeBg = remember {
        Brush.horizontalGradient(
            colors = listOf(Color(0xFF4F46E5), Color(0xFF7B3FE4))
        )
    }

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .then(if (isSelected) Modifier.background(activeBg) else Modifier)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 13.dp, vertical = 7.dp)
            .testTag("nav_tab_${tab.name.lowercase()}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) Color.White else Color(0xFF6F6E8A),
            modifier = Modifier.size(21.dp)
        )
        Text(
            text = label,
            color = if (isSelected) Color.White else Color(0xFF6F6E8A),
            fontFamily = PoppinsFontFamily,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 9.5.sp,
            style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = false))
        )
    }
}

@Composable
private fun MaintenanceModeFullScreen(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .shadow(24.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White)
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFEF3C7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.BugReport,
                    contentDescription = null,
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(32.dp)
                )
            }

            Text(
                text = "Under Maintenance",
                color = Color(0xFF1E293B),
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = message,
                color = Color(0xFF64748B),
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 12.5.sp,
                textAlign = TextAlign.Center,
                lineHeight = 19.sp
            )
        }
    }
}
