package com.example.taskgullak.screens

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Sms
import com.example.R
import com.example.data.remote.FirebaseEmailDispatchService
import com.example.data.remote.PhoneCountryOption
import com.example.data.repository.TaskGullakRepository
import com.example.taskgullak.components.CssGridOverlay
import com.example.taskgullak.components.Floating3DOrb
import com.example.taskgullak.components.ShinyGradientButton
import com.example.taskgullak.theme.InterFontFamily
import com.example.taskgullak.theme.PoppinsFontFamily
import com.example.taskgullak.theme.TgAuthError
import com.example.taskgullak.theme.TgAuthErrorDark
import com.example.taskgullak.theme.TgAuthInputBg
import com.example.taskgullak.theme.TgAuthPurple
import com.example.taskgullak.theme.TgAuthTextMain
import com.example.taskgullak.theme.TgAuthTextMuted
import com.example.taskgullak.theme.TgAuthTextSoft
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.ceil

private val EMAIL_REGEX = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")

data class PendingGooglePasswordSetup(
    val fullName: String,
    val email: String,
    val idToken: String
)

/**
 * Silent Auto-Sign-In on startup using GetGoogleIdOption in its own GetCredentialRequest.
 */
fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    FirebaseEmailDispatchService.cleanupTurn10SyncIfNeeded(context)
    if (Firebase.auth.currentUser != null || FirebaseEmailDispatchService.isUserLoggedIn(context)) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val extractedEmail = googleCred.id
                val extractedName = googleCred.displayName ?: ""
                val existsInDb = FirebaseEmailDispatchService.checkGoogleEmailAccountExistsInDatabase(
                    context = context,
                    rawEmail = extractedEmail
                )
                if (!existsInDb) {
                    onUnauthenticated()
                    return@launch
                }
                FirebaseEmailDispatchService.saveGoogleAccountSession(
                    context = context,
                    fullName = extractedName,
                    email = extractedEmail
                )
                runCatching {
                    val authCredential = GoogleAuthProvider.getCredential(googleCred.idToken, null)
                    Firebase.auth.signInWithCredential(authCredential).await()
                }
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (e: Exception) {
            onUnauthenticated()
        }
    }
}

/**
 * Interactive Google Sign-In using GetSignInWithGoogleOption in its own GetCredentialRequest.
 * Checks if the Google email already exists in the database:
 * - If it exists: signs in and navigates immediately to HomeScreen.
 * - If it does not exist: asks the user to enter Password and Confirm Password first,
 *   and once confirmed, creates the account in the database and logs them in automatically.
 */
fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {},
    onRequirePasswordSetup: (PendingGooglePasswordSetup) -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Google Sign-In configuration missing: default_web_client_id not found")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val activityContext = context as? Activity ?: context
            val result = credentialManager.getCredential(activityContext, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val extractedEmail = googleCred.id.trim().lowercase()
                val extractedName = googleCred.displayName.orEmpty().ifBlank {
                    extractedEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
                }

                // Check if this Google email already exists in the database
                val existsInDatabase = FirebaseEmailDispatchService.checkGoogleEmailAccountExistsInDatabase(
                    context = context,
                    rawEmail = extractedEmail
                )

                if (!existsInDatabase) {
                    // Email does not exist in database yet -> prompt user to enter Password & Confirm Password
                    onRequirePasswordSetup(
                        PendingGooglePasswordSetup(
                            fullName = extractedName,
                            email = extractedEmail,
                            idToken = googleCred.idToken
                        )
                    )
                    return@launch
                }

                // Email already exists in database -> let them in immediately
                FirebaseEmailDispatchService.saveGoogleAccountSession(
                    context = context,
                    fullName = extractedName,
                    email = extractedEmail
                )

                runCatching {
                    val authCredential = GoogleAuthProvider.getCredential(googleCred.idToken, null)
                    Firebase.auth.signInWithCredential(authCredential).await()
                    val firebaseUser = Firebase.auth.currentUser
                    if (firebaseUser != null) {
                        val resolvedName = firebaseUser.displayName?.takeIf { it.isNotBlank() } ?: extractedName
                        val resolvedEmail = firebaseUser.email?.takeIf { it.isNotBlank() } ?: extractedEmail
                        FirebaseEmailDispatchService.saveGoogleAccountSession(
                            context = context,
                            fullName = resolvedName,
                            email = resolvedEmail
                        )
                        TaskGullakRepository(context).ensureOrCreateProfile(
                            fullName = resolvedName,
                            email = resolvedEmail,
                            emailVerified = true,
                            referralCode = FirebaseEmailDispatchService.getOrCreateReferralCode(context, resolvedEmail),
                            referredByCode = FirebaseEmailDispatchService.getReferredByCode(context, resolvedEmail),
                            creditReferrerOnLogin = true
                        )
                    }
                }.onFailure { err ->
                    Log.w("Auth", "Firebase credential link note (continuing with Google profile): ${err.message}")
                }

                onAuthSuccess()
            } else {
                onAuthError("Unexpected credential type")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.w("Auth", "Google Sign-In failed: ${e.message}", e)
            onAuthError(e.localizedMessage ?: "Unable to sign in with Google. Please try again.")
        }
    }
}

/**
 * Signs out of Firebase Auth and clears CredentialManager state.
 */
fun signOutUser(
    context: Context,
    credentialManager: CredentialManager,
    onSignOutComplete: () -> Unit,
    scope: CoroutineScope
) {
    Firebase.auth.signOut()
    FirebaseEmailDispatchService.clearEmailSession(context)
    scope.launch {
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.w("Auth", "Failed to clear credential state: ${e.message}")
        } finally {
            onSignOutComplete()
        }
    }
}

/**
 * Exact 100% UI replica of login.html + login.css + login.js
 */
@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    onNavigateToSignup: () -> Unit,
    onNavigateToForgotPassword: (String) -> Unit,
    onNavigateToVerifyEmail: (String) -> Unit,
    onNavigateToTerms: () -> Unit,
    onNavigateToPrivacy: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var statusBannerTitle by remember { mutableStateOf<String?>(null) }
    var statusBannerMessage by remember { mutableStateOf<String?>(null) }
    var unregisteredGmailNoticeEmail by remember { mutableStateOf<String?>(null) }

    var isLoginLoading by remember { mutableStateOf(false) }
    var isGoogleLoading by remember { mutableStateOf(false) }

    // Rate-limit guard from login.js (MAX_FAILED_ATTEMPTS = 5, LOCKOUT_TIME_MS = 15 min)
    var failedAttempts by remember { mutableIntStateOf(0) }
    var lockoutUntil by remember { mutableLongStateOf(0L) }

    fun registerFailedAttempt() {
        failedAttempts += 1
        if (failedAttempts >= 5) {
            lockoutUntil = System.currentTimeMillis() + 15 * 60 * 1000L
            emailError = "5 failed attempts reached. Login locked for 15 minutes."
        }
    }

    fun triggerGoogleSignIn() {
        if (isGoogleLoading || isLoginLoading) return
        isGoogleLoading = true
        emailError = null
        passwordError = null
        statusBannerTitle = null
        onGoogleSignInClicked(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isGoogleLoading = false
                failedAttempts = 0
                lockoutUntil = 0L
                onLoginSuccess()
            },
            onAuthError = { errMsg ->
                isGoogleLoading = false
                statusBannerTitle = "Google Sign-In failed"
                statusBannerMessage = errMsg
            },
            scope = coroutineScope,
            onAuthCancelled = {
                isGoogleLoading = false
            },
            onRequirePasswordSetup = { setup ->
                isGoogleLoading = false
                unregisteredGmailNoticeEmail = setup.email
                statusBannerTitle = "Account not created with this Gmail"
                statusBannerMessage =
                    "No Task Gullak account has been created with ${setup.email} yet. Please tap 'Create Account' below to register this Gmail first."
                emailError = "This Gmail (${setup.email}) is not registered yet."
            }
        )
    }

    fun handleEmailFormSubmit() {
        if (isLoginLoading || isGoogleLoading) return
        val now = System.currentTimeMillis()
        if (lockoutUntil > now) {
            val remainingMin = ceil((lockoutUntil - now) / 60000.0).toInt()
            emailError = "Too many failed attempts. Try again after $remainingMin minute(s)."
            return
        } else if (lockoutUntil != 0L && now >= lockoutUntil) {
            failedAttempts = 0
            lockoutUntil = 0L
        }

        val cleanEmail = email.trim().lowercase()
        emailError = null
        passwordError = null
        statusBannerTitle = null
        unregisteredGmailNoticeEmail = null

        if (cleanEmail.isEmpty()) {
            emailError = "Please enter your email address."
            return
        }

        if (!EMAIL_REGEX.matches(cleanEmail)) {
            emailError = "Please enter a valid email address."
            return
        }
        if (password.isEmpty()) {
            passwordError = "Please enter your password."
            return
        }

        isLoginLoading = true
        coroutineScope.launch {
            val result = FirebaseEmailDispatchService.signInEmailAccount(
                context = context,
                rawEmail = cleanEmail,
                password = password
            )
            if (!result.success) {
                isLoginLoading = false
                registerFailedAttempt()
                statusBannerTitle = result.title
                statusBannerMessage = result.message
                if (result.title.contains("Create an account", ignoreCase = true)) {
                    emailError = "Please create an account first."
                }
                return@launch
            }

            failedAttempts = 0
            lockoutUntil = 0L

            if (!result.emailVerified) {
                isLoginLoading = false
                onNavigateToVerifyEmail(cleanEmail)
                return@launch
            }

            FirebaseEmailDispatchService.setUserLoggedIn(context, true)
            isLoginLoading = false
            onLoginSuccess()
        }
    }

    AuthPurpleBackground(testTag = "login_screen") {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // BRAND HEADER (.login-brand)
            AuthBrandHeader()

            Spacer(modifier = Modifier.height(13.dp))

            // LOGIN CARD (.login-card)
            run {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 385.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(20.dp),
                        ambientColor = Color(0xFF472B6C).copy(alpha = 0.12f),
                        spotColor = Color(0xFF472B6C).copy(alpha = 0.15f)
                    )
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.97f))
                    .border(1.dp, Color(0xFF483265).copy(alpha = 0.085f), RoundedCornerShape(20.dp))
                    .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 16.dp)
            ) {
                // Card Top-Right Glow (.card-glow)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 70.dp, y = (-115).dp)
                        .size(170.dp)
                        .blur(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF835BDB).copy(alpha = 0.08f))
                )

                Column(modifier = Modifier.fillMaxWidth()) {
                    // HEADER (.login-header)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(TgAuthPurple.copy(alpha = 0.065f))
                            .border(1.dp, TgAuthPurple.copy(alpha = 0.11f), RoundedCornerShape(999.dp))
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(TgAuthPurple)
                        )
                        Text(
                            text = "Secure Login",
                            color = Color(0xFF704DC5),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(9.dp))

                    Text(
                        text = "Welcome back",
                        style = TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF2B2435),
                                    Color(0xFF543795),
                                    Color(0xFF7955CC),
                                    Color(0xFF916FDF)
                                )
                            ),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 23.sp,
                            lineHeight = 27.sp,
                            letterSpacing = (-0.8).sp
                        )
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "Login to continue earning with Task Gullak.",
                        color = TgAuthTextSoft,
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(13.dp))

                    // GLOBAL STATUS (.login-status)
                    if (statusBannerTitle != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 11.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(TgAuthError.copy(alpha = 0.05f))
                                .border(1.dp, TgAuthError.copy(alpha = 0.34f), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(23.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(TgAuthError.copy(alpha = 0.08f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ErrorOutline,
                                    contentDescription = null,
                                    tint = TgAuthError,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = statusBannerTitle ?: "",
                                    color = TgAuthErrorDark,
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = statusBannerMessage ?: "",
                                    color = Color(0xFF97616B),
                                    fontFamily = InterFontFamily,
                                    fontSize = 9.sp,
                                    lineHeight = 13.sp
                                )
                                if (!unregisteredGmailNoticeEmail.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Create Account with ${unregisteredGmailNoticeEmail} →",
                                        color = Color(0xFF704AC8),
                                        fontFamily = PoppinsFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.5.sp,
                                        modifier = Modifier
                                            .clickable { onNavigateToSignup() }
                                            .testTag("login_unregistered_gmail_create_btn")
                                    )
                                }
                            }
                        }
                    }

                    // EMAIL INPUT (.input-group)
                    AuthInputField(
                        label = "Email address",
                        value = email,
                        onValueChange = {
                            email = it
                            emailError = null
                        },
                        placeholder = "Enter your email",
                        leadingIcon = Icons.Outlined.MailOutline,
                        errorMessage = emailError,
                        hintText = "Use the email linked to your Task Gullak account.",
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Next
                        ),
                        testTag = "login_email_input"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // PASSWORD INPUT (.input-group)
                    AuthInputField(
                        label = "Password",
                        value = password,
                        onValueChange = {
                            password = it
                            passwordError = null
                        },
                        placeholder = "Enter your password ",
                        leadingIcon = Icons.Outlined.Lock,
                        errorMessage = passwordError,
                        isPassword = true,
                        passwordVisible = passwordVisible,
                        onTogglePasswordVisibility = { passwordVisible = !passwordVisible },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        testTag = "login_password_input"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // FORM OPTIONS (.form-options)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 11.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Lock,
                                contentDescription = null,
                                tint = Color(0xFF918B98),
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "Secure sign in",
                                color = Color(0xFF918B98),
                                fontFamily = PoppinsFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 9.sp
                            )
                        }

                        Text(
                            text = "Forgot password?",
                            color = Color(0xFF704AC8),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.5.sp,
                            modifier = Modifier
                                .clickable { onNavigateToForgotPassword(email.trim()) }
                                .padding(vertical = 2.dp)
                                .testTag("forgot_password_link")
                        )
                    }

                    // LOGIN BUTTON (.login-button)
                    ShinyGradientButton(
                        text = if (isLoginLoading) "Logging in..." else "Login to Task Gullak",
                        onClick = { handleEmailFormSubmit() },
                        gradientColors = listOf(
                            Color(0xFF7046CE),
                            Color(0xFF8057DB),
                            Color(0xFF6A3EC5)
                        ),
                        height = 44.dp,
                        cornerRadius = 11.dp,
                        fontSizeSp = 11f,
                        isLoading = isLoginLoading,
                        testTag = "login_submit_button"
                    )

                    // DIVIDER (.auth-divider)
                    AuthOrDivider()

                    // GOOGLE LOGIN BUTTON (.google-login-button)
                    GoogleAuthButton(
                        text = if (isGoogleLoading) "Signing in..." else "Continue with Google",
                        isLoading = isGoogleLoading,
                        onClick = { triggerGoogleSignIn() },
                        testTag = "google_login_button"
                    )

                    // CREATE ACCOUNT SWITCH (.signup-switch)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Don't have an account? ",
                            color = TgAuthTextSoft,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "Create Account",
                            color = Color(0xFF704AC8),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .clickable { onNavigateToSignup() }
                                .padding(vertical = 2.dp)
                                .testTag("signup_switch_link")
                        )
                    }
                }
            }
            }

            Spacer(modifier = Modifier.height(13.dp))

            // FOOTER LINKS (.auth-footer-links)
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Terms & Conditions",
                    color = Color(0xFF918A9C),
                    fontFamily = PoppinsFontFamily,
                    fontSize = 9.5.sp,
                    modifier = Modifier
                        .clickable { onNavigateToTerms() }
                        .testTag("login_terms_link")
                )
                Text(
                    text = "•",
                    color = Color(0xFF918A9C),
                    fontSize = 9.5.sp
                )
                Text(
                    text = "Privacy Policy",
                    color = Color(0xFF918A9C),
                    fontFamily = PoppinsFontFamily,
                    fontSize = 9.5.sp,
                    modifier = Modifier
                        .clickable { onNavigateToPrivacy() }
                        .testTag("login_privacy_link")
                )
            }
        }
    }
}

/**
 * Exact 100% UI replica of signup.html + signup.css + signup.js
 */
@Composable
fun SignupScreen(
    onSignupGoogleSuccess: () -> Unit,
    onSignupEmailSubmitted: (String, String) -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToTerms: () -> Unit,
    onNavigateToPrivacy: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }

    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmError by remember { mutableStateOf<String?>(null) }

    var statusBannerTitle by remember { mutableStateOf<String?>(null) }
    var statusBannerMessage by remember { mutableStateOf<String?>(null) }
    var isSignupLoading by remember { mutableStateOf(false) }
    var isGoogleLoading by remember { mutableStateOf(false) }

    // Google Sign-In Pending Password Setup Dialog State
    var pendingGoogleSetup by remember { mutableStateOf<PendingGooglePasswordSetup?>(null) }
    var googleSetupPassword by remember { mutableStateOf("") }
    var googleSetupConfirm by remember { mutableStateOf("") }
    var googleSetupPasswordError by remember { mutableStateOf<String?>(null) }
    var isGoogleSetupLoading by remember { mutableStateOf(false) }

    fun triggerGoogleSignup() {
        if (isGoogleLoading || isSignupLoading) return
        isGoogleLoading = true
        statusBannerTitle = null
        onGoogleSignInClicked(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isGoogleLoading = false
                onSignupGoogleSuccess()
            },
            onAuthError = { errMsg ->
                isGoogleLoading = false
                statusBannerTitle = "Google Sign-In failed"
                statusBannerMessage = errMsg
            },
            scope = coroutineScope,
            onAuthCancelled = {
                isGoogleLoading = false
            },
            onRequirePasswordSetup = { setup ->
                isGoogleLoading = false
                pendingGoogleSetup = setup
            }
        )
    }

    fun handleGooglePasswordSetupSubmit() {
        val setup = pendingGoogleSetup ?: return
        if (googleSetupPassword.length < 6) {
            googleSetupPasswordError = "Password must be at least 6 characters."
            return
        }
        if (googleSetupPassword != googleSetupConfirm) {
            googleSetupPasswordError = "Passwords do not match."
            return
        }
        googleSetupPasswordError = null
        isGoogleSetupLoading = true

        coroutineScope.launch {
            val result = FirebaseEmailDispatchService.registerEmailAccountAndSendVerification(
                context = context,
                fullName = setup.fullName,
                rawEmail = setup.email,
                password = googleSetupPassword
            )
            isGoogleSetupLoading = false
            if (!result.success) {
                statusBannerTitle = result.title
                statusBannerMessage = result.message
                pendingGoogleSetup = null
                return@launch
            }
            pendingGoogleSetup = null
            onSignupGoogleSuccess()
        }
    }

    fun handleSignupSubmit() {
        if (isSignupLoading || isGoogleLoading) return
        val cleanName = fullName.trim()
        val cleanEmail = email.trim().lowercase()

        nameError = null
        emailError = null
        passwordError = null
        confirmError = null
        statusBannerTitle = null

        if (cleanName.length < 2) {
            nameError = "Please enter your full name (at least 2 characters)."
            return
        }
        if (cleanEmail.isEmpty() || !EMAIL_REGEX.matches(cleanEmail)) {
            emailError = "Please enter a valid email address."
            return
        }
        if (password.length < 6) {
            passwordError = "Password must be at least 6 characters."
            return
        }
        if (password != confirmPassword) {
            confirmError = "Passwords do not match."
            return
        }

        isSignupLoading = true
        coroutineScope.launch {
            val result = FirebaseEmailDispatchService.registerEmailAccountAndSendVerification(
                context = context,
                fullName = cleanName,
                rawEmail = cleanEmail,
                password = password
            )
            isSignupLoading = false
            if (!result.success) {
                statusBannerTitle = result.title
                statusBannerMessage = result.message
                return@launch
            }

            onSignupEmailSubmitted(cleanName, cleanEmail)
        }
    }

    // Google Sign-In Password Setup Dialog for new users
    if (pendingGoogleSetup != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { pendingGoogleSetup = null }) {
            androidx.compose.material3.Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 16.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Set Up Your Password",
                        style = TextStyle(
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = Color(0xFF2B2435)
                        )
                    )
                    Text(
                        text = "Welcome ${pendingGoogleSetup?.fullName}! Since this is your first time signing in with ${pendingGoogleSetup?.email}, please set a secure password for your Task Gullak account.",
                        style = TextStyle(
                            fontFamily = InterFontFamily,
                            fontSize = 11.5.sp,
                            color = TgAuthTextSoft,
                            lineHeight = 16.sp
                        ),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    AuthInputField(
                        label = "Create Password",
                        value = googleSetupPassword,
                        onValueChange = {
                            googleSetupPassword = it
                            googleSetupPasswordError = null
                        },
                        placeholder = "At least 6 characters",
                        leadingIcon = Icons.Outlined.Lock,
                        isPassword = true,
                        passwordVisible = passwordVisible,
                        onTogglePasswordVisibility = { passwordVisible = !passwordVisible },
                        errorMessage = googleSetupPasswordError,
                        testTag = "google_setup_password_input"
                    )

                    AuthInputField(
                        label = "Confirm Password",
                        value = googleSetupConfirm,
                        onValueChange = {
                            googleSetupConfirm = it
                            googleSetupPasswordError = null
                        },
                        placeholder = "Re-enter password",
                        leadingIcon = Icons.Outlined.Lock,
                        isPassword = true,
                        passwordVisible = confirmPasswordVisible,
                        onTogglePasswordVisibility = { confirmPasswordVisible = !confirmPasswordVisible },
                        testTag = "google_setup_confirm_input"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    ShinyGradientButton(
                        text = if (isGoogleSetupLoading) "Creating account..." else "Complete Registration",
                        onClick = { handleGooglePasswordSetupSubmit() },
                        gradientColors = listOf(Color(0xFF7046CE), Color(0xFF8057DB)),
                        height = 44.dp,
                        cornerRadius = 12.dp,
                        isLoading = isGoogleSetupLoading,
                        testTag = "google_setup_submit_btn"
                    )
                }
            }
        }
    }

    AuthPurpleBackground(testTag = "signup_screen") {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // BRAND HEADER (.signup-brand)
            AuthBrandHeader()

            Spacer(modifier = Modifier.height(13.dp))

            // SIGNUP CARD (.signup-card)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 385.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(20.dp),
                        ambientColor = Color(0xFF472B6C).copy(alpha = 0.12f),
                        spotColor = Color(0xFF472B6C).copy(alpha = 0.15f)
                    )
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.97f))
                    .border(1.dp, Color(0xFF483265).copy(alpha = 0.085f), RoundedCornerShape(20.dp))
                    .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 16.dp)
            ) {
                // Card Glow (.card-glow)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 70.dp, y = (-115).dp)
                        .size(170.dp)
                        .blur(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF835BDB).copy(alpha = 0.08f))
                )

                Column(modifier = Modifier.fillMaxWidth()) {
                    // HEADER (.signup-header)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(TgAuthPurple.copy(alpha = 0.065f))
                            .border(1.dp, TgAuthPurple.copy(alpha = 0.11f), RoundedCornerShape(999.dp))
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(TgAuthPurple)
                        )
                        Text(
                            text = "New Account",
                            color = Color(0xFF704DC5),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(9.dp))

                    Text(
                        text = "Create account",
                        style = TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF2B2435),
                                    Color(0xFF543795),
                                    Color(0xFF7955CC),
                                    Color(0xFF916FDF)
                                )
                            ),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 23.sp,
                            lineHeight = 27.sp,
                            letterSpacing = (-0.8).sp
                        )
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "Join Task Gullak and start earning today.",
                        color = TgAuthTextSoft,
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(13.dp))

                    // GLOBAL STATUS (.signup-status)
                    if (statusBannerTitle != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 11.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(TgAuthError.copy(alpha = 0.05f))
                                .border(1.dp, TgAuthError.copy(alpha = 0.34f), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(23.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(TgAuthError.copy(alpha = 0.08f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ErrorOutline,
                                    contentDescription = null,
                                    tint = TgAuthError,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = statusBannerTitle ?: "",
                                    color = TgAuthErrorDark,
                                    fontFamily = PoppinsFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = statusBannerMessage ?: "",
                                    color = Color(0xFF97616B),
                                    fontFamily = InterFontFamily,
                                    fontSize = 9.sp,
                                    lineHeight = 13.sp
                                )
                            }
                        }
                    }

                    // FULL NAME INPUT (.input-group)
                    AuthInputField(
                        label = "Full Name",
                        value = fullName,
                        onValueChange = {
                            fullName = it
                            nameError = null
                        },
                        placeholder = "Enter your full name",
                        leadingIcon = Icons.Outlined.PersonOutline,
                        errorMessage = nameError,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Next
                        ),
                        testTag = "signup_name_input"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // EMAIL INPUT (.input-group)
                    AuthInputField(
                        label = "Email address",
                        value = email,
                        onValueChange = {
                            email = it
                            emailError = null
                        },
                        placeholder = "Enter your email",
                        leadingIcon = Icons.Outlined.MailOutline,
                        errorMessage = emailError,
                        hintText = "We will send a verification link to this email.",
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Next
                        ),
                        testTag = "signup_email_input"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // PASSWORD INPUT (.input-group)
                    AuthInputField(
                        label = "Password",
                        value = password,
                        onValueChange = {
                            password = it
                            passwordError = null
                        },
                        placeholder = "At least 6 characters",
                        leadingIcon = Icons.Outlined.Lock,
                        errorMessage = passwordError,
                        isPassword = true,
                        passwordVisible = passwordVisible,
                        onTogglePasswordVisibility = { passwordVisible = !passwordVisible },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Next
                        ),
                        testTag = "signup_password_input"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // CONFIRM PASSWORD INPUT (.input-group)
                    AuthInputField(
                        label = "Confirm Password",
                        value = confirmPassword,
                        onValueChange = {
                            confirmPassword = it
                            confirmError = null
                        },
                        placeholder = "Re-enter password",
                        leadingIcon = Icons.Outlined.Lock,
                        errorMessage = confirmError,
                        isPassword = true,
                        passwordVisible = confirmPasswordVisible,
                        onTogglePasswordVisibility = { confirmPasswordVisible = !confirmPasswordVisible },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        testTag = "signup_confirm_password_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // SIGNUP BUTTON (.signup-button)
                    ShinyGradientButton(
                        text = if (isSignupLoading) "Creating account..." else "Create Task Gullak Account",
                        onClick = { handleSignupSubmit() },
                        gradientColors = listOf(
                            Color(0xFF7046CE),
                            Color(0xFF8057DB),
                            Color(0xFF6A3EC5)
                        ),
                        height = 44.dp,
                        cornerRadius = 11.dp,
                        fontSizeSp = 11f,
                        isLoading = isSignupLoading,
                        testTag = "signup_submit_button"
                    )

                    // DIVIDER (.auth-divider)
                    AuthOrDivider()

                    // GOOGLE SIGNUP BUTTON (.google-login-button)
                    GoogleAuthButton(
                        text = if (isGoogleLoading) "Connecting..." else "Continue with Google",
                        isLoading = isGoogleLoading,
                        onClick = { triggerGoogleSignup() },
                        testTag = "google_signup_button"
                    )

                    // LOGIN SWITCH (.login-switch)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Already have an account? ",
                            color = TgAuthTextSoft,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "Login",
                            color = Color(0xFF704AC8),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier
                                .clickable { onNavigateToLogin() }
                                .padding(vertical = 2.dp)
                                .testTag("login_switch_link")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(13.dp))

            // FOOTER LINKS (.auth-footer-links)
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Terms & Conditions",
                    color = Color(0xFF918A9C),
                    fontFamily = PoppinsFontFamily,
                    fontSize = 9.5.sp,
                    modifier = Modifier
                        .clickable { onNavigateToTerms() }
                        .testTag("signup_terms_link")
                )
                Text(
                    text = "•",
                    color = Color(0xFF918A9C),
                    fontSize = 9.5.sp
                )
                Text(
                    text = "Privacy Policy",
                    color = Color(0xFF918A9C),
                    fontFamily = PoppinsFontFamily,
                    fontSize = 9.5.sp,
                    modifier = Modifier
                        .clickable { onNavigateToPrivacy() }
                        .testTag("signup_privacy_link")
                )
            }
        }
    }
}

/**
 * Shared Purple Background shell matching Auth pages.
 */
@Composable
fun AuthPurpleBackground(
    testTag: String = "auth_background",
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFF9F7FF),
                        Color(0xFFF3EFEF),
                        Color(0xFFF5F0FF)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .testTag(testTag)
    ) {
        // Floating 3D Orbs background aesthetics
        Floating3DOrb(
            size = 210.dp,
            colors = listOf(Color(0xFF9333EA).copy(alpha = 0.15f), Color(0xFF7C3AED).copy(alpha = 0.04f)),
            offsetX = (-40).dp,
            offsetY = 40.dp,
            durationMillis = 5000
        )
        Floating3DOrb(
            size = 230.dp,
            colors = listOf(Color(0xFFEC4899).copy(alpha = 0.13f), Color(0xFFDB2777).copy(alpha = 0.03f)),
            offsetX = 200.dp,
            offsetY = 460.dp,
            durationMillis = 5500,
            delayMillis = 800
        )

        // CSS Grid overlay
        CssGridOverlay(
            gridSizeDp = 28.dp,
            lineColor = Color(0x0A7651D6)
        )

        content()
    }
}

@Composable
fun AuthBrandHeader() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = RoundedCornerShape(11.dp),
                    spotColor = Color(0xFF7651D6).copy(alpha = 0.35f)
                )
                .clip(RoundedCornerShape(11.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF7651D6),
                            Color(0xFF9333EA),
                            Color(0xFFEC4899)
                        )
                    )
                )
                .border(
                    width = 0.8.dp,
                    color = Color.White.copy(alpha = 0.40f),
                    shape = RoundedCornerShape(11.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "₹",
                color = Color.White,
                fontFamily = PoppinsFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp
            )
        }

        Text(
            text = "Task Gullak",
            color = Color(0xFF2B2435),
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            letterSpacing = (-0.5).sp
        )
    }
}

@Composable
fun AuthInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    leadingIcon: ImageVector,
    modifier: Modifier = Modifier,
    errorMessage: String? = null,
    hintText: String? = null,
    isPassword: Boolean = false,
    passwordVisible: Boolean = false,
    onTogglePasswordVisibility: () -> Unit = {},
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    testTag: String = "auth_input_field"
) {
    val hasError = !errorMessage.isNullOrBlank()
    val borderColor = if (hasError) TgAuthError.copy(alpha = 0.65f) else TgAuthPurple.copy(alpha = 0.15f)

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label,
            color = Color(0xFF383244),
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 5.dp, start = 2.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .shadow(
                    elevation = 2.dp,
                    shape = RoundedCornerShape(12.dp),
                    spotColor = Color(0xFF7651D6).copy(alpha = 0.05f)
                )
                .clip(RoundedCornerShape(12.dp))
                .background(TgAuthInputBg)
                .border(1.dp, borderColor, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = Color(0xFF867D96),
                    modifier = Modifier.size(17.dp)
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (value.isEmpty()) {
                        Text(
                            text = placeholder,
                            color = TgAuthTextMuted,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Normal,
                            fontSize = 11.5.sp
                        )
                    }
                    BasicTextField(
                        value = value,
                        onValueChange = onValueChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            color = TgAuthTextMain,
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.5.sp
                        ),
                        cursorBrush = SolidColor(TgAuthPurple),
                        visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation() else VisualTransformation.None,
                        keyboardOptions = keyboardOptions,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag(testTag)
                    )
                }

                if (isPassword) {
                    IconButton(
                        onClick = onTogglePasswordVisibility,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                            contentDescription = if (passwordVisible) "Hide password" else "Show password",
                            tint = Color(0xFF867D96),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        if (hasError) {
            Text(
                text = errorMessage ?: "",
                color = TgAuthError,
                fontFamily = InterFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 4.dp, start = 2.dp)
            )
        } else if (!hintText.isNullOrBlank()) {
            Text(
                text = hintText,
                color = TgAuthTextMuted,
                fontFamily = InterFontFamily,
                fontSize = 9.5.sp,
                modifier = Modifier.padding(top = 4.dp, start = 2.dp)
            )
        }
    }
}

@Composable
fun AuthOrDivider() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = TgAuthPurple.copy(alpha = 0.12f)
        )
        Text(
            text = "OR",
            color = TgAuthTextMuted,
            fontFamily = PoppinsFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 9.5.sp,
            letterSpacing = 1.sp
        )
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = TgAuthPurple.copy(alpha = 0.12f)
        )
    }
}

@Composable
fun GoogleAuthButton(
    text: String,
    isLoading: Boolean,
    onClick: () -> Unit,
    testTag: String = "google_auth_button"
) {
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(11.dp),
                spotColor = Color(0xFF17142E).copy(alpha = 0.08f)
            )
            .clip(RoundedCornerShape(11.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(11.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = !isLoading,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = Color(0xFF475569),
                    strokeWidth = 2.dp
                )
                Text(
                    text = text,
                    color = Color(0xFF334155),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp
                )
            }
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Google "G" Badge
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "G",
                        color = Color(0xFF4285F4),
                        fontFamily = PoppinsFontFamily,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = text,
                    color = Color(0xFF1E1B24),
                    fontFamily = PoppinsFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.5.sp
                )
            }
        }
    }
}
