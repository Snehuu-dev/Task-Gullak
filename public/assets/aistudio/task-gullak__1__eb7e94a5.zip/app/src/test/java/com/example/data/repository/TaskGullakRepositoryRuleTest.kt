package com.example.taskgullak.data.repository

import com.example.taskgullak.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskGullakRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureOrCreateProfile_and_submitTaskProof_succeedsForOwner() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = TaskGullakRepository(firestore)

        val profile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.ensureOrCreateProfile(
                fullName = "Alice Verma",
                email = ALICE_EMAIL,
                emailVerified = true
            ).getOrThrow()
        }
        assertNotNull(profile)

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateUserAvatar(avatarId = "avatar_3d_astronaut").getOrThrow()
        }

        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateUserName(fullName = "Alice Sharma").getOrThrow()
        }

        val updatedProfile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getProfileByUserId(uid).getOrThrow()
        }
        assertEquals("Alice Sharma", updatedProfile?.fullName)
        assertEquals("avatar_3d_astronaut", updatedProfile?.avatarId)

        val subId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.submitTaskProof(
                taskId = "task_watch_video",
                taskTitle = "Watch Video",
                category = "Video",
                rewardAmount = 45L,
                proofText = "Completed onboarding video walkthrough and verified.",
                screenshotBase64 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/",
                userName = "Alice Sharma",
                userEmail = ALICE_EMAIL,
                autoVerify = false
            ).getOrThrow()
        }

        val emittedSubs = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserSubmissions(uid).first { list -> list.any { it.id == subId } }
        }
        assertTrue(emittedSubs.any { it.id == subId && it.rewardAmount == 45L && it.status == "pending" })
    }

    @Test
    fun getProfileByUserId_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = TaskGullakRepository(firestore)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.ensureOrCreateProfile("Alice Verma", ALICE_EMAIL, true).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = TaskGullakRepository(firestore)
        val crossResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.getProfileByUserId(aliceUid)
        }
        assertTrue(crossResult.isFailure)
        val fsEx = crossResult.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun observeUserSubmissions_unauthenticated_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = TaskGullakRepository(firestore)
        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeUserSubmissions("unauth_user_123").first()
            }
        } catch (e: Throwable) {
            caught = e
        }
        assertNotNull(caught)
        val fsEx = caught?.unwrapFirestoreException()
        assertNotNull(fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun referredUserTaskCompletion_creditsReferrerWalletCommissionInRealTime() = runBlocking {
        val runSuffix = System.currentTimeMillis()
        val referrerEmail = "alice_ref_${runSuffix}@test.com"
        val referredEmail = "bob_ref_${runSuffix}@test.com"
        val refCode = "ALICE${(runSuffix % 10000)}"

        // 1. Alice is the referrer
        val aliceUid = signInTestUser(referrerEmail)
        val aliceRepo = TaskGullakRepository(firestore)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.ensureOrCreateProfile(
                fullName = "Alice Referrer",
                email = referrerEmail,
                emailVerified = true,
                referralCode = refCode
            ).getOrThrow()
        }

        // 2. Bob signs up & logs in using Alice's referral code -> Alice immediately gets +₹5 login credit
        val bobUid = signInTestUser(referredEmail)
        val bobRepo = TaskGullakRepository(firestore)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.ensureOrCreateProfile(
                fullName = "Bob Referred",
                email = referredEmail,
                emailVerified = true,
                referralCode = "BOB${(runSuffix % 10000)}",
                referredByCode = refCode,
                referredByUserId = aliceUid,
                creditReferrerOnLogin = true
            ).getOrThrow()
        }

        // 3. Bob completes a ₹100 task (autoVerify = true) while observing his Firestore user document -> Alice gets +₹5 (5%) commission
        withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.submitTaskProof(
                taskId = "task_complete_checklist",
                taskTitle = "Complete Checklist",
                category = "Checklist",
                rewardAmount = 100L,
                proofText = "Completed all checklist items with screenshot.",
                userName = "Bob Referred",
                userEmail = referredEmail,
                autoVerify = true
            ).getOrThrow()
        }

        // Trigger the real-time Firestore user document listener on Bob's profile
        val bobUpdatedProfile = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeUserProfile(bobUid).first { it != null && it.completedTasksCount == 1L }
        }
        assertNotNull(bobUpdatedProfile)
        // Bob receives the full ₹100 reward with zero deduction
        assertEquals(100L, bobUpdatedProfile?.walletBalance)

        // 4. Sign back in as Alice and verify her wallet received ₹5 (referral login credit) + ₹5 (5% task commission) = ₹10
        signInTestUser(referrerEmail)
        val aliceUpdatedProfile = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeUserProfile(aliceUid).first { it != null && it.walletBalance == 10L }
        }
        assertNotNull(aliceUpdatedProfile)
        assertEquals(10L, aliceUpdatedProfile?.walletBalance)
        assertEquals(10L, aliceUpdatedProfile?.referralCommissionEarned)

        // 5. Verify withdrawal rules: min is ₹100, max is user's total earned balance (must be >= ₹100)
        // Alice has ₹10 (< ₹100), so attempting to withdraw ₹10 or ₹100 fails
        val belowMinResult = aliceRepo.requestWithdrawal(
            amount = 50L,
            payoutMethod = "UPI Transfer",
            payoutDetails = "alice@upi",
            explicitUserId = aliceUid
        )
        assertTrue(belowMinResult.isFailure)

        val insufficientMinBalanceResult = aliceRepo.requestWithdrawal(
            amount = 100L,
            payoutMethod = "UPI Transfer",
            payoutDetails = "alice@upi",
            explicitUserId = aliceUid
        )
        assertTrue(insufficientMinBalanceResult.isFailure)

        // Sign back in as Bob (who earned ₹100 from the completed task + completes another ₹50 task = ₹150 total earned)
        signInTestUser(referredEmail)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.submitTaskProof(
                taskId = "task_bonus_50",
                taskTitle = "Bonus Survey",
                category = "Survey",
                rewardAmount = 50L,
                proofText = "Completed bonus survey.",
                userName = "Bob Referred",
                userEmail = referredEmail,
                autoVerify = true
            ).getOrThrow()
        }
        val bobBeforeWithdraw = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeUserProfile(bobUid).first { it != null && it.walletBalance == 150L }
        }
        assertEquals(150L, bobBeforeWithdraw?.walletBalance)

        // Attempting to withdraw more than Bob's total earned amount (₹200 > ₹150) fails
        val overMaxResult = bobRepo.requestWithdrawal(
            amount = 200L,
            payoutMethod = "UPI Transfer",
            payoutDetails = "bob@upi",
            explicitUserId = bobUid
        )
        assertTrue(overMaxResult.isFailure)

        // Bob withdraws his full earned balance of ₹150 (>= ₹100 min and <= ₹150 max)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.requestWithdrawal(
                amount = 150L,
                payoutMethod = "UPI Transfer",
                payoutDetails = "bob@upi",
                explicitUserId = bobUid
            ).getOrThrow()
        }
        val bobAfterWithdraw = withTimeout(FLOW_TIMEOUT_MS) {
            bobRepo.observeUserProfile(bobUid).first { it != null && it.walletBalance == 0L }
        }
        assertEquals(0L, bobAfterWithdraw?.walletBalance)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_tg@test.com"
        const val BOB_EMAIL = "bob_tg@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
